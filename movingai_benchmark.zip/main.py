# main.py (更新版本)
#!/usr/bin/env python3
"""
MOVINGAI数据集路径规划算法对比 - 包含RL-A*的主程序
"""

import os
import sys
import argparse
from pathlib import Path

# 添加项目路径
project_root = Path(__file__).parent
sys.path.append(str(project_root))

from movingai_loader import MovingAILoader
from benchmark.runner import BenchmarkRunner
from analysis.analyzer import PerformanceAnalyzer
from analysis.visualizer import ResultVisualizer
from algorithms.astar import AStarWrapper
from algorithms.thetastar import ThetaStarWrapper
from algorithms.rlastar import RLAStarWrapper  # 新的RL-A*包装器


def main():
    parser = argparse.ArgumentParser(description='路径规划算法对比测试')
    parser.add_argument('--data_dir', type=str, default='./movingai_data', 
                       help='MOVINGAI数据集目录')
    parser.add_argument('--output_dir', type=str, default='./results',
                       help='结果输出目录')
    parser.add_argument('--max_scenarios', type=int, default=50,
                       help='每个地图最大测试场景数')
    parser.add_argument('--max_obstacle', type=float, default=None,
                       help='最大障碍率 (0-1 或 百分比，例如 25 表示 25%)，仅保留障碍率小于等于阈值的地图')
    parser.add_argument('--maps', type=str, default=None,
                       help='逗号分隔的地图名列表（不带扩展名），优先于内置首选列表，例如 "maze512-1-0,random512-25-9"')
    parser.add_argument('--match_by_name', action='store_true',
                       help='当地图名中包含像 "-25-" 的百分比标签时，也将其视为匹配（用于 randomNN-XX-N 命名约定）')
    parser.add_argument('--timeout', type=float, default=30.0,
                       help='单次搜索超时时间(秒)')
    parser.add_argument('--use_focus_learning', action='store_true',
                       help='使用Focus Learning进行参数预测')
    parser.add_argument('--verbose', action='store_true',
                       help='输出详细日志')
    
    args = parser.parse_args()
    
    # 创建输出目录
    os.makedirs(args.output_dir, exist_ok=True)
    
    print("=== MOVINGAI路径规划算法对比测试 ===")
    print(f"使用Focus Learning: {args.use_focus_learning}")
    
    # 1. 初始化数据加载器
    print("初始化数据加载器...")
    loader = MovingAILoader(args.data_dir)
    
    # 2. 初始化测试运行器
    print("初始化测试运行器...")
    runner = BenchmarkRunner(loader, timeout=args.timeout)
    
    # 3. 注册算法
    print("注册路径规划算法...")
    runner.register_algorithm("A*", AStarWrapper())
    runner.register_algorithm("Theta*", ThetaStarWrapper())
    runner.register_algorithm("RL-A*", RLAStarWrapper(
        use_focus_learning=args.use_focus_learning,
        verbose=args.verbose
    ))
    
    # 4. 选择测试地图
    # 解释并展示阈值（支持 25 或 0.25 格式）
    interpreted_thr = None
    if args.max_obstacle is not None:
        try:
            thr = float(args.max_obstacle)
            interpreted_thr = thr / 100.0 if thr > 1 else thr
        except Exception:
            interpreted_thr = args.max_obstacle

    available = loader.list_maps(max_obstacle=args.max_obstacle, match_name_by_percentage=args.match_by_name)
    # 打印可用地图与选择结果，便于调试和确认筛选条件
    print(f"Found {len(available)} maps after applying max_obstacle={args.max_obstacle} (interpreted as {interpreted_thr})")
    if interpreted_thr is not None and len(available) > 0:
        for m in available:
            info = loader.get_map_info(m)
            od = info.get('obstacle_density', None) if info else None
            print(f" - {m}: obstacle_density={od}")

    # 如果用户提供了 --maps 参数则优先使用（并保证其在可用列表中）
    if args.maps:
        requested = [m.strip() for m in args.maps.split(',') if m.strip()]
        test_maps = [m for m in requested if m in available]
        if not test_maps:
            print(f"警告: 提供的地图 {requested} 均不可用或不满足 max_obstacle={args.max_obstacle}")
            test_maps = []
    else:
        # prefer an explicit shortlist but only keep maps that actually exist in the dataset
        preferred = ["maze512-1-0", "random512-1-0"]
        # keep the intersection in the preferred order
        test_maps = [m for m in preferred if m in available]
        # if none of the preferred maps are available, fall back to first N available maps
        if not test_maps:
            test_maps = available[:2]  # keep same default count as before
    
    # 5. 运行基准测试
    print(f"开始基准测试 ({len(test_maps)}个地图)...")
    results_df = runner.run_benchmark(test_maps, max_scenarios=args.max_scenarios)
    
    # 保存原始结果
    results_file = os.path.join(args.output_dir, "benchmark_results.csv")
    runner.save_results(results_file)
    print(f"结果已保存至: {results_file}")
    
    # 6. 性能分析
    print("进行性能分析...")
    analyzer = PerformanceAnalyzer(results_df)
    
    # 计算聚合指标
    metrics_df = analyzer.calculate_aggregate_metrics()
    metrics_file = os.path.join(args.output_dir, "performance_metrics.csv")
    metrics_df.to_csv(metrics_file, index=False)
    print(f"性能指标已保存至: {metrics_file}")
    
    # 统计显著性检验
    significance_df = analyzer.statistical_significance_test()
    significance_file = os.path.join(args.output_dir, "statistical_significance.csv")
    significance_df.to_csv(significance_file, index=False)
    print(f"显著性检验结果已保存至: {significance_file}")
    
    # 7. 结果可视化
    print("生成可视化图表...")
    visualizer = ResultVisualizer(results_df, args.output_dir)
    visualizer.create_all_visualizations()
    
    # 8. 生成综合报告
    print("生成综合报告...")
    report_file = os.path.join(args.output_dir, "benchmark_report.txt")
    analyzer.generate_comprehensive_report(report_file)
    
    print("=== 测试完成 ===")
    print(f"所有结果已保存至: {args.output_dir}")


if __name__ == "__main__":
    main()