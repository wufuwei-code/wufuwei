# run_benchmark.py
#!/usr/bin/env python3
"""
快速启动脚本 - 专门用于RL-A*算法测试
"""

import os
import sys
from pathlib import Path

# 添加项目路径
project_root = Path(__file__).parent
sys.path.append(str(project_root))

from movingai_loader import MovingAILoader
from benchmark.runner import BenchmarkRunner
from algorithms.rlastar import RLAStarWrapper


def quick_test():
    """快速测试RL-A*算法"""
    print("=== RL-A*算法快速测试 ===")
    
    # 初始化
    loader = MovingAILoader("./movingai_data")
    runner = BenchmarkRunner(loader, timeout=10.0)
    
    # 只注册RL-A*算法
    runner.register_algorithm("RL-A*", RLAStarWrapper(
        use_focus_learning=True,
        verbose=True
    ))
    
    # 选择少量地图进行快速测试
    test_maps = ["maze512-1-0"]
    
    print("开始快速测试...")
    results_df = runner.run_benchmark(test_maps, max_scenarios=10)

    # 处理空结果的情况（例如没有场景或全部加载失败）
    if results_df is None or results_df.empty:
        print("没有生成任何基准结果（可能没有找到场景或所有地图加载失败）")
        return results_df

    # 简单分析结果
    if 'success' not in results_df.columns:
        print("结果中不包含 'success' 字段，无法统计成功率")
        return results_df

    success_df = results_df[results_df['success'] == True]
    if len(success_df) > 0:
        avg_path_length = success_df['path_length'].mean()
        avg_expanded_nodes = success_df['expanded_nodes'].mean()
        avg_computation_time = success_df['computation_time'].mean()
        
        print(f"\n=== 测试结果 ===")
        print(f"成功率: {len(success_df)}/{len(results_df)} ({len(success_df)/len(results_df)*100:.1f}%)")
        print(f"平均路径长度: {avg_path_length:.2f}")
        print(f"平均扩展节点: {avg_expanded_nodes:.0f}")
        print(f"平均计算时间: {avg_computation_time:.4f}s")
    else:
        print("没有成功找到路径的测试用例")
    
    return results_df


if __name__ == "__main__":
    quick_test()