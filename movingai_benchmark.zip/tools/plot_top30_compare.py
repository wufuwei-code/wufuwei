import pandas as pd
import numpy as np
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def main():
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument('--csv', default=str(Path(__file__).resolve().parents[1] / 'results' / 'random100_mixed_benchmark - 副本.csv'))
    p.add_argument('--out-dir', default=str(Path(__file__).resolve().parents[1] / 'results' / 'plots'))
    p.add_argument('--max-scenarios', type=int, default=100)
    args = p.parse_args()

    df = pd.read_csv(args.csv)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # build map_scn
    if 'scenario_id' not in df.columns:
        df['scenario_id'] = df.get('scenario', '')
    df['map_scn'] = df['map_name'].astype(str) + '|' + df['scenario_id'].astype(str)

    # pick scenarios based on A* path_length descending
    ast = df[(df['algorithm']=='A*') & (df['success']==True)].copy()
    if ast.empty:
        ast = df[df['success']==True].copy()
    ast['map_scn'] = ast['map_name'].astype(str) + '|' + ast['scenario_id'].astype(str)
    unique = ast[['map_scn','path_length']].drop_duplicates().sort_values('path_length', ascending=False)
    chosen = unique['map_scn'].tolist()[:args.max_scenarios]

    sel = df[df['map_scn'].isin(chosen)].copy()

    # aggregate mean per scenario+algorithm
    agg = sel.groupby(['map_scn','algorithm']).agg(
        path_length=('path_length','mean'),
        expanded_nodes=('expanded_nodes','mean')
    ).reset_index()

    # reorder by A* path_length
    a_star = agg[agg['algorithm']=='A*'].set_index('map_scn')['path_length']
    order = a_star.sort_values(ascending=False).index.tolist()
    order_idx = {m:i for i,m in enumerate(order)}

    algs = ['A*','ML-A*','Theta*']
    colors = {'A*':'#1f77b4','ML-A*':'#4daf4a','Theta*':'#7f7f7f'}

    fig, ax1 = plt.subplots(figsize=(14,6))
    ax2 = ax1.twinx()

    x = np.arange(len(order))

    for alg in algs:
        row = agg[agg['algorithm']==alg]
        # create series aligned to order
        series = pd.Series(index=order, dtype=float)
        series[row['map_scn']] = row.set_index('map_scn')['path_length']
        y = series.values.astype(float)
        ax1.plot(x, y, marker='o', label=f'{alg} path length', color=colors.get(alg,'C0'))

    # secondary axis: expanded nodes for A*, ML-A*, Theta*
    # use consistent color mapping when plotting expanded nodes
    expanded_colors = {'A*': 'red', 'ML-A*': 'orange', 'Theta*': '#7f7f7f'}
    expanded_styles = {'A*': '-', 'ML-A*': '--', 'Theta*': ':'}
    for alg in ['A*', 'ML-A*', 'Theta*']:
        row = agg[agg['algorithm']==alg]
        series = pd.Series(index=order, dtype=float)
        if 'expanded_nodes' in row.columns:
            series[row['map_scn']] = row.set_index('map_scn')['expanded_nodes']
            ax2.plot(x, series.values, marker='s', linestyle=expanded_styles.get(alg, '-'), label=f'{alg} expanded nodes', color=expanded_colors.get(alg, 'gray'))

    ax1.set_xlabel('Map scenarios (sorted by A* path length)', fontsize=12)
    ax1.set_ylabel('Path length', fontsize=12)
    ax2.set_ylabel('Expanded nodes', fontsize=12)
    # simplify x-axis ticks to 1,10,20,... up to n
    # numeric ticks: 1,10,20,... up to n (1-based)
    if len(x) > 0:
        n = args.max_scenarios
        ticks_one_based = [1] + list(range(10, n+1, 10))
        ticks = [i-1 for i in ticks_one_based if (i-1) < len(x)]
        if not ticks:
            ax1.set_xticks([])
        else:
            labels_num = [str(i) for i in ticks_one_based if (i-1) < len(x)]
            ax1.set_xticks(ticks)
            ax1.set_xticklabels(labels_num, rotation=90, fontsize=8)
    else:
        ax1.set_xticks([])
    ax1.set_title('Comparison: Path length and Expanded nodes across maps', fontsize=14)

    h1,l1 = ax1.get_legend_handles_labels()
    h2,l2 = ax2.get_legend_handles_labels()
    ax1.legend(h1+h2, l1+l2, loc='upper right', fontsize=9)
    ax1.grid(True, axis='y', alpha=0.3)
    fig.tight_layout()

    n = args.max_scenarios
    png = out_dir / f'top{n}_compare_path_expanded.png'
    pdf = out_dir / f'top{n}_compare_path_expanded.pdf'
    fig.savefig(png, dpi=300)
    fig.savefig(pdf)
    print('Wrote compare plots to', out_dir)


if __name__ == '__main__':
    main()
