import pandas as pd
from pathlib import Path
import glob

root = Path(__file__).resolve().parents[1]
res_dir = root / 'results'
out_csv = res_dir / 'rlastar_raw_summaries.csv'

files = list(res_dir.glob('compare_rl_optimal_*.csv')) + list(res_dir.glob('benchmark_results*.csv')) + list(res_dir.glob('compare_rl_optimal*.csv'))
rows = []
for f in files:
    try:
        df = pd.read_csv(f)
    except Exception as e:
        print(f'Cannot read {f}: {e}')
        continue
    # normalize column names
    cols = [c.lower() for c in df.columns]
    df.columns = cols
    # find rows that refer to RL-A*
    mask = df.apply(lambda r: ('rl-a*' in str(r.get('algorithm','')).lower()) or ('rl-a*' in str(r.get('algorithm_name','')).lower()), axis=1)
    df_rl = df[mask].copy()
    if df_rl.empty:
        continue
    for _, r in df_rl.iterrows():
        def getc(name, default=None):
            return r.get(name, default) if name in r.index else default
        algorithm = getc('algorithm') if pd.notna(getc('algorithm')) else ''
        algname = getc('algorithm_name') if pd.notna(getc('algorithm_name')) else ''
        # determine variant
        variant = ''
        if isinstance(algname, str) and algname.strip():
            variant = algname
        elif isinstance(algorithm, str) and '(' in algorithm:
            variant = algorithm
        else:
            variant = str(algorithm) if algorithm else str(algname)
        rows.append({
            'source_file': f.name,
            'variant': variant,
            'success': getc('success', ''),
            'path_length_raw': getc('path_length', ''),
            'smooth_length': getc('smooth_length', ''),
            'grid_steps': getc('grid_steps', ''),
            'expanded_nodes': getc('expanded_nodes', ''),
            'computation_time': getc('computation_time', ''),
            'wall_time': getc('wall_time', ''),
            'map_name': getc('map_name',''),
            'scenario_id': getc('scenario_id','')
        })

if not rows:
    print('No RL-A* rows found in scanned files')
else:
    out_df = pd.DataFrame(rows)
    out_df.to_csv(out_csv, index=False)
    print(f'Wrote {len(out_df)} rows to {out_csv}')
    print(out_df.head(20).to_string(index=False))
