import sys
from pathlib import Path
project_root = Path(__file__).resolve().parents[1]
sys.path.append(str(project_root))

modules = [
    'algorithms.astar',
    'algorithms.thetastar',
    'algorithms.rlastar',
    'algorithms.base'
]

ok = True
for m in modules:
    try:
        __import__(m)
        print(f'Imported {m} OK')
    except Exception as e:
        ok = False
        print(f'Failed to import {m}: {e}')

if ok:
    print('ALL IMPORTS OK')
else:
    print('SOME IMPORTS FAILED')
