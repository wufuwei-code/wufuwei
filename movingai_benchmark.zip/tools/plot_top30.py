import pandas as pd
import numpy as np
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

root = Path(__file__).resolve().parents[1]
res_csv = root / 'results' / 'benchmark_results.csv'
if not res_csv.exists():
    raise SystemExit(f"Results CSV not found: {res_csv}")

df = pd.read_csv(res_csv)
# Filter to algorithm A* rows that succeeded
ast = df[(df['algorithm']=='A*') & (df['success']==True)].copy()
if ast.empty:
    raise SystemExit('No successful A* rows found in results CSV.')

# Create a unique map scenario identifier: map_name + '|' + scenario_id
ast['map_scn'] = ast['map_name'].astype(str) + '|' + ast['scenario_id'].astype(str)

# Determine sample of up to 30 unique scenarios
unique = ast['map_scn'].unique()
if len(unique) >= 30:
    rng = np.random.default_rng(0)
    chosen = rng.choice(unique, size=30, replace=False)
else:
    chosen = unique

sel = ast[ast['map_scn'].isin(chosen)].copy()
# Aggregate (mean) per scenario
summary = sel.groupby('map_scn').agg({'path_length':'mean','expanded_nodes':'mean'}).reset_index()
# Sort by path_length descending for nicer visualization
summary = summary.sort_values('path_length', ascending=False).reset_index(drop=True)

# Plot
out_dir = root / 'results' / 'plots'
out_dir.mkdir(parents=True, exist_ok=True)
fig, ax1 = plt.subplots(figsize=(14,6))
ax2 = ax1.twinx()

x = np.arange(len(summary))
ax1.bar(x, summary['path_length'], color='C0', alpha=0.7, label='Path length (A*)')
ax2.plot(x, summary['expanded_nodes'], color='C1', marker='o', label='Expanded nodes (A*)')

ax1.set_xlabel('Map scenario (sorted by path length)')
ax1.set_ylabel('Path length')
ax2.set_ylabel('Expanded nodes')
# shorten labels for readability
labels = [s.replace('|', '\n') for s in summary['map_scn']]
ax1.set_xticks(x)
ax1.set_xticklabels(labels, rotation=90, fontsize=8)
ax1.set_title('Sample of up to 30 map scenarios: Path length and expanded nodes (A*)')

# legends
h1, l1 = ax1.get_legend_handles_labels()
h2, l2 = ax2.get_legend_handles_labels()
ax1.legend(h1+h2, l1+l2, loc='upper right')

fig.tight_layout()
out_path = out_dir / 'top30_paths_expanded.png'
plt.savefig(out_path, dpi=150)
print(f'Saved plot to {out_path}')
