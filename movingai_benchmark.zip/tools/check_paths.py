import pandas as pd
import ast
import math
import json

CSV='results/random100_benchmark.csv'

def parse_path(s):
    if pd.isna(s):
        return None
    try:
        p = ast.literal_eval(s)
    except Exception:
        return None
    if isinstance(p, (list, tuple)) and len(p) > 0 and isinstance(p[0], (list, tuple)):
        return [(float(x[0]), float(x[1])) for x in p]
    return None

def path_length_from_points(pts):
    if not pts or len(pts) < 2:
        return 0.0
    s = 0.0
    for i in range(1, len(pts)):
        a = pts[i-1]; b = pts[i]
        s += math.hypot(b[0]-a[0], b[1]-a[1])
    return s

if __name__ == '__main__':
    df = pd.read_csv(CSV)
    print('Total rows:', len(df))
    print('Unique maps:', df['map_name'].nunique())

    parsed = 0
    mism = 0
    samples = []

    for i, r in df.iterrows():
        s = r.get('path')
        pts = parse_path(s)
        comp = path_length_from_points(pts) if pts is not None else None
        reported = r.get('path_length')
        if comp is not None and pd.notna(reported):
            parsed += 1
            if abs(comp - float(reported)) > 1e-6:
                mism += 1
                if len(samples) < 10:
                    samples.append({
                        'idx': int(i),
                        'map': r.get('map_name'),
                        'scenario': r.get('scenario_id'),
                        'algorithm': r.get('algorithm'),
                        'start': (r.get('start_x'), r.get('start_y')) if 'start_x' in r else None,
                        'goal': (r.get('goal_x'), r.get('goal_y')) if 'goal_x' in r else None,
                        'reported': reported,
                        'computed': comp,
                        'raw_path_length': r.get('raw_path_length') if 'raw_path_length' in r else None,
                        'smooth_length': r.get('smooth_length') if 'smooth_length' in r else None,
                    })

    print('Parsed path rows:', parsed)
    print('Mismatches:', mism)
    if samples:
        print('\nExamples of mismatches (up to 10):')
        print(json.dumps(samples, ensure_ascii=False, indent=2))
    else:
        print('No mismatches in sample rows.')

    # Also print first 8 rows start/goal and reported lengths for quick inspection
    print('\nFirst 8 rows start/goal and lengths:')
    for i, r in df.head(8).iterrows():
        print(i, r.get('map_name'), r.get('scenario_id'), r.get('algorithm'), 'start=', (r.get('start_x'), r.get('start_y')) if 'start_x' in r else None, 'goal=', (r.get('goal_x'), r.get('goal_y')) if 'goal_x' in r else None, 'reported=', r.get('path_length'), 'raw=', r.get('raw_path_length') if 'raw_path_length' in r else None, 'smooth=', r.get('smooth_length') if 'smooth_length' in r else None)
