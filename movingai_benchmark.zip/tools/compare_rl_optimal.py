#!/usr/bin/env python3
"""Compare default RL-A*, force_optimal RL-A*, and standard A* on a single scenario.
Writes a small CSV and prints results.
"""
import sys
from pathlib import Path
project_root = Path(__file__).resolve().parents[1]
sys.path.append(str(project_root))

import argparse
import pandas as pd
import time

from movingai_loader import MovingAILoader
from algorithms.astar import AStarWrapper
from algorithms.thetastar import ThetaStarWrapper
from algorithms.rlastar import RLAStarWrapper
from astar_demo import prune_path, smooth_path_with_bezier_adaptive
import numpy as np


def run_one(map_name, bucket, timeout=120):
    loader = MovingAILoader()
    scenarios = loader.load_scenarios(map_name)
    s = None
    for sc in scenarios:
        if sc['bucket'] == bucket:
            s = sc
            break
    if s is None:
        raise ValueError('scenario not found')

    grid = loader.load_map(map_name)
    start = (s['start_y'], s['start_x'])
    goal = (s['goal_y'], s['goal_x'])

    # Algorithms to compare: A*, Theta*, RL-A* (default)
    algos = [
        ('A*', AStarWrapper()),
        ('Theta*', ThetaStarWrapper()),
        ('RL-A* (default)', RLAStarWrapper(use_focus_learning=True, verbose=False)),
    ]

    results = []
    for name, algo in algos:
        t0 = time.time()
        res = algo.find_path(grid, start, goal)
        t1 = time.time()
        # normalize fields: ensure path is np.array of shape (N,2)
        path = np.array(res.get('path', [])) if res.get('path') is not None else np.array([])
        # grid_steps: number of discrete moves (len-1) if integer grid path
        grid_steps = int(res.get('grid_steps', 0)) if 'grid_steps' in res else (len(path)-1 if path.size>0 else 0)
        # grid_length: if path is discrete integer coords, compute 8-conn cost; otherwise fall back to res.path_length
        if path.size>0 and np.issubdtype(path.dtype, np.number):
            # if path contains floats (smoothed), compute continuous length
            try:
                # determine if coordinates are integer-like (discrete path) by checking if all close to ints
                is_integer_like = np.allclose(path, np.round(path))
            except Exception:
                is_integer_like = False
            if is_integer_like:
                # compute 8-connected cost
                diffs = np.diff(path.astype(int), axis=0)
                step_costs = np.hypot(diffs[:,0], diffs[:,1])
                grid_length = float(np.sum(step_costs))
            else:
                grid_length = float(np.sum(np.linalg.norm(np.diff(path, axis=0), axis=1)))
        else:
            grid_length = float(res.get('path_length', 0.0))

        # smooth length: if algorithm returned smooth path separately, we can't access it from wrapper
        # So, produce a pruned+smoothed version from returned path (if discrete) for fair comparison
        smooth_length = None
        try:
            if path.size>0 and np.allclose(path, np.round(path)):
                pruned = prune_path(path.astype(float), grid)
                smooth = smooth_path_with_bezier_adaptive(pruned, grid)
                smooth_length = float(np.sum(np.linalg.norm(np.diff(smooth, axis=0), axis=1)))
        except Exception:
            smooth_length = None

        res_out = {
            'path': res.get('path', []),
            'path_length': grid_length,
            'smooth_length': smooth_length,
            'grid_steps': grid_steps,
            'expanded_nodes': res.get('expanded_nodes', 0),
            'computation_time': res.get('computation_time', 0.0),
            'success': res.get('success', False),
            'wall_time': t1 - t0,
            'algorithm_name': name
        }
        results.append(res_out)
        print(f"{name}: success={res_out['success']} path_length={res_out['path_length']} smooth_length={res_out['smooth_length']} grid_steps={res_out['grid_steps']} expanded_nodes={res_out['expanded_nodes']} comp_time={res_out['computation_time']} wall_time={res_out['wall_time']}")

    df = pd.DataFrame(results)
    out = project_root / 'results' / f'compare_rl_optimal_{map_name}_bucket{bucket}.csv'
    df.to_csv(out, index=False)
    print(f"Wrote {out}")


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--map', required=True)
    p.add_argument('--bucket', type=int, required=True)
    args = p.parse_args()
    run_one(args.map, args.bucket)
