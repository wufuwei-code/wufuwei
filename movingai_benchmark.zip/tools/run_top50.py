#!/usr/bin/env python3
"""Simple, robust runner for top-k longest scenarios of a map.
Sequential (single-process) to avoid multiprocessing/Windows timeout issues during debugging.
"""
import argparse
from pathlib import Path
import sys
import pandas as pd

project_root = Path(__file__).resolve().parents[1]
sys.path.append(str(project_root))

from movingai_loader import MovingAILoader
from benchmark.runner import BenchmarkRunner, time_limit
from algorithms.astar import AStarWrapper
from algorithms.thetastar import ThetaStarWrapper
from algorithms.rlastar import RLAStarWrapper


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--map', required=True, help='map name without extension')
    parser.add_argument('--data-root', default=str(project_root / 'movingai_data'))
    parser.add_argument('--out', default=str(project_root / 'results' / 'benchmark_results_top50.csv'))
    parser.add_argument('--top', type=int, default=50)
    parser.add_argument('--timeout', type=float, default=30.0)
    parser.add_argument('--use_focus_learning', action='store_true')
    parser.add_argument('--verbose', action='store_true')
    args = parser.parse_args()

    loader = MovingAILoader(args.data_root)
    scenarios = loader.load_scenarios(args.map)
    if not scenarios:
        print(f'No scenarios found for {args.map}')
        return

    sc_sorted = sorted(scenarios, key=lambda s: s['optimal_length'], reverse=True)[:args.top]

    runner = BenchmarkRunner(loader, timeout=args.timeout)
    runner.register_algorithm('A*', AStarWrapper())
    runner.register_algorithm('Theta*', ThetaStarWrapper())
    runner.register_algorithm('ML-A*', RLAStarWrapper(use_focus_learning=args.use_focus_learning, verbose=args.verbose))

    all_results = []
    grid = loader.load_map(args.map)

    for s in sc_sorted:
        start = (s['start_y'], s['start_x'])
        goal = (s['goal_y'], s['goal_x'])
        if not runner._is_valid_position(grid, start) or not runner._is_valid_position(grid, goal):
            print(f"Invalid start/goal for bucket {s['bucket']}")
            continue

        for name, finder in runner.algorithms.items():
            try:
                with time_limit(int(runner.timeout)):
                    res = finder.find_path(grid, start, goal)
            except Exception:
                res = runner._create_timeout_result(name)

            if 'grid_steps' not in res:
                res['grid_steps'] = res.get('path_length', 0) if isinstance(res.get('path_length', 0), (int, float)) else 0

            res.update({
                'map_name': args.map,
                'scenario_id': s['bucket'],
                'start_x': start[1],
                'start_y': start[0],
                'goal_x': goal[1],
                'goal_y': goal[0],
                'optimal_length': s['optimal_length'],
                'suboptimality_ratio': (res['path_length'] / s['optimal_length'] if res.get('success') and s['optimal_length']>0 else float('inf'))
            })
            all_results.append(res)

    df = pd.DataFrame(all_results)
    df.to_csv(args.out, index=False)
    print(f"Saved results to {args.out}")


if __name__ == '__main__':
    main()

