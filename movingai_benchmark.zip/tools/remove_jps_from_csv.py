#!/usr/bin/env python3
"""Scan CSV files under results/ and create copies with JPS rows removed.
Writes files with suffix _noJPS.csv next to the originals.
"""
import pandas as pd
from pathlib import Path

def process_file(p: Path):
    try:
        df = pd.read_csv(p)
    except Exception as e:
        print(f'Failed to read {p}: {e}')
        return False
    if 'algorithm' not in df.columns:
        print(f'No algorithm column in {p}, skipping')
        return False
    if (df['algorithm'] == 'JPS').any():
        out = p.with_name(p.stem + '_noJPS' + p.suffix)
        df2 = df[df['algorithm'] != 'JPS']
        df2.to_csv(out, index=False)
        print(f'Wrote {out} (removed {(df.shape[0]-df2.shape[0])} JPS rows)')
        return True
    else:
        print(f'No JPS rows in {p}, not writing copy')
        return False

def main():
    root = Path(__file__).resolve().parents[1]
    res_dir = root / 'results'
    if not res_dir.exists():
        print('results/ not found')
        return
    csvs = list(res_dir.glob('*.csv'))
    if not csvs:
        print('No CSV files found in results/')
        return
    processed = 0
    for p in csvs:
        if process_file(p):
            processed += 1
    print(f'Done. Processed {processed} files.')

if __name__ == '__main__':
    main()
