"""Inspect smoothing columns in a benchmark CSV and print stats per algorithm.
Usage: python tools\inspect_smoothing.py [path/to/csv]
"""
import sys
import pandas as pd
from pathlib import Path

p = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("results/random100_quarter_mixed_benchmark_fixed.csv")
if not p.exists():
    print(f"CSV not found: {p}")
    sys.exit(2)

df = pd.read_csv(p)
print("Loaded:", p)
print("columns:", list(df.columns))
print()
print("algorithm value counts:")
print(df['algorithm'].value_counts())

smoothing_cols = [c for c in df.columns if 'smooth' in c.lower() or 'raw_path_length' in c.lower()]
print()
print("smoothing related columns:", smoothing_cols)
print()

for alg in df['algorithm'].unique():
    sub = df[df['algorithm'] == alg]
    applied = 0
    if 'smooth_applied' in df.columns:
        # coerce truthiness
        applied = sub['smooth_applied'].fillna(False).astype(bool).sum()
    elif 'smooth_length' in df.columns:
        applied = sub['smooth_length'].notna().sum()
    total = len(sub)
    pct = (applied / total) * 100 if total else 0
    print(f"{alg}: {applied}/{total} smoothed ({pct:.1f}%)")

print('\nSample A* rows:')
print(df[df['algorithm'] == 'A*'].head(5).to_string(index=False))
print('\nSample Theta* rows:')
print(df[df['algorithm'] == 'Theta*'].head(5).to_string(index=False))
