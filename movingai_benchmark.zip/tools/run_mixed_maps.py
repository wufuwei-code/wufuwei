import argparse
import sys
import os
import numpy as np
from pathlib import Path
import pandas as pd

# ensure project root is on sys.path so 'algorithms' and 'benchmark' packages import correctly
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from movingai_loader import MovingAILoader
from algorithms.astar import AStarWrapper
from algorithms.thetastar import ThetaStarWrapper
from algorithms.rlastar import RLAStarWrapper
from benchmark.runner import BenchmarkRunner


def pick_far_apart_pair(grid, max_sample=500):
    free = np.argwhere(grid == 0)
    if free.size == 0:
        return (0,0), (grid.shape[0]-1, grid.shape[1]-1)
    m = len(free)
    if m <= max_sample:
        idx = np.arange(m)
    else:
        idx = np.random.choice(m, size=max_sample, replace=False)
    coords = free[idx]
    try:
        dif = coords[:, None, :] - coords[None, :, :]
        sq = (dif ** 2).sum(axis=2)
        i, j = np.unravel_index(np.argmax(sq), sq.shape)
        a = coords[int(i)]; b = coords[int(j)]
        return (int(a[0]), int(a[1])), (int(b[0]), int(b[1]))
    except Exception:
        # fallback: random
        a = coords[np.random.choice(len(coords))]
        b = coords[np.random.choice(len(coords))]
        return (int(a[0]), int(a[1])), (int(b[0]), int(b[1]))


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--n', type=int, default=100)
    p.add_argument('--out', default=str(Path(__file__).resolve().parents[1] / 'results' / 'random100_quarter_mixed_benchmark_fixed.csv'))
    p.add_argument('--rows', type=int, default=80)
    p.add_argument('--cols', type=int, default=80)
    p.add_argument('--obs', type=float, default=0.30)
    p.add_argument('--ratio', default='2:1:1', help='ratios for random:da2:dao')
    p.add_argument('--timeout', type=float, default=30.0)
    args = p.parse_args()

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    loader = MovingAILoader()

    # build candidate lists per dataset (include street-map)
    maps_root = Path(loader.data_root) / 'maps'
    random_maps = [p.stem for p in (maps_root / 'random-map').glob('*.map')] if (maps_root / 'random-map').exists() else []
    da2_maps = [p.stem for p in (maps_root / 'da2-map').glob('*.map')] if (maps_root / 'da2-map').exists() else []
    dao_maps = [p.stem for p in (maps_root / 'dao-map').glob('*.map')] if (maps_root / 'dao-map').exists() else []
    street_maps = [p.stem for p in (maps_root / 'street-map').glob('*.map')] if (maps_root / 'street-map').exists() else []

    if len(random_maps) == 0 and len(da2_maps) == 0 and len(dao_maps) == 0 and len(street_maps) == 0:
        print('No maps found in movingai_data/maps; aborting')
        return

    # select exactly 25 maps from each of four datasets (random, da2, dao, street)
    per_dataset = int(args.n / 4)
    n = args.n
    def sample_k(source_list, k):
        if not source_list:
            return []
        if k <= len(source_list):
            return list(np.random.choice(source_list, size=k, replace=False))
        # if not enough maps, allow sampling with replacement but keep order
        return list(np.random.choice(source_list, size=k, replace=True))

    chosen_maps = []
    chosen_maps += sample_k(random_maps, per_dataset)
    chosen_maps += sample_k(da2_maps, per_dataset)
    chosen_maps += sample_k(dao_maps, per_dataset)
    chosen_maps += sample_k(street_maps, per_dataset)

    all_available = list(set(random_maps + da2_maps + dao_maps + street_maps))
    print(f'Using per-dataset={per_dataset}, total requested n={n}, actual chosen maps count={len(chosen_maps)}')

    results = []

    # We'll continue sampling/replacing until we have n maps where A* succeeded
    success_maps = set()
    tried_maps = set()
    all_available = all_available

    # candidate pool: shuffle the list so selection is random
    pool = list(all_available)
    np.random.shuffle(pool)

    global_trials = 0
    # increase maximum allowed global trials to make the "guarantee 100 A* successes" feasible
    max_global_trials = max(20000, n * 200)

    # helper to build and run benchmark for a single (name, start,goal) scenario
    def run_one_map_scenario(name, start, goal):
        scenario = {
            'bucket': 0,
            'start_x': int(start[1]), 'start_y': int(start[0]),
            'goal_x': int(goal[1]), 'goal_y': int(goal[0]),
            'optimal_length': float(np.hypot(goal[0]-start[0], goal[1]-start[1]))
        }

        class SingleLoader:
            def __init__(self, grid, scenario):
                self._grid = grid
                self._scenario = scenario

            def load_map(self, nm):
                return self._grid

            def load_scenarios(self, nm):
                return [self._scenario]

        grid = loader.load_map(name)
        if grid is None:
            print('Skipping map (load failed)', name)
            return pd.DataFrame()

        loader_single = SingleLoader(grid, scenario)

        runner = BenchmarkRunner(loader_single, timeout=args.timeout)
        runner.register_algorithm('A*', AStarWrapper())
        runner.register_algorithm('Theta*', ThetaStarWrapper())
        runner.register_algorithm('ML-A*', RLAStarWrapper(use_focus_learning=True, verbose=False))

        try:
            df_map = runner.run_benchmark([name], max_scenarios=1)
        except Exception as e:
            print('Error running benchmark for', name, e)
            df_map = pd.DataFrame()

        if df_map is None or df_map.empty:
            return pd.DataFrame()

        df_map['map_name'] = name
        return df_map

    # First pass: try chosen_maps (original selection) in order
    for name in chosen_maps:
        if global_trials >= max_global_trials:
            break
        tried_maps.add(name)
        grid = loader.load_map(name)
        if grid is None:
            print('Skipping map', name)
            continue

        # single attempt per map: if A* fails, give up and move on
        global_trials += 1
        start, goal = pick_far_apart_pair(grid, max_sample=500)
        df_map = run_one_map_scenario(name, start, goal)
        if not df_map.empty:
            try:
                a_row = df_map[df_map['algorithm'] == 'A*']
                a_success = False
                if not a_row.empty:
                    a_success = bool(a_row.iloc[0].get('success', False))
            except Exception:
                a_success = False

            if a_success:
                results.append(df_map)
                success_maps.add(name)
                print(f'Accepted map {name} on single attempt')
            else:
                print(f'Map {name} A* failed on single attempt; replacing')
        else:
            print(f'Map {name} produced no results; skipping')

    # Continue filling until we have n successful maps
    pool_idx = 0
    while len(success_maps) < n and global_trials < max_global_trials:
        if pool_idx >= len(pool):
            # reshuffle pool and allow repeats if necessary
            pool = list(all_available)
            np.random.shuffle(pool)
            pool_idx = 0

        cand = pool[pool_idx]
        pool_idx += 1
        if cand in success_maps or cand in tried_maps:
            continue

        tried_maps.add(cand)
        grid = loader.load_map(cand)
        if grid is None:
            continue

        # single attempt per candidate: if fails, give up and continue
        global_trials += 1
        start, goal = pick_far_apart_pair(grid, max_sample=500)
        df_map = run_one_map_scenario(cand, start, goal)
        if not df_map.empty:
            try:
                a_row = df_map[df_map['algorithm'] == 'A*']
                a_success = False
                if not a_row.empty:
                    a_success = bool(a_row.iloc[0].get('success', False))
            except Exception:
                a_success = False

            if a_success:
                results.append(df_map)
                success_maps.add(cand)
                print(f'Accepted new map {cand} on single attempt (total success_maps={len(success_maps)})')
            else:
                print(f'Candidate {cand} A* failed on single attempt; giving up')
        else:
            print(f'Candidate {cand} produced no results; skipping')

    if len(results) == 0:
        print('No results produced')
        return

    # final DataFrame: only include maps we've accepted (success_maps)
    final_df = pd.concat(results, ignore_index=True)
    # keep only accepted successful map entries
    final_df = final_df[final_df['map_name'].isin(list(success_maps))]
    if final_df.empty:
        print('No successful results produced')
        return
    final_df.to_csv(out_path, index=False)
    print('Wrote mixed benchmark to', out_path)

    # call plotting
    try:
        import subprocess
        script_dir = Path(__file__).resolve().parents[1] / 'tools'
        script_pub = str(script_dir / 'plot_top30_publication.py')
        script_cmp = str(script_dir / 'plot_top30_compare.py')
        subprocess.run([sys.executable, script_pub, '--csv', str(out_path), '--max-scenarios', str(args.n)], check=False)
        subprocess.run([sys.executable, script_cmp, '--csv', str(out_path), '--max-scenarios', str(args.n)], check=False)
    except Exception:
        pass


if __name__ == '__main__':
    main()
