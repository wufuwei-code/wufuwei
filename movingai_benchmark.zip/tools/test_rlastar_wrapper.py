import sys
from pathlib import Path
project_root = Path(__file__).resolve().parents[1]
sys.path.append(str(project_root))

import numpy as np
from algorithms.rlastar import RLAStarWrapper

if __name__ == '__main__':
    w = RLAStarWrapper(use_focus_learning=False, verbose=False)
    grid = np.zeros((10,10), dtype=int)
    start=(0,0)
    goal=(9,9)
    res = w.find_path(grid, start, goal)
    print('OK')
    print('keys:', sorted(res.keys()))
    print('additional_info keys:', sorted(res.get('additional_info', {}).keys()))
    print('raw_path_length:', res.get('additional_info', {}).get('raw_path_length'))
    print('smooth_length:', res.get('additional_info', {}).get('smooth_length'))
