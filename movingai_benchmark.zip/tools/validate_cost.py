import sys
from pathlib import Path
project_root = Path(__file__).resolve().parents[1]
sys.path.append(str(project_root))

from movingai_loader import MovingAILoader
from benchmark.runner import BenchmarkRunner
from algorithms.astar import AStarWrapper

def main():
    loader = MovingAILoader(project_root / 'movingai_data')
    scenarios = loader.load_scenarios('maze512-1-0')
    if not scenarios:
        print('no scenarios')
        return

    sc_sorted = sorted(scenarios, key=lambda s: s['optimal_length'], reverse=True)[:20]
    runner = BenchmarkRunner(loader, timeout=5)
    runner.register_algorithm('A*', AStarWrapper())

    print('bucket\tofficial_opt\tour_cost\tgrid_steps\tsuccess\texpanded')
    for s in sc_sorted:
        start = (s['start_y'], s['start_x'])
        goal = (s['goal_y'], s['goal_x'])
        grid = loader.load_map('maze512-1-0')
        res = runner.algorithms['A*'].find_path(grid, start, goal)
        print(f"{s['bucket']}\t{s['optimal_length']}\t{res.get('path_length')}\t{res.get('grid_steps')}\t{res.get('success')}\t{res.get('expanded_nodes')}")

if __name__ == '__main__':
    main()
