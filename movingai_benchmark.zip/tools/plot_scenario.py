#!/usr/bin/env python3
"""
tools/plot_scenario.py
绘制单个场景的地图、扩展节点和路径为 PNG。
用法示例：
  python tools/plot_scenario.py --map maze512-1-0 --bucket 0 --algorithm A* --out results/plot.png
"""
import argparse
from pathlib import Path
import sys
project_root = Path(__file__).resolve().parents[1]
sys.path.append(str(project_root))

from movingai_loader import MovingAILoader
from analysis.visualizer import ResultVisualizer
from algorithms.astar import AStarWrapper
from algorithms.thetastar import ThetaStarWrapper
# JPS removed from supported algorithms
from algorithms.rlastar import RLAStarWrapper


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_dir', default='movingai_data')
    parser.add_argument('--map', required=True, help='map name without extension')
    parser.add_argument('--bucket', type=int, default=0, help='scenario bucket/index to pick (0-based in scen file order)')
    parser.add_argument('--algorithm', default='A*', choices=['A*','Theta*','RL-A*'])
    parser.add_argument('--out', default='results/plot.png')
    parser.add_argument('--use_focus_learning', action='store_true')
    args = parser.parse_args()

    loader = MovingAILoader(args.data_dir)
    grid = loader.load_map(args.map)
    if grid is None:
        print('Map not found')
        return

    scen = loader.load_scenarios(args.map)
    if not scen:
        print('Scenarios not found')
        return

    if args.bucket < 0 or args.bucket >= len(scen):
        print('Bucket out of range')
        return

    s = scen[args.bucket]
    start = (s['start_y'], s['start_x'])
    goal = (s['goal_y'], s['goal_x'])

    # choose algorithm
    if args.algorithm == 'A*':
        finder = AStarWrapper()
    elif args.algorithm == 'Theta*':
        finder = ThetaStarWrapper()
    else:
        # default to RL-A*
        finder = RLAStarWrapper(use_focus_learning=args.use_focus_learning, verbose=False)

    # run the algorithm (no timeout here)
    res = finder.find_path(grid, start, goal)

    viz = ResultVisualizer(None, Path(args.out).parent)

    expanded = None
    # try to extract expanded nodes list if returned in additional_info
    if 'expanded_nodes_list' in res:
        expanded = res['expanded_nodes_list']

    out = viz.plot_path(grid, res.get('path', []), expanded=expanded, start=start, goal=goal, out_file=args.out)
    print('Saved plot to', out)


if __name__ == '__main__':
    main()
