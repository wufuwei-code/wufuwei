import pandas as pd
import numpy as np
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def load_df(path):
    p = Path(path)
    if not p.exists():
        raise SystemExit(f'Results CSV not found: {p}')
    return pd.read_csv(p)


def main():
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument('--csv', default=str(Path(__file__).resolve().parents[1] / 'results' / 'benchmark_results_top30_unique.csv'))
    p.add_argument('--out-dir', default=str(Path(__file__).resolve().parents[1] / 'results' / 'plots'))
    p.add_argument('--max-scenarios', type=int, default=30, help='Maximum number of scenarios to include')
    args = p.parse_args()

    df = load_df(args.csv)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # prefer rows where algorithm == 'A*' for ordering scenarios by path length
    ast = df[(df['algorithm'] == 'A*') & (df['success'] == True)].copy()
    if ast.empty:
        # fallback: use any successful rows
        ast = df[df['success'] == True].copy()

    ast['map_scn'] = ast['map_name'].astype(str) + '|' + ast['scenario_id'].astype(str)
    # choose up to max_scenarios unique scenarios preserved order
    unique = ast['map_scn'].unique()
    chosen = unique[:args.max_scenarios]

    # ensure df has map_scn and then filter by chosen scenarios
    if 'scenario_id' not in df.columns:
        df['scenario_id'] = df.get('scenario', '')
    df['map_scn'] = df['map_name'].astype(str) + '|' + df['scenario_id'].astype(str)
    sel = df[df['map_scn'].isin(chosen)]

    # Aggregate per scenario+algorithm
    # summary aggregated per scenario+algorithm
    # choose available timing column
    time_col = 'plan_time' if 'plan_time' in sel.columns else ('computation_time' if 'computation_time' in sel.columns else None)
    if time_col is None:
        print('Warning: neither plan_time nor computation_time present; timing plots will be skipped')

    agg_dict = {'path_length':('path_length','mean')}
    if 'expanded_nodes' in sel.columns:
        agg_dict['expanded_nodes'] = ('expanded_nodes','mean')
    if time_col is not None:
        agg_dict['plan_time'] = (time_col,'mean')

    summary = sel.groupby(['map_scn', 'algorithm']).agg(**agg_dict).reset_index()

    # Pivot A* path_length for ordering
    a_star = summary[summary['algorithm']=='A*'][['map_scn','path_length']].set_index('map_scn')
    order = a_star['path_length'].sort_values(ascending=False).index.tolist()

    # Plot 1: Path length (bar) and expanded nodes (line) per map scenario for A*
    fig, ax1 = plt.subplots(figsize=(12,6))
    ax2 = ax1.twinx()

    a_summary = summary[summary['algorithm']=='A*'].set_index('map_scn').reindex(order)
    x = np.arange(len(a_summary))
    ax1.bar(x, a_summary['path_length'], color='#2b83ba', label='Path length (A*)', alpha=0.85)
    if 'expanded_nodes' in a_summary.columns:
        ax2.plot(x, a_summary['expanded_nodes'], color='#d7191c', marker='o', label='Expanded nodes (A*)')
    else:
        print('Warning: expanded_nodes not present in summary; line will be empty')

    ax1.set_xlabel('Map scenario (sorted by A* path length)', fontsize=12)
    ax1.set_ylabel('Path length', fontsize=12)
    ax2.set_ylabel('Expanded nodes', fontsize=12)
    labels = [s.replace('|','\n') for s in a_summary.index]
    # simplify x-axis ticks to numeric 1,10,20,... up to n
    if len(x) > 0:
        n = args.max_scenarios
        # desired one-based tick positions: 1,10,20,... up to n
        ticks_one_based = [1] + list(range(10, n+1, 10))
        # convert to zero-based indices and keep those that exist in data
        ticks = [i-1 for i in ticks_one_based if (i-1) < len(x)]
        if not ticks:
            ax1.set_xticks([])
        else:
            labels_num = [str(i) for i in ticks_one_based if (i-1) < len(x)]
            ax1.set_xticks(ticks)
            ax1.set_xticklabels(labels_num, rotation=0, fontsize=8)
    else:
        ax1.set_xticks([])
    ax1.set_title('Sample of up to 30 map scenarios: Path length and expanded nodes (A*)', fontsize=14)

    h1, l1 = ax1.get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    ax1.legend(h1+h2, l1+l2, loc='upper right', fontsize=10)
    fig.tight_layout()
    n = args.max_scenarios
    available = len(unique)
    if available < n:
        print(f'Warning: requested {n} scenarios but only {available} available; using {available}.')

    png_path = out_dir / f'top{n}_paths_expanded_publication.png'
    pdf_path = out_dir / f'top{n}_paths_expanded_publication.pdf'
    fig.savefig(png_path, dpi=300)
    fig.savefig(pdf_path)

    # Plot 2: Planning time boxplot per algorithm
    plt.close(fig)
    fig2, ax = plt.subplots(figsize=(8,6))
    if time_col is not None:
        df_plot = df[df['success']==True]
        algs = df_plot['algorithm'].unique()
        data = [df_plot[df_plot['algorithm']==a][time_col].dropna().values for a in algs]
        ax.boxplot(data, labels=algs, patch_artist=True)
        ax.set_ylabel(f'Planning time (s) [{time_col}]', fontsize=12)
        ax.set_title('Planning time by algorithm (successful runs)', fontsize=14)
        fig2.tight_layout()
        png2 = out_dir / 'planning_time_boxplot.png'
        pdf2 = out_dir / 'planning_time_boxplot.pdf'
        fig2.savefig(png2, dpi=300)
        fig2.savefig(pdf2)
    else:
        print('Skipping planning time boxplot: no timing column available')

    print(f'Wrote publication plots to {out_dir} ({png_path.name}, {pdf_path.name})')


if __name__ == '__main__':
    main()
