#!/usr/bin/env python3
"""Run the single longest scenario from up to 30 different maps (one per map).
Produces a consolidated CSV suitable for plotting and paper-quality figures.
"""
import argparse
from pathlib import Path
import sys
import pandas as pd

project_root = Path(__file__).resolve().parents[1]
sys.path.append(str(project_root))

from movingai_loader import MovingAILoader
from benchmark.runner import BenchmarkRunner, time_limit
from algorithms.astar import AStarWrapper
from algorithms.thetastar import ThetaStarWrapper
from algorithms.rlastar import RLAStarWrapper


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data-root', default=str(project_root / 'movingai_data'))
    parser.add_argument('--out', default=str(project_root / 'results' / 'benchmark_results_top30_unique.csv'))
    parser.add_argument('--timeout', type=float, default=30.0)
    parser.add_argument('--use_focus_learning', action='store_true')
    parser.add_argument('--verbose', action='store_true')
    args = parser.parse_args()

    loader = MovingAILoader(args.data_root)

    # collect available map names (folder/name without .map)
    map_paths = list(Path(args.data_root).glob('maps/**/*.map'))
    map_names = []
    for p in map_paths:
        # name without extension and without folder prefix: assume loader.load_map expects basename with extension-less name
        map_names.append(p.stem)

    # unique preserving order
    seen = set()
    unique_maps = []
    for m in map_names:
        if m not in seen:
            seen.add(m)
            unique_maps.append(m)

    chosen = unique_maps[:30]
    if len(chosen) == 0:
        print('No maps found under', args.data_root)
        return

    runner = BenchmarkRunner(loader, timeout=args.timeout)
    runner.register_algorithm('A*', AStarWrapper())
    runner.register_algorithm('Theta*', ThetaStarWrapper())
    runner.register_algorithm('RL-A*', RLAStarWrapper(use_focus_learning=args.use_focus_learning, verbose=args.verbose))

    all_results = []

    for idx_map, map_name in enumerate(chosen, start=1):
        print(f'[{idx_map}/{len(chosen)}] Processing map: {map_name}')
        scenarios = loader.load_scenarios(map_name)
        if not scenarios:
            print(f'No scenarios for map {map_name}, skipping')
            continue
        # pick the single longest scenario
        s = max(scenarios, key=lambda x: x['optimal_length'])
        start = (s['start_y'], s['start_x'])
        goal = (s['goal_y'], s['goal_x'])

        grid = loader.load_map(map_name)
        if not runner._is_valid_position(grid, start) or not runner._is_valid_position(grid, goal):
            print(f'Invalid start/goal for map {map_name}, bucket {s.get("bucket")}, skipping')
            continue

        for name, finder in runner.algorithms.items():
            print(f'   Running algorithm: {name} ...', end='', flush=True)
            try:
                with time_limit(int(runner.timeout)):
                    res = finder.find_path(grid, start, goal)
                print(' done')
            except Exception:
                res = runner._create_timeout_result(name)
                print(' timeout/exception')

            if 'grid_steps' not in res:
                res['grid_steps'] = res.get('path_length', 0) if isinstance(res.get('path_length', 0), (int, float)) else 0

            res.update({
                'map_name': map_name,
                'scenario_id': s.get('bucket'),
                'start_x': start[1],
                'start_y': start[0],
                'goal_x': goal[1],
                'goal_y': goal[0],
                'optimal_length': s.get('optimal_length'),
                'suboptimality_ratio': (res.get('path_length', float('inf')) / s.get('optimal_length', float('inf')) if res.get('success') and s.get('optimal_length', 0)>0 else float('inf'))
            })
            all_results.append(res)

    df = pd.DataFrame(all_results)
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out_path, index=False)
    print(f'Saved results to {out_path} (maps count={len(chosen)}, rows={len(df)})')


if __name__ == '__main__':
    main()
