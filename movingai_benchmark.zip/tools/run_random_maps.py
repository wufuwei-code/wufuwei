import argparse
import sys
import os
import numpy as np
from pathlib import Path
import pandas as pd

# ensure project root is on sys.path so 'algorithms' and 'benchmark' packages import correctly
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from algorithms.astar import AStarWrapper
from algorithms.thetastar import ThetaStarWrapper
from algorithms.rlastar import RLAStarWrapper

from benchmark.runner import BenchmarkRunner


def generate_random_map(rows=80, cols=80, obstacle_ratio=0.30, seed=None):
    if seed is not None:
        np.random.seed(seed)
    grid = np.zeros((rows, cols), dtype=int)
    mask = np.random.rand(rows, cols) < obstacle_ratio
    grid[mask] = 1
    # ensure at least one free cell for start/goal
    grid[0, 0] = 0
    grid[rows-1, cols-1] = 0
    return grid


def pick_random_free_cell(grid):
    free = np.argwhere(grid == 0)
    if free.size == 0:
        return None
    idx = np.random.choice(len(free))
    r, c = free[idx]
    return (int(r), int(c))


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--n', type=int, default=100, help='Number of random maps to generate')
    p.add_argument('--out', default=str(Path(__file__).resolve().parents[1] / 'results' / 'random100_benchmark.csv'))
    p.add_argument('--rows', type=int, default=80)
    p.add_argument('--cols', type=int, default=80)
    p.add_argument('--obs', type=float, default=0.30, help='Obstacle density')
    p.add_argument('--timeout', type=float, default=30.0)
    args = p.parse_args()

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    # create simple loader that matches runner expectations
    class SimpleLoader:
        def __init__(self, maps):
            self.maps = maps

        def load_map(self, name):
            return self.maps.get(name)

        def load_scenarios(self, name):
            # each map will have a single scenario entry
            # mimic movingai scenario fields used by runner
            return [self.maps[name]['scenario']]

    # We'll generate maps one-by-one and run the benchmark for each map until
    # we have collected `args.n` unique maps where A* succeeded. This avoids
    # missing samples due to failures or duplicates.
    all_results = []
    seen_maps = set()
    map_idx = 0
    max_attempts = max(1000, args.n * 20)  # safety cap to avoid infinite loops

    while len(seen_maps) < args.n and map_idx < max_attempts:
        name = f'random_map_{map_idx:04d}'
        grid = generate_random_map(args.rows, args.cols, args.obs, seed=None)

        # pick start/goal trying to maximize distance between them
        free = np.argwhere(grid == 0)
        start = None
        goal = None
        if free.size == 0:
            start = (0, 0)
            goal = (args.rows-1, args.cols-1)
        else:
            # sample up to this many free cells to compute approximate farthest pair
            max_sample = 500
            m = len(free)
            if m <= max_sample:
                sample_idx = np.arange(m)
            else:
                sample_idx = np.random.choice(m, size=max_sample, replace=False)
            coords = free[sample_idx]
            try:
                # compute pairwise squared distances (broadcasting) and pick max
                dif = coords[:, None, :] - coords[None, :, :]
                sq = (dif ** 2).sum(axis=2)
                i, j = np.unravel_index(np.argmax(sq), sq.shape)
                a = coords[int(i)]
                b = coords[int(j)]
                start = (int(a[0]), int(a[1]))
                goal = (int(b[0]), int(b[1]))
                if start == goal:
                    # fallback to random pick
                    start = tuple(map(int, free[np.random.choice(len(free))]))
                    goal = tuple(map(int, free[np.random.choice(len(free))]))
                    if start == goal:
                        goal = (args.rows-1, args.cols-1)
            except Exception:
                # fallback: pick random free cells
                start = tuple(map(int, free[np.random.choice(len(free))]))
                goal = tuple(map(int, free[np.random.choice(len(free))]))
                if start == goal:
                    goal = (args.rows-1, args.cols-1)

        optimal_length = float(np.hypot(goal[0]-start[0], goal[1]-start[1]))
        scenario = {
            'bucket': 0,
            'start_x': int(start[1]), 'start_y': int(start[0]),
            'goal_x': int(goal[1]), 'goal_y': int(goal[0]),
            'optimal_length': optimal_length
        }

        # create a tiny loader for this single map
        class SingleLoader:
            def __init__(self, grid, scenario):
                self._grid = grid
                self._scenario = scenario

            def load_map(self, nm):
                return self._grid

            def load_scenarios(self, nm):
                return [self._scenario]

        loader = SingleLoader(grid, scenario)

        runner = BenchmarkRunner(loader, timeout=args.timeout)
        runner.register_algorithm('A*', AStarWrapper())
        runner.register_algorithm('Theta*', ThetaStarWrapper())
        runner.register_algorithm('RL-A*', RLAStarWrapper(use_focus_learning=False, verbose=False))

        try:
            df_map = runner.run_benchmark([name], max_scenarios=1)
        except Exception as e:
            print(f'Error running benchmark for {name}: {e}')
            df_map = pd.DataFrame()

        if df_map is None or df_map.empty:
            map_idx += 1
            continue

        # ensure map_name column is set (runner sets it)
        df_map['map_name'] = name

        # append
        all_results.append(df_map)

        # check how many unique maps have A* success
        combined = pd.concat(all_results, ignore_index=True)
        a_success = combined[(combined['algorithm'] == 'A*') & (combined['success'] == True)]
        unique_success_maps = set(a_success['map_name'].tolist())

        # if this map produced a successful A* entry, record it
        if name in unique_success_maps:
            seen_maps.add(name)

        map_idx += 1

    if len(all_results) == 0:
        print('No benchmark results were produced.')
        return

    final_df = pd.concat(all_results, ignore_index=True)
    # save results
    final_df.to_csv(out_path, index=False)
    print(f'Wrote random benchmark results to {out_path} (collected {len(seen_maps)} unique A* successes)')

    # call existing plots using this csv (user can re-run manually if desired)
    try:
        import subprocess
        script_dir = Path(__file__).resolve().parents[1] / 'tools'
        script_pub = str(script_dir / 'plot_top30_publication.py')
        script_cmp = str(script_dir / 'plot_top30_compare.py')
        subprocess.run([sys.executable, script_pub, '--csv', str(out_path), '--max-scenarios', str(args.n)], check=False)
        subprocess.run([sys.executable, script_cmp, '--csv', str(out_path), '--max-scenarios', str(args.n)], check=False)
    except Exception:
        pass


if __name__ == '__main__':
    main()
