import os
import numpy as np
from typing import Dict, List, Tuple, Optional
from pathlib import Path


class MovingAILoader:
    """MOVINGAI数据集加载器"""
    
    def __init__(self, data_root: str = "./movingai_data"):
        self.data_root = Path(data_root)
        self.map_cache = {}
        
    def list_maps(self, max_obstacle: Optional[float] = None, match_name_by_percentage: bool = False) -> List[str]:
        """列出所有可用的地图文件。

        参数:
            max_obstacle: 可选的最大障碍率阈值，0-1之间的浮点数；也支持传入大于1的百分比（例如25表示25%）。
        """
        maps_root = self.data_root / "maps"
        if not maps_root.exists():
            raise FileNotFoundError(f"地图目录不存在: {maps_root}")

        # 搜索所有子目录下的 .map 文件，返回不带扩展名的文件名列表
        map_files = list(maps_root.rglob("*.map"))

        # 如果存在名为 random-map 的子目录并且其中包含地图，则认为用户在使用随机数据集，允许包含 random 地图。
        random_dir = maps_root / 'random-map'
        allow_random = False
        if random_dir.exists() and any(random_dir.rglob('*.map')):
            allow_random = True

        def is_random(stem: str) -> bool:
            return stem.lower().startswith('random')

        candidate_maps = [f.stem for f in map_files] if allow_random else [f.stem for f in map_files if not is_random(f.stem)]

        # 如果指定了最大障碍率阈值，则根据实际地图信息过滤
        if max_obstacle is not None:
            try:
                thr = float(max_obstacle)
            except Exception:
                thr = None

            if thr is not None:
                # 支持以百分比形式传入(>1 表示百分比)
                interpreted_as_percent = False
                if thr > 1:
                    thr = thr / 100.0
                    interpreted_as_percent = True

                # 加入一个小容差以避免浮点边界导致的意外排除
                eps = 1e-9

                filtered = []
                for m in candidate_maps:
                    info = self.get_map_info(m)
                    if not info:
                        continue
                    od = info.get('obstacle_density', 1.0)
                    if od <= thr + eps:
                        filtered.append(m)
                    else:
                        # 额外：如果用户允许按名称匹配百分比（如 random512-25-9），
                        # 则解析名称中的数字片段并与阈值比较，以便用户能通过命名约定选择地图
                        if match_name_by_percentage:
                            parts = m.split('-')
                            matched = False
                            for p in parts:
                                try:
                                    val = int(p)
                                    # 如果部分值与阈值百分比相等，则当作匹配
                                    if thr > 0 and abs(val / 100.0 - thr) < 1e-9:
                                        filtered.append(m)
                                        matched = True
                                        break
                                except ValueError:
                                    continue
                            if matched:
                                # 已匹配，继续下一个地图
                                continue

                return filtered

        return candidate_maps
    
    def load_map(self, map_name: str) -> Optional[np.ndarray]:
        """加载MOVINGAI地图文件"""
        if map_name in self.map_cache:
            return self.map_cache[map_name]
        maps_root = self.data_root / "maps"

        # 优先尝试直接在 maps/ 下查找
        map_path = maps_root / f"{map_name}.map"
        if not map_path.exists():
            # 回退：在 maps 的所有子目录中查找匹配的文件（例如 maze-map/）
            candidates = list(maps_root.rglob(f"{map_name}.map"))
            # 如果存在 random-map 子目录并且用户希望使用随机数据集，则不要过滤 random 地图
            random_dir = maps_root / 'random-map'
            allow_random = random_dir.exists() and any(random_dir.rglob('*.map'))
            if not allow_random:
                # 忽略以 'random' 开头的候选项
                candidates = [c for c in candidates if not c.stem.lower().startswith('random')]
            if len(candidates) > 0:
                map_path = candidates[0]
            else:
                print(f"警告: 地图文件不存在: {map_path}")
                return None
            
        try:
            with open(map_path, 'r') as f:
                lines = [line.rstrip('\n') for line in f]
                
            # 解析地图头信息
            map_type = None
            height, width = 0, 0
            map_start_line = 0
            
            for i, line in enumerate(lines):
                if line.startswith("type"):
                    map_type = line.split()[1]
                elif line.startswith("height"):
                    height = int(line.split()[1])
                elif line.startswith("width"):
                    width = int(line.split()[1])
                elif line == "map":
                    map_start_line = i + 1
                    break
            
            if height == 0 or width == 0:
                raise ValueError("无法解析地图尺寸")
                
            # 读取地图数据
            map_data = []
            for i in range(map_start_line, map_start_line + height):
                if i < len(lines):
                    row = lines[i][:width]  # 确保宽度一致
                    map_data.append(list(row))
                else:
                    map_data.append(['@'] * width)  # 填充障碍物
                    
            # 转换为数值网格 (0=可通行, 1=障碍物)
            grid = np.zeros((height, width), dtype=np.uint8)
            for i in range(height):
                for j in range(width):
                    cell = map_data[i][j]
                    # MOVINGAI地图字符含义
                    if cell in ['.', 'G', 'S', 'W']:  # 可通行区域
                        grid[i, j] = 0
                    else:  # 障碍物 ('@', 'O', 'T', 等)
                        grid[i, j] = 1
                        
            self.map_cache[map_name] = grid
            return grid
            
        except Exception as e:
            print(f"加载地图 {map_name} 时出错: {e}")
            return None
    
    def load_scenarios(self, map_name: str) -> List[Dict]:
        """加载测试场景"""
        scenarios_root = self.data_root / "scenarios"

        # 优先尝试直接在 scenarios/ 下查找
        scenario_path = scenarios_root / f"{map_name}.scen"
        if not scenario_path.exists():
            # 回退：在 scenarios 的子目录中查找匹配的 .scen 文件
            # 有些 scen 文件可能带有额外后缀，比如 'maze512-1-0.map.scen'，因此使用包含匹配
            candidates = list(scenarios_root.rglob(f"*{map_name}*.scen"))
            if len(candidates) > 0:
                scenario_path = candidates[0]
            else:
                print(f"警告: 场景文件不存在: {scenario_path}")
                return []
            
        scenarios = []
        try:
            with open(scenario_path, 'r') as f:
                lines = f.readlines()
                
            # 跳过版本行
            for line in lines[1:]:
                parts = line.strip().split('\t')
                if len(parts) >= 9:
                    scenario = {
                        'bucket': int(parts[0]),
                        'map_name': parts[1],
                        'map_width': int(parts[2]),
                        'map_height': int(parts[3]),
                        'start_x': int(parts[4]),
                        'start_y': int(parts[5]),
                        'goal_x': int(parts[6]),
                        'goal_y': int(parts[7]),
                        'optimal_length': float(parts[8])
                    }
                    scenarios.append(scenario)
                    
        except Exception as e:
            print(f"加载场景文件 {scenario_path} 时出错: {e}")
            
        return scenarios
    
    def get_map_info(self, map_name: str) -> Dict:
        """获取地图信息"""
        grid = self.load_map(map_name)
        if grid is None:
            return {}
            
        obstacle_count = np.sum(grid)
        total_cells = grid.size
        obstacle_density = obstacle_count / total_cells
        
        return {
            'name': map_name,
            'height': grid.shape[0],
            'width': grid.shape[1],
            'obstacle_density': obstacle_density,
            'free_cells': total_cells - obstacle_count
        }