"""
Enhanced Model Loader - 解决不同hidden size的模型加载问题
"""
import torch
import numpy as np
from meta.meta_controller import MetaController, SimpleMLP

class EnhancedModelLoader:
    """增强模型加载器，自动检测和适配不同的模型架构"""
    
    @staticmethod
    def load_enhanced_model(model_path: str, scaler_path: str, use_multi_head: bool = True, use_calibration: bool = True):
        """
        智能加载增强模型，自动检测hidden size
        """
        # 先检查模型文件的架构参数
        checkpoint = torch.load(model_path, map_location='cpu', weights_only=False)

        # 从权重形状推断hidden size
        if use_multi_head:
            # Multi-head模式，检查shared_backbone的维度
            if 'shared_backbone.0.weight' in checkpoint:
                hidden_size = checkpoint['shared_backbone.0.weight'].shape[0]
            else:
                hidden_size = 96  # 默认值
        else:
            # 单头模式，检查第一层的维度
            if 'net.0.weight' in checkpoint:
                hidden_size = checkpoint['net.0.weight'].shape[0]
            else:
                hidden_size = 96  # 默认值

        print(f"检测到模型hidden_size: {hidden_size}")

        # 创建匹配的模型架构，支持校准
        mc = MetaController(use_mlp=True, delta_mode=True, use_multi_head=use_multi_head, use_calibration=use_calibration)

        # 重新创建匹配的模型
        mc.model = SimpleMLP(in_dim=20, hidden=hidden_size, out_dim=8, use_multi_head=use_multi_head)

        # 加载模型权重
        mc.model.load_state_dict(checkpoint)

        # 加载scaler
        if scaler_path:
            data = np.load(scaler_path)
            mc.scaler_mean = data['mean'].astype(np.float32)
            mc.scaler_std = data['std'].astype(np.float32)
            if 'delta_mode' in data:
                mc.trained_delta_flag = bool(int(data['delta_mode'][0]))

        # 加载校准模型（如果启用）
        if use_calibration:
            calibration_dir = 'meta/models/calibration'
            mc.load_calibration_models(calibration_dir)

        return mc

def test_focus_model():
    """测试Focus增强模型"""
    print("=== Focus Learning增强模型测试 ===\n")
    
    # 测试地图特征生成函数
    def generate_test_features(size=20, obs_rate=0.25):
        features = {
            'height': size, 'width': size,
            'obstacle_ratio': obs_rate,
            'free_ratio': 1.0 - obs_rate,
            'dist_mean': size * 0.6,
            'dist_std': size * 0.2,
            'dist_min': size * 0.1,
            'dist_p25': size * 0.4,
            'dist_p50': size * 0.6,
            'dist_p75': size * 0.8,
            'num_components': 1,
            'largest_component_ratio': 0.85,
            'narrow_region_ratio': obs_rate * 0.6,
            'approx_path_len': size * 1.4,
            'approx_reachable': 1.0,
            'start_goal_euclid': size * 0.8,
            'start_local_free': 0.9,
            'goal_local_free': 0.9,
            'row_entropy': 2.5,
            'col_entropy': 2.5
        }
        return features
    
    # 加载Focus增强模型
    try:
        focus_mc = EnhancedModelLoader.load_enhanced_model(
            'meta/models/meta_mlp_enhanced_focus.pt',
            'meta/models/meta_scaler_enhanced_focus.npz',
            use_multi_head=True
        )
        print("✅ Focus增强模型加载成功!")
    except Exception as e:
        print(f"❌ Focus增强模型加载失败: {e}")
        return
    
    # 对比测试
    models = [
        ("Rule基线", None),
        ("Focus增强", focus_mc),
    ]
    
    test_maps = [
        (15, 0.20, "简单地图"),
        (20, 0.30, "中等地图"), 
        (25, 0.35, "复杂地图")
    ]
    
    for map_size, obs_rate, map_desc in test_maps:
        print(f"\n{map_desc} ({map_size}x{map_size}, 障碍率{obs_rate:.2f}):")
        features = generate_test_features(map_size, obs_rate)
        
        print("  参数              | Rule     | Focus增强  | 差异(%)")
        print("  ------------------------------------------------")
        
        # Rule baseline
        rule_mc = MetaController(use_mlp=False)
        rule_params = rule_mc.rule_based_init(features)
        
        # Focus enhanced
        focus_params = focus_mc.predict_delta(features)
        
        # 对比关键参数
        key_params = ['initial_weight', 'lambda_risk', 'lambda_smooth', 'frontier_radius']
        for param in key_params:
            rule_val = rule_params.get(param, 0)
            focus_val = focus_params.get(param, 0)
            diff_pct = ((focus_val - rule_val) / rule_val * 100) if rule_val != 0 else 0
            print(f"  {param:16} | {rule_val:8.2f} | {focus_val:8.2f} | {diff_pct:+6.1f}%")

if __name__ == "__main__":
    test_focus_model()