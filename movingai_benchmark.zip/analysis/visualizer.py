import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np
import os
from typing import List


class ResultVisualizer:
    """Result visualizer for benchmark results."""

    def __init__(self, results_df: pd.DataFrame, output_dir: str):
        self.results = results_df
        self.output_dir = output_dir
        self.success_df = results_df[results_df['success'] == True]

        # plotting style
        plt.style.use('seaborn-v0_8')
        sns.set_palette("husl")

    def create_all_visualizations(self):
        """Create all visualization charts."""
        self.create_performance_comparison()
        self.create_efficiency_scatter()
        self.create_success_rate_chart()
        self.create_computation_time_distribution()
        self.create_path_length_comparison()
        self.create_algorithm_ranking()

    def create_performance_comparison(self):
        """Create a 2x3 performance comparison grid."""
        fig, axes = plt.subplots(2, 3, figsize=(18, 12))
        fig.suptitle('Path Planning Performance Comparison', fontsize=16, fontweight='bold')

        # Success rate comparison
        success_rates = self.results.groupby('algorithm')['success'].mean()
        axes[0, 0].bar(success_rates.index, success_rates.values * 100)
        axes[0, 0].set_title('Success Rate Comparison')
        axes[0, 0].set_ylabel('Success Rate (%)')
        axes[0, 0].tick_params(axis='x', rotation=45)

        # Path length distribution
        if not self.success_df.empty:
            sns.boxplot(data=self.success_df, x='algorithm', y='path_length', ax=axes[0, 1])
            axes[0, 1].set_title('Path Length Distribution')
            axes[0, 1].set_ylabel('Path Length')
            axes[0, 1].tick_params(axis='x', rotation=45)

        # Expanded nodes distribution
        if not self.success_df.empty:
            sns.boxplot(data=self.success_df, x='algorithm', y='expanded_nodes', ax=axes[0, 2])
            axes[0, 2].set_title('Expanded Nodes Distribution')
            axes[0, 2].set_ylabel('Expanded Nodes')
            axes[0, 2].tick_params(axis='x', rotation=45)

        # Computation time distribution
        if not self.success_df.empty:
            sns.boxplot(data=self.success_df, x='algorithm', y='computation_time', ax=axes[1, 0])
            axes[1, 0].set_title('Computation Time Distribution')
            axes[1, 0].set_ylabel('Computation Time (s)')
            axes[1, 0].tick_params(axis='x', rotation=45)

        # Suboptimality ratio
        if not self.success_df.empty:
            valid_subopt = self.success_df[self.success_df['suboptimality_ratio'] < 10]
            sns.boxplot(data=valid_subopt, x='algorithm', y='suboptimality_ratio', ax=axes[1, 1])
            axes[1, 1].set_title('Suboptimality Ratio')
            axes[1, 1].set_ylabel('Path Length / Optimal Length')
            axes[1, 1].tick_params(axis='x', rotation=45)

        # Efficiency scatter (avg time vs avg expanded nodes)
        if not self.success_df.empty:
            algo_means = self.success_df.groupby('algorithm').agg({
                'computation_time': 'mean',
                'expanded_nodes': 'mean'
            }).reset_index()

            axes[1, 2].scatter(
                algo_means['computation_time'],
                algo_means['expanded_nodes'],
                s=100, alpha=0.7
            )

            # add labels
            for i, row in algo_means.iterrows():
                axes[1, 2].annotate(
                    row['algorithm'],
                    (row['computation_time'], row['expanded_nodes']),
                    xytext=(5, 5), textcoords='offset points'
                )

            axes[1, 2].set_title('Efficiency Trade-off')
            axes[1, 2].set_xlabel('Avg. Computation Time (s)')
            axes[1, 2].set_ylabel('Avg. Expanded Nodes')
            axes[1, 2].grid(True, alpha=0.3)

        plt.tight_layout()
        plt.savefig(os.path.join(self.output_dir, 'performance_comparison.png'), dpi=300, bbox_inches='tight')
        plt.close()

    def create_efficiency_scatter(self):
        """Scatter plot of computation time vs expanded nodes for each algorithm."""
        if self.success_df.empty:
            return

        fig, ax = plt.subplots(figsize=(10, 8))

        algorithms = self.success_df['algorithm'].unique()
        colors = plt.cm.Set1(np.linspace(0, 1, len(algorithms)))

        for i, algo in enumerate(algorithms):
            algo_data = self.success_df[self.success_df['algorithm'] == algo]
            ax.scatter(algo_data['computation_time'], algo_data['expanded_nodes'], c=[colors[i]], label=algo, alpha=0.6, s=50)

        ax.set_xlabel('Computation Time (s)')
        ax.set_ylabel('Expanded Nodes')
        ax.set_title('Algorithm Efficiency Scatter')
        ax.legend()
        ax.grid(True, alpha=0.3)

        plt.savefig(os.path.join(self.output_dir, 'efficiency_scatter.png'), dpi=300, bbox_inches='tight')
        plt.close()

    def create_success_rate_chart(self):
        """Bar chart showing success rate and sample count per algorithm."""
        success_by_algo = self.results.groupby('algorithm')['success'].agg(['mean', 'count'])
        success_by_algo = success_by_algo.sort_values('mean', ascending=False)

        fig, ax = plt.subplots(figsize=(10, 6))

        bars = ax.bar(success_by_algo.index, success_by_algo['mean'] * 100)
        ax.set_ylabel('Success Rate (%)')
        ax.set_title('Success Rate by Algorithm')

        for bar, count in zip(bars, success_by_algo['count']):
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width() / 2., height + 1, f'{height:.1f}%', ha='center', va='bottom')
            ax.text(bar.get_x() + bar.get_width() / 2., height / 2, f'n={count}', ha='center', va='center', color='white', fontweight='bold')

        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_dir, 'success_rate.png'), dpi=300, bbox_inches='tight')
        plt.close()

    def create_computation_time_distribution(self):
        """Violin plot for computation time distribution (filtered by 95th percentile)."""
        if self.success_df.empty:
            return

        fig, ax = plt.subplots(figsize=(12, 6))

        time_data = self.success_df[self.success_df['computation_time'] < self.success_df['computation_time'].quantile(0.95)]

        sns.violinplot(data=time_data, x='algorithm', y='computation_time', ax=ax)
        ax.set_ylabel('Computation Time (s)')
        ax.set_title('Computation Time Distribution')
        plt.xticks(rotation=45)

        plt.tight_layout()
        plt.savefig(os.path.join(self.output_dir, 'computation_time_dist.png'), dpi=300, bbox_inches='tight')
        plt.close()

    def create_path_length_comparison(self):
        """Compare path quality relative to optimal (boxplot)."""
        if self.success_df.empty:
            return

        fig, ax = plt.subplots(figsize=(12, 6))

        valid_data = self.success_df[self.success_df['suboptimality_ratio'] < 2]

        sns.boxplot(data=valid_data, x='algorithm', y='suboptimality_ratio', ax=ax)
        ax.axhline(1.0, color='red', linestyle='--', alpha=0.7, label='Optimal Path')
        ax.set_ylabel('Path Length / Optimal Length')
        ax.set_title('Path Quality Comparison (relative to optimal)')
        ax.legend()
        plt.xticks(rotation=45)

        plt.tight_layout()
        plt.savefig(os.path.join(self.output_dir, 'path_quality.png'), dpi=300, bbox_inches='tight')
        plt.close()

    def create_algorithm_ranking(self):
        """Create radar chart ranking algorithms by composite score."""
        metrics = []
        for algo in self.results['algorithm'].unique():
            algo_data = self.results[self.results['algorithm'] == algo]
            success_data = algo_data[algo_data['success'] == True]

            if len(success_data) == 0:
                continue

            success_rate = len(success_data) / len(algo_data)
            # avoid division by zero
            max_time = self.success_df['computation_time'].max() if not self.success_df.empty else 1.0
            max_nodes = self.success_df['expanded_nodes'].max() if not self.success_df.empty else 1.0
            max_length = self.success_df['path_length'].max() if not self.success_df.empty else 1.0

            avg_time = 1 - (success_data['computation_time'].mean() / max_time)
            avg_nodes = 1 - (success_data['expanded_nodes'].mean() / max_nodes)
            avg_length = 1 - (success_data['path_length'].mean() / max_length)

            composite_score = (0.3 * success_rate + 0.3 * avg_time + 0.2 * avg_nodes + 0.2 * avg_length)

            metrics.append({
                'algorithm': algo,
                'composite_score': composite_score,
                'success_rate': success_rate,
                'time_efficiency': avg_time,
                'node_efficiency': avg_nodes,
                'path_quality': avg_length
            })

        if not metrics:
            return

        metrics_df = pd.DataFrame(metrics).sort_values('composite_score', ascending=False)

        # Radar chart
        categories = ['Success Rate', 'Time Efficiency', 'Node Efficiency', 'Path Quality']
        algorithms = metrics_df['algorithm'].tolist()

        fig, ax = plt.subplots(figsize=(10, 8), subplot_kw=dict(projection='polar'))

        angles = np.linspace(0, 2 * np.pi, len(categories), endpoint=False).tolist()
        angles += angles[:1]

        for i, algo in enumerate(algorithms):
            values = [
                metrics_df[metrics_df['algorithm'] == algo]['success_rate'].iloc[0],
                metrics_df[metrics_df['algorithm'] == algo]['time_efficiency'].iloc[0],
                metrics_df[metrics_df['algorithm'] == algo]['node_efficiency'].iloc[0],
                metrics_df[metrics_df['algorithm'] == algo]['path_quality'].iloc[0]
            ]
            values += values[:1]

            ax.plot(angles, values, 'o-', linewidth=2, label=algo)
            ax.fill(angles, values, alpha=0.1)

        ax.set_xticks(angles[:-1])
        ax.set_xticklabels(categories)
        ax.set_ylim(0, 1)
        ax.set_title('Algorithm Performance Radar', size=14, fontweight='bold')
        ax.legend(bbox_to_anchor=(1.1, 1.05))

        plt.tight_layout()
        plt.savefig(os.path.join(self.output_dir, 'algorithm_ranking.png'), dpi=300, bbox_inches='tight')
        plt.close()

    def plot_path(self, grid: np.ndarray, path: List[tuple], expanded: List[tuple] = None,
                  start: tuple = None, goal: tuple = None, out_file: str = None):
        """在地图网格上绘制路径和扩展节点。

        Args:
            grid: 2D numpy array (0=free,1=obstacle)
            path: list of (row,col) tuples
            expanded: optional list of (row,col) tuples (expanded nodes)
            start, goal: optional (row,col)
            out_file: 如果提供则保存为 PNG，否则返回 matplotlib Figure
        """
        h, w = grid.shape
        fig, ax = plt.subplots(figsize=(8, 8))

        # 绘制地图（障碍=黑，空白=白）
        ax.imshow(grid, cmap='Greys_r', origin='upper')

        # 绘制扩展节点
        if expanded:
            ex_r = [p[0] for p in expanded]
            ex_c = [p[1] for p in expanded]
            ax.scatter(ex_c, ex_r, s=4, c='orange', alpha=0.6, label='expanded')

        # 绘制路径
        if path and len(path) > 0:
            pr = [p[0] for p in path]
            pc = [p[1] for p in path]
            ax.plot(pc, pr, color='cyan', linewidth=2.5, label='path')
            ax.scatter(pc[0], pr[0], color='green', s=50, marker='o', label='start')
            ax.scatter(pc[-1], pr[-1], color='red', s=50, marker='X', label='goal')
        else:
            if start:
                ax.scatter(start[1], start[0], color='green', s=50, marker='o', label='start')
            if goal:
                ax.scatter(goal[1], goal[0], color='red', s=50, marker='X', label='goal')

        ax.set_xlim(-0.5, w - 0.5)
        ax.set_ylim(h - 0.5, -0.5)
        ax.set_xticks([])
        ax.set_yticks([])
        ax.legend(loc='upper right')
        plt.tight_layout()

        if out_file:
            os.makedirs(os.path.dirname(out_file), exist_ok=True)
            plt.savefig(out_file, dpi=300, bbox_inches='tight')
            plt.close()
            return out_file
        else:
            return fig