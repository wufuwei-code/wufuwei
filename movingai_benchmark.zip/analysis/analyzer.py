import pandas as pd
import numpy as np
from scipy import stats
from typing import Dict, List
import itertools


class PerformanceAnalyzer:
    """性能分析器"""
    
    def __init__(self, results_df: pd.DataFrame):
        self.results = results_df
        
    def calculate_aggregate_metrics(self) -> pd.DataFrame:
        """计算聚合性能指标"""
        success_df = self.results[self.results['success'] == True]
        
        metrics = []
        for algo in self.results['algorithm'].unique():
            algo_data = self.results[self.results['algorithm'] == algo]
            algo_success = success_df[success_df['algorithm'] == algo]
            
            if len(algo_success) == 0:
                continue
                
            # 基础指标
            total_scenarios = len(algo_data)
            successful_scenarios = len(algo_success)
            success_rate = successful_scenarios / total_scenarios
            
            # 路径质量指标
            avg_path_length = algo_success['path_length'].mean()
            std_path_length = algo_success['path_length'].std()
            avg_suboptimality = algo_success['suboptimality_ratio'].mean()
            
            # 效率指标
            avg_expanded_nodes = algo_success['expanded_nodes'].mean()
            avg_computation_time = algo_success['computation_time'].mean()
            median_computation_time = algo_success['computation_time'].median()
            
            # 鲁棒性指标
            time_std = algo_success['computation_time'].std()
            node_std = algo_success['expanded_nodes'].std()
            
            metric = {
                'algorithm': algo,
                'success_rate': success_rate,
                'total_scenarios': total_scenarios,
                'successful_scenarios': successful_scenarios,
                'avg_path_length': avg_path_length,
                'std_path_length': std_path_length,
                'avg_suboptimality': avg_suboptimality,
                'avg_expanded_nodes': avg_expanded_nodes,
                'std_expanded_nodes': node_std,
                'avg_computation_time': avg_computation_time,
                'std_computation_time': time_std,
                'median_computation_time': median_computation_time,
                'efficiency_score': self._calculate_efficiency_score(algo_success)
            }
            metrics.append(metric)
            
        return pd.DataFrame(metrics).sort_values('success_rate', ascending=False)
    
    def _calculate_efficiency_score(self, algo_success: pd.DataFrame) -> float:
        """计算效率综合评分"""
        if len(algo_success) == 0:
            return 0.0
            
        # 归一化指标
        norm_time = 1 - (algo_success['computation_time'].mean() / 
                        self.results[self.results['success']]['computation_time'].max())
        norm_nodes = 1 - (algo_success['expanded_nodes'].mean() / 
                         self.results[self.results['success']]['expanded_nodes'].max())
        norm_length = 1 - (algo_success['path_length'].mean() / 
                          self.results[self.results['success']]['path_length'].max())
        
        # 加权综合评分
        weights = {'time': 0.4, 'nodes': 0.4, 'length': 0.2}
        efficiency_score = (weights['time'] * norm_time + 
                           weights['nodes'] * norm_nodes + 
                           weights['length'] * norm_length)
        
        return max(0, efficiency_score)
    
    def statistical_significance_test(self) -> pd.DataFrame:
        """统计显著性检验"""
        success_df = self.results[self.results['success'] == True]
        algorithms = success_df['algorithm'].unique()
        
        if len(algorithms) < 2:
            return pd.DataFrame()
            
        significance_results = []
        
        for algo1, algo2 in itertools.combinations(algorithms, 2):
            data1 = success_df[success_df['algorithm'] == algo1]
            data2 = success_df[success_df['algorithm'] == algo2]
            
            if len(data1) == 0 or len(data2) == 0:
                continue
                
            # 路径长度t检验
            try:
                t_stat_len, p_val_len = stats.ttest_ind(
                    data1['path_length'], data2['path_length'], equal_var=False
                )
            except:
                t_stat_len, p_val_len = 0, 1
                
            # 扩展节点数t检验
            try:
                t_stat_nodes, p_val_nodes = stats.ttest_ind(
                    data1['expanded_nodes'], data2['expanded_nodes'], equal_var=False
                )
            except:
                t_stat_nodes, p_val_nodes = 0, 1
                
            # 计算时间t检验
            try:
                t_stat_time, p_val_time = stats.ttest_ind(
                    data1['computation_time'], data2['computation_time'], equal_var=False
                )
            except:
                t_stat_time, p_val_time = 0, 1
            
            # 效应量计算
            cohen_d_length = self._cohens_d(data1['path_length'], data2['path_length'])
            cohen_d_nodes = self._cohens_d(data1['expanded_nodes'], data2['expanded_nodes'])
            cohen_d_time = self._cohens_d(data1['computation_time'], data2['computation_time'])
            
            significance_results.append({
                'comparison': f"{algo1} vs {algo2}",
                'path_length_pvalue': p_val_len,
                'path_length_significant': p_val_len < 0.05,
                'path_length_effect_size': cohen_d_length,
                'expanded_nodes_pvalue': p_val_nodes,
                'expanded_nodes_significant': p_val_nodes < 0.05,
                'expanded_nodes_effect_size': cohen_d_nodes,
                'computation_time_pvalue': p_val_time,
                'computation_time_significant': p_val_time < 0.05,
                'computation_time_effect_size': cohen_d_time
            })
            
        return pd.DataFrame(significance_results)
    
    def _cohens_d(self, x, y):
        """计算Cohen's d效应量"""
        nx, ny = len(x), len(y)
        dof = nx + ny - 2
        if dof <= 0:
            return 0
            
        pooled_std = np.sqrt(((nx-1)*np.std(x, ddof=1)**2 + 
                            (ny-1)*np.std(y, ddof=1)**2) / dof)
        
        if pooled_std == 0:
            return 0
            
        return (np.mean(x) - np.mean(y)) / pooled_std
    
    def analyze_by_map_type(self) -> pd.DataFrame:
        """按地图类型分析性能"""
        if 'map_name' not in self.results.columns:
            return pd.DataFrame()
            
        # 简单的地图分类
        def classify_map(name):
            name_lower = name.lower()
            if 'street' in name_lower or 'city' in name_lower:
                return 'urban'
            elif 'maze' in name_lower:
                return 'maze'
            elif 'room' in name_lower:
                return 'indoor'
            elif 'random' in name_lower:
                return 'random'
            else:
                return 'other'
                
        self.results['map_type'] = self.results['map_name'].apply(classify_map)
        
        map_analysis = []
        for map_type in self.results['map_type'].unique():
            for algo in self.results['algorithm'].unique():
                type_algo_data = self.results[
                    (self.results['map_type'] == map_type) & 
                    (self.results['algorithm'] == algo)
                ]
                
                if len(type_algo_data) == 0:
                    continue
                    
                success_data = type_algo_data[type_algo_data['success'] == True]
                success_rate = len(success_data) / len(type_algo_data)
                
                if len(success_data) > 0:
                    avg_time = success_data['computation_time'].mean()
                    avg_nodes = success_data['expanded_nodes'].mean()
                    avg_length = success_data['path_length'].mean()
                else:
                    avg_time = avg_nodes = avg_length = float('inf')
                    
                map_analysis.append({
                    'map_type': map_type,
                    'algorithm': algo,
                    'success_rate': success_rate,
                    'avg_computation_time': avg_time,
                    'avg_expanded_nodes': avg_nodes,
                    'avg_path_length': avg_length,
                    'scenario_count': len(type_algo_data)
                })
                
        return pd.DataFrame(map_analysis)
    
    def generate_comprehensive_report(self, output_file: str):
        """生成综合报告"""
        metrics_df = self.calculate_aggregate_metrics()
        significance_df = self.statistical_significance_test()
        map_analysis_df = self.analyze_by_map_type()
        
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write("=== 路径规划算法性能对比报告 ===\n\n")
            
            f.write("1. 总体性能排名\n")
            f.write("=" * 50 + "\n")
            for _, row in metrics_df.iterrows():
                f.write(f"{row['algorithm']}:\n")
                f.write(f"  成功率: {row['success_rate']:.1%}\n")
                f.write(f"  平均路径长度: {row['avg_path_length']:.2f}\n")
                f.write(f"  平均扩展节点: {row['avg_expanded_nodes']:.0f}\n")
                f.write(f"  平均计算时间: {row['avg_computation_time']:.4f}s\n")
                f.write(f"  效率评分: {row['efficiency_score']:.3f}\n\n")
                
            f.write("\n2. 统计显著性分析\n")
            f.write("=" * 50 + "\n")
            for _, row in significance_df.iterrows():
                f.write(f"{row['comparison']}:\n")
                if row['path_length_significant']:
                    f.write(f"  路径长度: p={row['path_length_pvalue']:.4f}*, d={row['path_length_effect_size']:.2f}\n")
                else:
                    f.write(f"  路径长度: p={row['path_length_pvalue']:.4f}, d={row['path_length_effect_size']:.2f}\n")
                    
                if row['expanded_nodes_significant']:
                    f.write(f"  扩展节点: p={row['expanded_nodes_pvalue']:.4f}*, d={row['expanded_nodes_effect_size']:.2f}\n")
                else:
                    f.write(f"  扩展节点: p={row['expanded_nodes_pvalue']:.4f}, d={row['expanded_nodes_effect_size']:.2f}\n")
                    
                if row['computation_time_significant']:
                    f.write(f"  计算时间: p={row['computation_time_pvalue']:.4f}*, d={row['computation_time_effect_size']:.2f}\n")
                else:
                    f.write(f"  计算时间: p={row['computation_time_pvalue']:.4f}, d={row['computation_time_effect_size']:.2f}\n")
                f.write("\n")
                
            if not map_analysis_df.empty:
                f.write("\n3. 地图类型分析\n")
                f.write("=" * 50 + "\n")
                for map_type in map_analysis_df['map_type'].unique():
                    f.write(f"{map_type}地图:\n")
                    type_data = map_analysis_df[map_analysis_df['map_type'] == map_type]
                    for _, row in type_data.iterrows():
                        f.write(f"  {row['algorithm']}: 成功率{row['success_rate']:.1%}, "
                               f"时间{row['avg_computation_time']:.4f}s, "
                               f"节点{row['avg_expanded_nodes']:.0f}\n")
                    f.write("\n")
                    
            f.write("\n4. 结论\n")
            f.write("=" * 50 + "\n")
            best_algo = metrics_df.iloc[0]
            f.write(f"综合表现最佳的算法是 {best_algo['algorithm']}, ")
            f.write(f"成功率 {best_algo['success_rate']:.1%}, ")
            f.write(f"效率评分 {best_algo['efficiency_score']:.3f}\n")