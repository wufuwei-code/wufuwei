from abc import ABC, abstractmethod
import time
import numpy as np
from typing import List, Tuple, Dict, Any


class BasePathFinder(ABC):
    """路径规划算法基类"""
    
    def __init__(self):
        self.name = "BasePathFinder"
        
    @abstractmethod
    def find_path(self, grid: np.ndarray, start: Tuple[int, int], 
                 goal: Tuple[int, int]) -> Dict[str, Any]:
        """寻找路径
        
        Args:
            grid: 二维网格地图，0=可通行，1=障碍物
            start: 起点坐标 (row, col)
            goal: 终点坐标 (row, col)
            
        Returns:
            包含路径信息的结果字典
        """
        pass
    
    def _create_result(self, path: List[Tuple[int, int]], 
                      expanded_nodes: int, 
                      computation_time: float, 
                      success: bool,
                      additional_info: Dict = None) -> Dict[str, Any]:
        """创建标准化结果字典"""
        cost, steps = self._calculate_path_length(path, return_steps=True)
        result = {
            'path': path,
            # 'path_length' 保留为代价（8连通：正交=1, 对角=sqrt(2)）以便与官方 cost 对齐
            'path_length': cost,
            # 同时输出 grid_steps（节点步数，即 len(path)-1，当 path 为空为 0）
            'grid_steps': steps,
            'expanded_nodes': expanded_nodes,
            'computation_time': computation_time,
            'success': success,
            'algorithm': self.name
        }
        
        if additional_info:
            result.update(additional_info)
            
        return result
    
    def _calculate_path_length(self, path: List[Tuple[int, int]], return_steps: bool = False):
        """计算路径长度（两种度量）

        返回:
          - cost: 使用 8-连通代价计算（正交步=1，斜步=sqrt(2)）
          - steps: 网格步数（len(path)-1）
        """
        # 兼容列表或 numpy 数组的判空和长度检查
        if path is None:
            return (0.0, 0) if return_steps else 0.0

        try:
            if isinstance(path, np.ndarray):
                n_points = path.shape[0]
            else:
                n_points = len(path)
        except Exception:
            return (0.0, 0) if return_steps else 0.0

        if n_points < 2:
            return (0.0, 0) if return_steps else 0.0

        cost = 0.0
        for i in range(1, n_points):
            dx = abs(path[i][0] - path[i-1][0])
            dy = abs(path[i][1] - path[i-1][1])
            # 正交移动
            if dx + dy == 1:
                step_cost = 1.0
            # 对角移动 (dx==1 and dy==1)
            elif dx == 1 and dy == 1:
                step_cost = float(np.sqrt(2.0))
            else:
                # 非标准跳跃（如果发生，退回到欧式距离）
                step_cost = float(np.sqrt(dx*dx + dy*dy))
            cost += step_cost

        steps = max(0, n_points - 1)
        return (cost, steps) if return_steps else cost
    
    def _is_valid_cell(self, grid: np.ndarray, cell: Tuple[int, int]) -> bool:
        """检查单元格是否有效且可通行"""
        row, col = cell
        return (0 <= row < grid.shape[0] and 
                0 <= col < grid.shape[1] and 
                grid[row, col] == 0)
    
    def _get_neighbors(self, grid: np.ndarray, cell: Tuple[int, int], 
                      diagonal: bool = True) -> List[Tuple[int, int]]:
        """获取相邻单元格"""
        row, col = cell
        neighbors = []
        
        # 8方向移动
        directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]  # 上下左右
        if diagonal:
            directions.extend([(-1, -1), (-1, 1), (1, -1), (1, 1)])  # 对角线
            
        for dr, dc in directions:
            new_row, new_col = row + dr, col + dc
            if self._is_valid_cell(grid, (new_row, new_col)):
                # 检查对角线移动是否被阻挡
                if abs(dr) == 1 and abs(dc) == 1:
                    if (grid[row, new_col] == 1 or grid[new_row, col] == 1):
                        continue
                neighbors.append((new_row, new_col))
                
        return neighbors