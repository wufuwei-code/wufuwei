# algorithms/rlastar.py
import time
import numpy as np
from typing import List, Tuple, Dict, Any
from .base import BasePathFinder

# 明确从本包导入 astar_demo，避免导入根目录同名模块的歧义
from .astar_demo import (
    focus_predict_and_constrain,
    search_with_decreasing_inflation,
    prune_path,
    smooth_path_with_bezier_adaptive,
    DEFAULT_PARAMS
)

class RLAStarWrapper(BasePathFinder):
    """基于astar_demo.py的RL-A*算法包装器"""
    
    def __init__(self, use_focus_learning: bool = True, verbose: bool = False):
        super().__init__()
        self.name = "RL-A*"
        self.use_focus_learning = use_focus_learning
        self.verbose = verbose
        
        # 直接绑定从本包导入的函数
        self.focus_predict_and_constrain = focus_predict_and_constrain
        self.search_with_decreasing_inflation = search_with_decreasing_inflation
        self.prune_path = prune_path
        self.smooth_path_with_bezier_adaptive = smooth_path_with_bezier_adaptive
        self.DEFAULT_PARAMS = DEFAULT_PARAMS

    def find_path(self, grid: np.ndarray, start: Tuple[int, int], 
                 goal: Tuple[int, int]) -> Dict[str, Any]:
        start_time = time.time()
        
        if not self._is_valid_cell(grid, start) or not self._is_valid_cell(grid, goal):
            return self._create_result([], 0, 0, False)
        
        try:
            # 运行RL-A*算法
            path, expanded_nodes, computation_time = self._rl_astar_search(
                grid, start, goal)
            # 保留原始离散网格路径（可能是 numpy array 或 list）以便记录 raw metrics
            raw_path = None
            try:
                raw_path = np.array(path) if path is not None else np.array([])
            except Exception:
                raw_path = np.array([])
            raw_cost, raw_steps = self._calculate_path_length(raw_path, return_steps=True) if raw_path.size>0 else (0.0, 0)
            
            success = len(path) > 0
            
            # 路径后处理（始终执行，恢复原始行为）
            smooth_applied = False
            smooth_path = None
            smooth_len = None
            if success and len(path) > 2:
                try:
                    pruned = self.prune_path(path, grid)
                    smooth_path = self.smooth_path_with_bezier_adaptive(pruned, grid)
                    # 替换返回路径为平滑后的连续路径
                    path = smooth_path
                    smooth_applied = True
                    try:
                        smooth_len = float(np.sum(np.linalg.norm(np.diff(smooth_path, axis=0), axis=1))) if smooth_path is not None and len(smooth_path) > 1 else 0.0
                    except Exception:
                        smooth_len = None
                except Exception as e:
                    if self.verbose:
                        print(f"路径后处理错误: {e}")
            
        
        except Exception as e:
            if self.verbose:
                print(f"RL-A*搜索错误: {e}")
            path, expanded_nodes = [], 0
            success = False
            computation_time = time.time() - start_time
            
        # 将 raw 与 smooth 信息作为 additional_info 返回，低侵入地扩展结果格式
        additional_info = {
            'raw_path': raw_path.tolist() if raw_path is not None and raw_path.size>0 else [],
            'raw_path_length': float(raw_cost) if raw_path is not None and raw_path.size>0 else 0.0,
            'raw_grid_steps': int(raw_steps) if raw_path is not None and raw_path.size>0 else 0,
            'smooth_applied': bool(smooth_applied),
            'smooth_path': smooth_path.tolist() if smooth_path is not None and getattr(smooth_path, 'size', 0)>0 else [],
            'smooth_length': float(smooth_len) if smooth_len is not None else None
        }

        return self._create_result(
            path=path,
            expanded_nodes=expanded_nodes,
            computation_time=computation_time,
            success=success,
            additional_info=additional_info
        )
    
    def _rl_astar_search(self, grid: np.ndarray, start: Tuple[int, int], 
                        goal: Tuple[int, int]) -> tuple:
        """基于astar_demo.py的RL-A*搜索实现"""
        
        # 参数预测和约束
        if self.use_focus_learning:
            try:
                meta_params, confidence_score, algorithm_name, run_features = \
                    self.focus_predict_and_constrain(grid, start, goal, verbose=self.verbose)
                complex_params = meta_params if meta_params is not None else self.DEFAULT_PARAMS
            except Exception as e:
                if self.verbose:
                    print(f"Focus Learning参数预测失败: {e}")
                complex_params = self.DEFAULT_PARAMS
        else:
            complex_params = self.DEFAULT_PARAMS
        
        # 递减膨胀半径搜索（恢复原始默认值）
        inflation_radius = 2
        path, expanded_order, used_radius, attempts, plan_time = \
            self.search_with_decreasing_inflation(
                grid, start, goal, inflation_radius, complex_params)

        # 计算扩展节点数：使用 expanded_order 中非零单元的去重计数
        try:
            if hasattr(expanded_order, 'size'):
                expanded_nodes = int((expanded_order > 0).sum())
            else:
                expanded_nodes = int(np.max(expanded_order)) if len(path) > 0 else 0
        except Exception:
            expanded_nodes = int(np.max(expanded_order)) if len(path) > 0 else 0

        return path, expanded_nodes, plan_time
    
    def _is_valid_cell(self, grid: np.ndarray, cell: Tuple[int, int]) -> bool:
        """检查单元格是否有效且可通行"""
        row, col = cell
        return (0 <= row < grid.shape[0] and 
                0 <= col < grid.shape[1] and 
                grid[row, col] == 0)