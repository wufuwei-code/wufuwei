import time
import heapq
import numpy as np
from typing import List, Tuple, Dict, Any
from .base import BasePathFinder


class AStarWrapper(BasePathFinder):
    """A*算法实现"""
    
    def __init__(self, heuristic_type: str = "euclidean", 
                 diagonal: bool = True):
        super().__init__()
        self.name = "A*"
        self.heuristic_type = heuristic_type
        self.diagonal = diagonal
        
    def find_path(self, grid: np.ndarray, start: Tuple[int, int], 
                 goal: Tuple[int, int]) -> Dict[str, Any]:
        start_time = time.time()
        
        # 验证输入
        if not self._is_valid_cell(grid, start) or not self._is_valid_cell(grid, goal):
            return self._create_result([], 0, 0, False)
        
        # A*搜索
        try:
            path, expanded_nodes = self._astar_search(grid, start, goal)
            success = len(path) > 0
        except Exception as e:
            print(f"A*搜索错误: {e}")
            path, expanded_nodes = [], 0
            success = False
            
        computation_time = time.time() - start_time
        
        return self._create_result(
            path=path,
            expanded_nodes=expanded_nodes,
            computation_time=computation_time,
            success=success
        )
    
    def _astar_search(self, grid: np.ndarray, start: Tuple[int, int], 
                     goal: Tuple[int, int]) -> tuple:
        """A*搜索算法实现"""
        open_set = []
        closed_set = set()
        # track unique expanded nodes explicitly for a consistent metric
        expanded_set = set()

        # 节点信息存储
        g_score = {start: 0}
        f_score = {start: self._heuristic(start, goal)}
        parent = {}

        heapq.heappush(open_set, (f_score[start], start))

        while open_set:
            current_f, current = heapq.heappop(open_set)

            if current in closed_set:
                # already expanded this node (duplicate in open list)
                continue

            if current == goal:
                # 重建路径
                path = self._reconstruct_path(parent, start, goal)
                return path, len(expanded_set)

            closed_set.add(current)
            expanded_set.add(current)

            for neighbor in self._get_neighbors(grid, current, self.diagonal):
                if neighbor in closed_set:
                    continue

                # 计算移动代价
                move_cost = 1.0
                if abs(neighbor[0] - current[0]) + abs(neighbor[1] - current[1]) == 2:
                    move_cost = np.sqrt(2)  # 对角线移动

                tentative_g = g_score[current] + move_cost

                if neighbor not in g_score or tentative_g < g_score[neighbor]:
                    # 发现更好路径
                    parent[neighbor] = current
                    g_score[neighbor] = tentative_g
                    f_score[neighbor] = tentative_g + self._heuristic(neighbor, goal)

                    # 如果邻居不在开放列表中，添加它
                    if not any(neighbor == item[1] for item in open_set):
                        heapq.heappush(open_set, (f_score[neighbor], neighbor))

        return [], len(expanded_set)  # 未找到路径
    
    def _heuristic(self, a: Tuple[int, int], b: Tuple[int, int]) -> float:
        """启发式函数"""
        if self.heuristic_type == "manhattan":
            return abs(a[0] - b[0]) + abs(a[1] - b[1])
        elif self.heuristic_type == "diagonal":
            dx = abs(a[0] - b[0])
            dy = abs(a[1] - b[1])
            return (dx + dy) + (np.sqrt(2) - 2) * min(dx, dy)
        else:  # euclidean
            return np.sqrt((a[0] - b[0])**2 + (a[1] - b[1])**2)
    
    def _reconstruct_path(self, parent: Dict, start: Tuple[int, int], 
                         goal: Tuple[int, int]) -> List[Tuple[int, int]]:
        """重建路径"""
        path = [goal]
        current = goal
        
        while current != start:
            if current not in parent:
                return []  # 路径不完整
            current = parent[current]
            path.append(current)
            
        path.reverse()
        return path