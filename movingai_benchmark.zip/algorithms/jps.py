import time
import heapq
import numpy as np
from typing import List, Tuple, Dict, Any, Optional
from .base import BasePathFinder


class JPSWrapper(BasePathFinder):
    """Jump Point Search算法实现"""
    
    def __init__(self):
        super().__init__()
        self.name = "JPS"
        
    def find_path(self, grid: np.ndarray, start: Tuple[int, int], 
                 goal: Tuple[int, int]) -> Dict[str, Any]:
        start_time = time.time()
        
        if not self._is_valid_cell(grid, start) or not self._is_valid_cell(grid, goal):
            return self._create_result([], 0, 0, False)
        
        try:
            path, expanded_nodes = self._jps_search(grid, start, goal)
            success = len(path) > 0
        except Exception as e:
            print(f"JPS搜索错误: {e}")
            path, expanded_nodes = [], 0
            success = False
            
        computation_time = time.time() - start_time
        
        return self._create_result(
            path=path,
            expanded_nodes=expanded_nodes,
            computation_time=computation_time,
            success=success
        )
    
    def _jps_search(self, grid: np.ndarray, start: Tuple[int, int], 
                   goal: Tuple[int, int]) -> tuple:
        """JPS搜索算法实现"""
        open_set = []
        closed_set = set()
        expanded_set = set()

        g_score = {start: 0}
        parent = {}

        heapq.heappush(open_set, (self._heuristic(start, goal), start))

        while open_set:
            current_f, current = heapq.heappop(open_set)

            if current in closed_set:
                continue

            if current == goal:
                path = self._reconstruct_path(parent, start, goal)
                return path, len(expanded_set)

            closed_set.add(current)
            expanded_set.add(current)
            
            # 获取跳跃点
            for neighbor in self._get_neighbors(grid, current, parent.get(current)):
                jump_point = self._jump(grid, current, neighbor, goal)
                
                if jump_point and jump_point not in closed_set:
                    move_cost = self._distance(current, jump_point)
                    tentative_g = g_score[current] + move_cost
                    
                    if jump_point not in g_score or tentative_g < g_score[jump_point]:
                        g_score[jump_point] = tentative_g
                        f_score = tentative_g + self._heuristic(jump_point, goal)
                        parent[jump_point] = current
                        
                        heapq.heappush(open_set, (f_score, jump_point))
        
        return [], len(expanded_set)
    
    def _get_neighbors(self, grid: np.ndarray, node: Tuple[int, int], 
                      parent: Optional[Tuple[int, int]] = None) -> List[Tuple[int, int]]:
        """JPS特定的邻居获取"""
        if parent is None:
            # 起始节点，返回所有方向
            return super()._get_neighbors(grid, node, True)
            
        # 计算强制邻居
        neighbors = []
        dx = node[0] - parent[0]
        dy = node[1] - parent[1]
        
        # 标准化方向
        dx = 0 if dx == 0 else dx // abs(dx)
        dy = 0 if dy == 0 else dy // abs(dy)
        
        # 对角线移动
        if dx != 0 and dy != 0:
            # 水平方向
            if self._is_valid_cell(grid, (node[0] + dx, node[1])):
                neighbors.append((node[0] + dx, node[1]))
            # 垂直方向
            if self._is_valid_cell(grid, (node[0], node[1] + dy)):
                neighbors.append((node[0], node[1] + dy))
            # 对角线方向
            if (self._is_valid_cell(grid, (node[0] + dx, node[1])) or 
                self._is_valid_cell(grid, (node[0], node[1] + dy))):
                if self._is_valid_cell(grid, (node[0] + dx, node[1] + dy)):
                    neighbors.append((node[0] + dx, node[1] + dy))
        else:
            # 直线移动
            if dx == 0:  # 垂直移动
                if self._is_valid_cell(grid, (node[0], node[1] + dy)):
                    neighbors.append((node[0], node[1] + dy))
                # 强制邻居检查
                if not self._is_valid_cell(grid, (node[0] + 1, node[1])):
                    if self._is_valid_cell(grid, (node[0] + 1, node[1] + dy)):
                        neighbors.append((node[0] + 1, node[1] + dy))
                if not self._is_valid_cell(grid, (node[0] - 1, node[1])):
                    if self._is_valid_cell(grid, (node[0] - 1, node[1] + dy)):
                        neighbors.append((node[0] - 1, node[1] + dy))
            else:  # 水平移动
                if self._is_valid_cell(grid, (node[0] + dx, node[1])):
                    neighbors.append((node[0] + dx, node[1]))
                # 强制邻居检查
                if not self._is_valid_cell(grid, (node[0], node[1] + 1)):
                    if self._is_valid_cell(grid, (node[0] + dx, node[1] + 1)):
                        neighbors.append((node[0] + dx, node[1] + 1))
                if not self._is_valid_cell(grid, (node[0], node[1] - 1)):
                    if self._is_valid_cell(grid, (node[0] + dx, node[1] - 1)):
                        neighbors.append((node[0] + dx, node[1] - 1))
                        
        return neighbors
    
    def _jump(self, grid: np.ndarray, from_node: Tuple[int, int], 
             direction: Tuple[int, int], goal: Tuple[int, int]) -> Optional[Tuple[int, int]]:
        """跳跃函数"""
        current = (from_node[0] + direction[0], from_node[1] + direction[1])
        
        if not self._is_valid_cell(grid, current):
            return None
            
        if current == goal:
            return current
            
        # 检查强制邻居
        dx, dy = direction
        
        # 对角线跳跃
        if dx != 0 and dy != 0:
            if (self._jump(grid, current, (dx, 0), goal) is not None or
                self._jump(grid, current, (0, dy), goal) is not None):
                return current
                
        # 继续跳跃
        return self._jump(grid, current, direction, goal)
    
    def _distance(self, a: Tuple[int, int], b: Tuple[int, int]) -> float:
        """计算距离"""
        dx = a[0] - b[0]
        dy = a[1] - b[1]
        return np.sqrt(dx*dx + dy*dy)
    
    def _heuristic(self, a: Tuple[int, int], b: Tuple[int, int]) -> float:
        """启发式函数"""
        return self._distance(a, b)
    
    def _reconstruct_path(self, parent: Dict, start: Tuple[int, int], 
                         goal: Tuple[int, int]) -> List[Tuple[int, int]]:
        """重建路径"""
        path = [goal]
        current = goal
        
        while current != start:
            if current not in parent:
                return []
            current = parent[current]
            path.append(current)
            
        path.reverse()
        return path