import numpy as np
import matplotlib.pyplot as plt
from scipy.ndimage import distance_transform_edt
import heapq
import time
import math
from collections import deque
import argparse

try:
    from meta.map_features import extract_map_features
    from meta.meta_controller import MetaController
    from test_focus_model import EnhancedModelLoader
    from parameter_validation_optimized import validate_parameters_optimized, get_confidence_score_optimized
    from failure_analysis import ANALYZER
    FOCUS_AVAILABLE = True
    CONSTRAINT_AVAILABLE = True
except Exception:
    FOCUS_AVAILABLE = False
    CONSTRAINT_AVAILABLE = False

# 配置常量
DEFAULT_PARAMS = {
    'initial_weight': 1.5, 'lambda_risk': 1.0, 'lambda_smooth': 0.5,
    'lambda_bonus': 0.3, 'frontier_radius': 4, 'recent_visited_len': 30,
    'curvature_window': 3, 'risk_power': 1.0, 'min_weight': 1.0
}

CONSERVATIVE_PARAMS = {
    'initial_weight': 39.5, 'lambda_risk': 2.52, 'lambda_smooth': 1.53,
    'frontier_radius': 3, 'recent_visited_len': 25
}

MODEL_PATHS = [
    ('meta/models/focus_large_data.pkl', 'meta/models/meta_scaler_enhanced_focus.npz')
]

def prepare_random_map(rows=80, cols=80, obstacle_ratio=0.30, seed=2):
    map_grid = np.zeros((rows, cols))
    np.random.seed(seed)
    obstacle_idx = np.random.rand(rows, cols) < obstacle_ratio
    map_grid[obstacle_idx] = 1
    start = (0, 0)
    goal = (rows - 1, cols - 1)
    map_grid[start] = 0
    map_grid[goal] = 0
    return map_grid, start, goal

def focus_predict_and_constrain(map_grid, start, goal, verbose=True):
    meta_params = None
    algorithm_name = "Focus Learning Enhanced A*"
    confidence_score = 1.0
    run_features = None

    if not FOCUS_AVAILABLE:
        if verbose:
            print("[Focus Learning] 模块不可用，使用默认参数...")
        return None, confidence_score, "Traditional A* (No ML)", None
    if verbose:
        print("[Focus Learning] 加载增强模型...")
    try:
        focus_controller, error = load_focus_model()
        if focus_controller is None:
            raise Exception(error)

        params = predict_parameters(focus_controller, map_grid, start, goal)
        # 统一特征提取
        try:
            run_features = ANALYZER.extract_features(map_grid, start, goal)
        except Exception:
            run_features = None

        meta_params, confidence_score = apply_intelligent_constraints(params, verbose=verbose)
        if verbose:
            print("[Focus Learning] 最终使用的参数:")
            for k, v in meta_params.items():
                if k != 'min_weight':
                    print(f"   {k}: {v:.3f}")
            if CONSTRAINT_AVAILABLE:
                expected_success_rate = min(0.95, 0.4 + confidence_score * 0.6)
                print(f"[Focus Learning] 预估成功率: {expected_success_rate:.1%}")
    except Exception as e:
        if verbose:
            print(f"[Focus Learning] 模型加载失败: {e}")
            print("[Focus Learning] 使用默认参数进行搜索...")
        algorithm_name = "Traditional A* (Fallback)"
    return meta_params, confidence_score, algorithm_name, run_features

def search_with_decreasing_inflation(map_grid, start, goal, inflation_radius, complex_params):
    """从指定膨胀半径递减，找到第一条路径。返回 (path, expanded_order, used_radius, attempts, plan_time)."""
    rows, cols = map_grid.shape
    used_radius = -1
    path = []
    expanded_order = np.zeros((rows, cols))
    tic = time.time()
    attempts = 0
    for r in range(inflation_radius, -1, -1):
        attempts += 1
        inflated_map = inflate_map(map_grid, r)
        inflated_map[start] = 0
        inflated_map[goal] = 0
        path_tmp, expanded_tmp = astar_hierarchical_hybrid(inflated_map, start, goal, complex_params)
        # 避免对 numpy array 使用模糊布尔判断（The truth value of an array ...）
        if path_tmp is not None and len(path_tmp) > 0:
            path = np.array(path_tmp)
            expanded_order = expanded_tmp
            used_radius = r
            break
    plan_time = time.time() - tic
    return path, expanded_order, used_radius, attempts, plan_time

def log_run_safe(verbose, **kwargs):
    try:
        ANALYZER.log_run(**kwargs)
        if verbose:
            print('[FailureAnalysis] 已记录成功案例。' if kwargs.get('outcome') == 'success' else '[FailureAnalysis] 已记录失败案例。')
    except Exception as e:
        if verbose:
            tag = '成功案例' if kwargs.get('outcome') == 'success' else '失败'
            print(f'[FailureAnalysis] 记录{tag}失败: {e}')

def report_path_stats(path, smooth_path, algorithm_name, complex_params, plan_time, expanded_order, verbose=True):
    original_len = np.sum(np.linalg.norm(np.diff(path, axis=0), axis=1))
    smooth_len = np.sum(np.linalg.norm(np.diff(smooth_path, axis=0), axis=1))
    used_weight = complex_params.get('initial_weight', DEFAULT_PARAMS['initial_weight'])
    length_diff = smooth_len - original_len
    expanded_nodes = int(np.max(expanded_order))

    if verbose:
        print('A path has been found!')
        print(f"Search algorithm: {algorithm_name} (Initial Weight: {used_weight:.2f})")
    # 核心五行
    print(f'Original path length: {original_len:.6f}')
    print(f'Smooth path length: {smooth_len:.6f}')
    print(f'Length difference: {length_diff:.6f} ({(length_diff / original_len * 100):.2f}%)')
    print(f'The time of path planning is {plan_time:.6f} s')
    print(f'The number of expanded grid is {expanded_nodes}')
    return original_len, smooth_len, expanded_nodes

def visualize_result(map_grid, path, smooth_path, start, goal, algorithm_name, used_weight, expanded_order):
    rows, cols = map_grid.shape
    fig, ax = plt.subplots()
    ax.set_aspect('equal')
    display_map = np.ones((rows, cols, 3))
    display_map[map_grid == 1] = [0, 0, 0]
    display_map[expanded_order > 0] = [1, 0, 0]
    ax.imshow(display_map, origin='lower', extent=[-0.5, cols-0.5, -0.5, rows-0.5], interpolation='nearest')
    ax.set_xticks(np.arange(-0.5, cols, 1), minor=True)
    ax.set_yticks(np.arange(-0.5, rows, 1), minor=True)
    ax.grid(which='minor', color='k', linestyle='-', linewidth=0.5)
    ax.tick_params(which='major', bottom=False, left=False, labelbottom=False, labelleft=False)
    original_path_length = np.sum(np.linalg.norm(np.diff(path, axis=0), axis=1))
    smooth_path_length = np.sum(np.linalg.norm(np.diff(smooth_path, axis=0), axis=1))
    ax.plot(path[:, 1], path[:, 0], '--', color='white', linewidth=1.0, label=f'Original ({original_path_length:.2f})')
    ax.plot(smooth_path[:, 1], smooth_path[:, 0], color='white', linewidth=1.5, label=f'Smooth ({smooth_path_length:.2f})')
    ax.plot(start[1], start[0], 'go', markersize=10, label='Start')
    ax.plot(goal[1], goal[0], 'ys', markersize=10, label='Goal')
    ax.set_title(f'Path Planning: {algorithm_name} (initial_w={used_weight:.1f})')
    ax.legend(loc='best')
    plt.show()

def load_focus_model(verbose=False):
    if not FOCUS_AVAILABLE:
        return None, "Focus Learning 模块不可用"
    
    loader = EnhancedModelLoader()
    
    for model_path, scaler_path in MODEL_PATHS:
        try:
            if model_path.endswith('.pkl'):
                controller = loader.load_enhanced_model(model_path, scaler_path)
            else:
                controller = EnhancedModelLoader.load_enhanced_model(
                    model_path, scaler_path, use_multi_head=False
                )
            if verbose:
                print(f"[Focus Learning] 成功加载模型: {model_path}")
            return controller, None
        except Exception as e:
            if verbose:
                print(f"[Focus Learning] 尝试加载 {model_path} 失败: {e}")
            continue
    
    return None, "所有Focus模型加载失败"

def predict_parameters(controller, map_grid, start, goal):
    feats = extract_map_features(map_grid, start, goal)
    
    if hasattr(controller, 'predict_parameters'):
        return controller.predict_parameters(feats, mode='focus')
    elif hasattr(controller, 'get_params'):
        return controller.get_params(feats)
    else:
        # 兼容性处理
        temp_controller = MetaController(use_mlp=True, delta_mode=True)
        temp_controller.model = controller.model
        temp_controller.scaler_mean = controller.scaler_mean
        temp_controller.scaler_std = controller.scaler_std
        temp_controller.trained_delta_flag = getattr(controller, 'trained_delta_flag', True)
        return temp_controller.get_params(feats)

def apply_intelligent_constraints(params, verbose=False):
    if not CONSTRAINT_AVAILABLE:
        return params, 1.0
    
    if verbose:
        print("[智能约束] 验证参数合理性...")
    validated_params, violations = validate_parameters_optimized(params)
    confidence_score = get_confidence_score_optimized(validated_params)
    
    if violations and verbose:
        print("[智能约束] 参数调整:")
        for violation in violations:
            print(f"   {violation}")
    
    if verbose:
        print(f"[智能约束] 参数置信度: {confidence_score:.2f}")
    
    # 低置信度保守策略
    if confidence_score < 0.4:
        if verbose:
            print("[智能约束] 置信度过低，采用保守参数...")
        validated_params.update(CONSERVATIVE_PARAMS)
        confidence_score = get_confidence_score_optimized(validated_params)
        if verbose:
            print(f"[智能约束] 保守策略置信度: {confidence_score:.2f}")
    
    return validated_params, confidence_score

def astar_demo(verbose=False, show_plot=False):
    # 1. 生成随机地图
    map_grid, start, goal = prepare_random_map()
    rows, cols = map_grid.shape
    inflation_radius = 2

    # 2. Focus 预测 + 约束
    meta_params, confidence_score, algorithm_name, run_features = focus_predict_and_constrain(map_grid, start, goal, verbose=verbose)

    # 3. 膨胀半径递减搜索
    complex_params = meta_params if meta_params is not None else DEFAULT_PARAMS
    path, expanded_order, used_radius, attempts, plan_time = search_with_decreasing_inflation(
        map_grid, start, goal, inflation_radius, complex_params
    )

    if len(path) == 0:
        if verbose:
            print('在所有膨胀半径下均未找到路径。')
        log_run_safe(verbose,
            map_grid=map_grid,
            start=start,
            goal=goal,
            features=run_features if run_features is not None else [],
            predicted_params=meta_params if meta_params is not None else DEFAULT_PARAMS,
            confidence_score=confidence_score,
            outcome='failure',
            expanded_nodes=int(np.max(expanded_order)),
            plan_time=plan_time,
            path_length=None,
            smooth_path_length=None,
            inflation_radius_used=used_radius,
            num_inflation_attempts=attempts,
            reason='路径搜索失败',
            notes=None
        )
        raise Exception('请调整障碍/起终点或减小障碍密度。')

    if verbose:
        if used_radius != inflation_radius:
            print(f'膨胀半径从 {inflation_radius} 降为 {used_radius} 才找到路径（避免堵死通道）。')
        else:
            print(f'在膨胀半径 {used_radius} 下找到路径。')

    # 4. 路径剪枝 + 平滑
    path = prune_path(path, map_grid)
    smooth_path = smooth_path_with_bezier_adaptive(path, map_grid)

    # 5. 打印结果
    original_len, smooth_len, expanded_nodes = report_path_stats(
        path, smooth_path, algorithm_name, complex_params, plan_time, expanded_order, verbose=verbose
    )

    # 6. 记录成功案例
    log_run_safe(verbose,
        map_grid=map_grid,
        start=start,
        goal=goal,
        features=run_features if run_features is not None else [],
        predicted_params=meta_params if meta_params is not None else DEFAULT_PARAMS,
        confidence_score=confidence_score,
        outcome='success',
        expanded_nodes=expanded_nodes,
        plan_time=plan_time,
        path_length=original_len,
        smooth_path_length=smooth_len,
        inflation_radius_used=used_radius,
        num_inflation_attempts=attempts,
        reason=None,
        notes=None
    )

    # 7. 可视化
    used_weight = complex_params.get('initial_weight', DEFAULT_PARAMS['initial_weight'])
    if show_plot:
        visualize_result(map_grid, path, smooth_path, start, goal, algorithm_name, used_weight, expanded_order)

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument('--verbose', action='store_true', help='输出调试与模型加载信息')
    p.add_argument('--plot', action='store_true', help='显示可视化')
    return p.parse_args()


# ====== 辅助函数定义 ======

## 已移除未被调用的 astar_dynamic_weighting (保持仓库整洁)

def astar_hierarchical_hybrid(map_grid, start, goal, params):
    rows, cols = map_grid.shape
    expanded_order = np.zeros_like(map_grid, dtype=int)
    order_count = 0

    # 预计算欧氏启发
    goal_r, goal_c = goal
    c_idx, r_idx = np.meshgrid(np.arange(cols), np.arange(rows))
    h_euclid = np.hypot(r_idx - goal_r, c_idx - goal_c)
    dist_start_to_goal = h_euclid[start]

    # 安全距离场 (用于风险估计)
    edt = distance_transform_edt(1 - map_grid)  # 障碍为0, free为1 -> 1-map_grid: 障碍为1
    # 风险 R = (max_edt - edt)/max_edt  -> 障碍附近高风险, 再指数放大
    max_edt = np.max(edt) if np.max(edt) > 0 else 1
    base_risk = (max_edt - edt) / max_edt
    risk_power = params.get('risk_power', 1.0)
    risk_field = base_risk ** risk_power

    # g cost 初始化
    g_cost = np.full((rows, cols), np.inf)
    g_cost[start] = 0

    parent = {start: start}
    open_list = []
    open_best = {}

    recent_queue = deque(maxlen=params.get('recent_visited_len', 50))
    frontier_radius = params.get('frontier_radius', 4)
    curvature_window = params.get('curvature_window', 3)

    lambda_r = params.get('lambda_risk', 1.0)
    lambda_s_base = params.get('lambda_smooth', 0.3)
    lambda_b_base = params.get('lambda_bonus', 0.5)
    initial_weight = params.get('initial_weight', 5.0)
    min_weight = params.get('min_weight', 1.0)

    def local_frontier_bonus(r, c):
        r0 = max(0, r - frontier_radius); r1 = min(rows, r + frontier_radius + 1)
        c0 = max(0, c - frontier_radius); c1 = min(cols, c + frontier_radius + 1)
        sub_exp = expanded_order[r0:r1, c0:c1]
        sub_occ = map_grid[r0:r1, c0:c1]
        if sub_exp.size == 0:
            return 0.0
        free_mask = (sub_occ == 0)
        total_free = free_mask.sum()
        if total_free == 0:
            return 0.0
        unexplored_free = ((sub_exp == 0) & free_mask).sum()
        ratio_unexp = unexplored_free / total_free
        # 周界统计：直接遍历子窗口边缘
        boundary_unexplored = 0
        # top & bottom rows
        for cc in range(c0, c1):
            # top
            rr = r0
            if map_grid[rr, cc] == 0 and expanded_order[rr, cc] == 0:
                boundary_unexplored += 1
            # bottom
            rr2 = r1 - 1
            if rr2 != rr and map_grid[rr2, cc] == 0 and expanded_order[rr2, cc] == 0:
                boundary_unexplored += 1
        # left & right cols
        for rr in range(r0+1, r1-1):
            cc = c0
            if map_grid[rr, cc] == 0 and expanded_order[rr, cc] == 0:
                boundary_unexplored += 1
            cc2 = c1 - 1
            if cc2 != cc and map_grid[rr, cc2] == 0 and expanded_order[rr, cc2] == 0:
                boundary_unexplored += 1
        perimeter_free = max(1, 2*(c1-c0) + 2*max(0, (r1-r0-2)))  # 估算可用自由边长, 防止除0
        info_gain = boundary_unexplored / perimeter_free
        return 0.6 * ratio_unexp + 0.4 * info_gain

    def curvature_penalty(node):
        # 基于最近路径方向变化估计局部曲率
        if len(recent_queue) < curvature_window + 2:
            return 0
        pts = list(recent_queue)[- (curvature_window + 2):] + [node]
        dirs = []
        for i in range(1, len(pts)):
            v = (pts[i][0]-pts[i-1][0], pts[i][1]-pts[i-1][1])
            norm = math.hypot(*v)
            if norm == 0: continue
            dirs.append((v[0]/norm, v[1]/norm))
        if len(dirs) < 2:
            return 0
        angles = 0
        for i in range(1, len(dirs)):
            d1 = dirs[i-1]; d2 = dirs[i]
            dp = max(-1.0, min(1.0, d1[0]*d2[0] + d1[1]*d2[1]))
            ang = math.acos(dp)
            angles += ang**2
        return angles / len(dirs)

    def local_density(r, c, rad=2):
        r0 = max(0, r-rad); r1 = min(rows, r+rad+1)
        c0 = max(0, c-rad); c1 = min(cols, c+rad+1)
        region = map_grid[r0:r1, c0:c1]
        return region.mean() if region.size>0 else 0

    start_weight = initial_weight
    start_f = g_cost[start] + start_weight * h_euclid[start]
    heapq.heappush(open_list, (start_f, start))
    open_best[start] = start_f

    while open_list:
        f_cur, current = heapq.heappop(open_list)
        if current not in open_best or f_cur > open_best[current]:
            continue
        del open_best[current]

        r, c = current
        order_count += 1
        expanded_order[r, c] = order_count
        recent_queue.append(current)

        if current == goal:
            return reconstruct_path(parent, start, goal), expanded_order

        # 动态权重随进展线性下降
        dist_remain = h_euclid[current]
        if dist_start_to_goal > 0:
            W = min_weight + (initial_weight - min_weight) * (dist_remain / dist_start_to_goal)
        else:
            W = min_weight

        # 自适应 λ_s, λ_b: 局部密度越大 -> 平滑度更重要, 探索奖励下降
        dens = local_density(r, c)
        lambda_s = lambda_s_base * (1 + dens)
        lambda_b = lambda_b_base * (1 - 0.5*dens)

        for dr in range(-1, 2):
            for dc in range(-1, 2):
                if dr == 0 and dc == 0:
                    continue
                nr, nc = r + dr, c + dc
                if not (0 <= nr < rows and 0 <= nc < cols):
                    continue
                if map_grid[nr, nc] == 1:
                    continue
                if dr != 0 and dc != 0:
                    # 对角线穿越障碍拦截
                    if map_grid[r, nc] == 1 or map_grid[nr, c] == 1:
                        continue

                step = math.hypot(dr, dc)
                tentative_g = g_cost[current] + step
                if tentative_g >= g_cost[nr, nc]:
                    continue

                # 启发: 分层混合 h_ms = α * h_global + (1-α) * h_local
                # h_local: 在frontier窗口内对 goal 方向约束 (向量投影) 近似: remaining dist - 方向增益
                h_global = h_euclid[nr, nc]
                vec_to_goal = (goal_r - nr, goal_c - nc)
                norm_v = math.hypot(*vec_to_goal)
                if norm_v == 0:
                    dir_goal = (0,0)
                else:
                    dir_goal = (vec_to_goal[0]/norm_v, vec_to_goal[1]/norm_v)
                move_dir = (dr/step, dc/step) if step>0 else (0,0)
                alignment = move_dir[0]*dir_goal[0] + move_dir[1]*dir_goal[1]
                h_local = h_global * (1 - 0.3*alignment)  # 朝向目标的对齐减少局部启发
                alpha = 0.7
                h_ms = alpha * h_global + (1-alpha) * h_local

                # 风险
                risk_val = risk_field[nr, nc]
                # 曲率: 预测加入该节点后的局部曲率
                curve = curvature_penalty((nr, nc))
                # 探索奖励
                bonus = local_frontier_bonus(nr, nc)

                f_candidate = tentative_g + W * h_ms + lambda_r * risk_val + lambda_s * curve - lambda_b * bonus

                g_cost[nr, nc] = tentative_g
                parent[(nr, nc)] = current
                heapq.heappush(open_list, (f_candidate, (nr, nc)))
                open_best[(nr, nc)] = f_candidate

    return [], expanded_order

def is_strict_line_clear(p1, p2, map_grid):
    rows, cols = map_grid.shape
    dist = np.hypot(p2[0] - p1[0], p2[1] - p1[1])
    num_points = max(math.ceil(dist * 10), 5)
    
    x = np.linspace(p1[1], p2[1], num_points)
    y = np.linspace(p1[0], p2[0], num_points)

    safety_dist = 0.75

    for i in range(num_points):
        py, px = y[i], x[i]
        
        r, c = round(py), round(px)
        
        if not (0 <= r < rows and 0 <= c < cols):
            return False
        
        # 检查周围九宫格
        for dr in range(-1, 2):
            for dc in range(-1, 2):
                check_r, check_c = r + dr, c + dc
                if 0 <= check_r < rows and 0 <= check_c < cols:
                    if map_grid[check_r, check_c] == 1:
                        dist_to_obstacle = np.hypot(py - check_r, px - check_c)
                        if dist_to_obstacle < safety_dist:
                            return False
    return True

def reconstruct_path(parent_map, start, goal):
    """从 parent_map 重建路径"""
    path = [goal]
    pos = goal
    while pos != start:
        pos = parent_map.get(pos)
        if pos is None:
            return [] # 路径中断
        path.append(pos)
    path.reverse()
    return path

def inflate_map(map_grid, radius):
    if radius <= 0:
        return map_grid.copy()
    # bwdist(map) <= radius 等价于 distance_transform_edt(1-map) <= radius
    return distance_transform_edt(1 - map_grid) <= radius

def calculate_local_density(point, map_grid, radius):
    """计算局部障碍物密度"""
    rows, cols = map_grid.shape
    r, c = round(point[0]), round(point[1])
    
    r_start = max(0, r - radius)
    r_end = min(rows, r + radius + 1)
    c_start = max(0, c - radius)
    c_end = min(cols, c + radius + 1)
    
    sub_map = map_grid[r_start:r_end, c_start:c_end]
    if sub_map.size == 0:
        return 0
    
    return np.sum(sub_map) / sub_map.size

def prune_path(path, map_grid):
    if len(path) < 3:
        return path
    
    pruned_path = [path[0]]
    current_idx = 0
    
    while current_idx < len(path) - 1:
        last_visible_idx = -1
        for lookahead_idx in range(len(path) - 1, current_idx, -1):
            if is_strict_line_clear(tuple(path[current_idx]), tuple(path[lookahead_idx]), map_grid):
                last_visible_idx = lookahead_idx
                break
        
        if last_visible_idx != -1:
            pruned_path.append(path[last_visible_idx])
            current_idx = last_visible_idx
        else:
            pruned_path.append(path[current_idx + 1])
            current_idx += 1
            
    return np.array(pruned_path)

def smooth_path_with_bezier_adaptive(path, map_grid):
    if len(path) < 3:
        return path
    
    corner_indices = find_corners(path)
    if not corner_indices:
        return path
    
    smoothed_path_segments = []
    current_idx = 0
    
    path_list = path.tolist()

    for corner_idx in corner_indices:
        if corner_idx > current_idx:
            smoothed_path_segments.extend(path_list[current_idx:corner_idx])
        
        if 0 < corner_idx < len(path) - 1:
            local_density = calculate_local_density(path[corner_idx], map_grid, 3)
            adaptive_smoothness = 0.7 * (1 - local_density)
            
            bezier_segment = create_bezier_corner_adaptive(path, corner_idx, adaptive_smoothness, map_grid)
            if bezier_segment.any():
                smoothed_path_segments.extend(bezier_segment.tolist())
            else:
                smoothed_path_segments.append(path_list[corner_idx])
        else:
             smoothed_path_segments.append(path_list[corner_idx])

        current_idx = corner_idx + 1

    if current_idx < len(path):
        smoothed_path_segments.extend(path_list[current_idx:])
        
    return remove_duplicate_points(np.array(smoothed_path_segments))

def find_corners(path):
    corners = []
    if len(path) < 3:
        return corners
    
    for i in range(1, len(path) - 1):
        v1 = path[i] - path[i-1]
        v2 = path[i+1] - path[i]
        
        norm_v1 = np.linalg.norm(v1)
        norm_v2 = np.linalg.norm(v2)
        
        if norm_v1 > 0 and norm_v2 > 0:
            dot_product = np.dot(v1 / norm_v1, v2 / norm_v2)
            dot_product = np.clip(dot_product, -1.0, 1.0)
            angle = np.arccos(dot_product)
            
            if angle > np.pi / 8: # 22.5度阈值
                corners.append(i)
    return corners

def create_bezier_corner_adaptive(path, corner_idx, smoothness, map_grid):
    if not (0 < corner_idx < len(path) - 1):
        return np.array([])
        
    p0 = path[corner_idx - 1]
    p1 = path[corner_idx]
    p2 = path[corner_idx + 1]
    
    d1 = np.linalg.norm(p1 - p0)
    d2 = np.linalg.norm(p2 - p1)
    min_dist = min(d1, d2) * smoothness
    
    dir1 = (p1 - p0) / d1 if d1 > 0 else np.array([0, 0])
    dir2 = (p2 - p1) / d2 if d2 > 0 else np.array([0, 0])
    
    cp0 = p1 - dir1 * min_dist
    cp1 = p1 + dir2 * min_dist
    
    num_points = max(10, math.ceil(min_dist * 5))
    t = np.linspace(0, 1, num_points)[:, np.newaxis]
    
    # 二次贝塞尔曲线
    bezier_points = (1-t)**2 * cp0 + 2*(1-t)*t * p1 + t**2 * cp1
    
    if check_path_collision(bezier_points, map_grid):
        return np.array([])
        
    return bezier_points

def check_path_collision(path_points, map_grid):
    rows, cols = map_grid.shape
    safety_dist = 0.75

    for point in path_points:
        py, px = point
        if not (0 <= py < rows and 0 <= px < cols):
            return True
            
        r, c = round(py), round(px)
        
        for dr in range(-1, 2):
            for dc in range(-1, 2):
                check_r, check_c = r + dr, c + dc
                if 0 <= check_r < rows and 0 <= check_c < cols:
                    if map_grid[check_r, check_c] == 1:
                        dist_to_obstacle = np.hypot(py - check_r, px - check_c)
                        if dist_to_obstacle < safety_dist:
                            return True
    return False

def remove_duplicate_points(path):
    if len(path) <= 1:
        return path
        
    clean_path = [path[0]]
    tolerance = 0.1
    
    for i in range(1, len(path)):
        if np.linalg.norm(path[i] - clean_path[-1]) > tolerance:
            clean_path.append(path[i])
            
    return np.array(clean_path)


if __name__ == '__main__':
    args = parse_args()
    astar_demo(verbose=args.verbose, show_plot=args.plot)