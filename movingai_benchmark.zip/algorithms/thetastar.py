import time
import heapq
import numpy as np
from typing import List, Tuple, Dict, Any
from .base import BasePathFinder


class ThetaStarWrapper(BasePathFinder):
    """Theta*算法实现"""
    
    def __init__(self):
        super().__init__()
        self.name = "Theta*"
        
    def find_path(self, grid: np.ndarray, start: Tuple[int, int], 
                 goal: Tuple[int, int]) -> Dict[str, Any]:
        start_time = time.time()
        
        if not self._is_valid_cell(grid, start) or not self._is_valid_cell(grid, goal):
            return self._create_result([], 0, 0, False)
        
        try:
            path, expanded_nodes = self._thetastar_search(grid, start, goal)
            success = len(path) > 0
        except Exception as e:
            print(f"Theta*搜索错误: {e}")
            path, expanded_nodes = [], 0
            success = False
            
        computation_time = time.time() - start_time
        
        return self._create_result(
            path=path,
            expanded_nodes=expanded_nodes,
            computation_time=computation_time,
            success=success
        )
    
    def _thetastar_search(self, grid: np.ndarray, start: Tuple[int, int], 
                         goal: Tuple[int, int]) -> tuple:
        """Theta*搜索算法实现"""
        open_set = []
        closed_set = set()
        expanded_set = set()

        g_score = {start: 0}
        parent = {start: start}

        heapq.heappush(open_set, (self._heuristic(start, goal), start))

        while open_set:
            current_f, current = heapq.heappop(open_set)

            if current in closed_set:
                continue

            if current == goal:
                path = self._reconstruct_path(parent, start, goal)
                return path, len(expanded_set)

            closed_set.add(current)
            expanded_set.add(current)

            for neighbor in self._get_neighbors(grid, current, True):
                if neighbor in closed_set:
                    continue
                    
                # Theta*关键步骤: 视线检查
                if parent[current] != current and self._line_of_sight(grid, parent[current], neighbor):
                    # 路径2: 从祖父节点到邻居
                    move_cost = self._distance(parent[current], neighbor)
                    tentative_g = g_score[parent[current]] + move_cost
                else:
                    # 路径1: 从当前节点到邻居
                    move_cost = self._distance(current, neighbor)
                    tentative_g = g_score[current] + move_cost
                    
                if neighbor not in g_score or tentative_g < g_score[neighbor]:
                    g_score[neighbor] = tentative_g
                    f_score = tentative_g + self._heuristic(neighbor, goal)
                    
                    if tentative_g == g_score[current] + move_cost:
                        parent[neighbor] = current
                    else:
                        parent[neighbor] = parent[current]
                        
                    # 更新开放列表
                    for i, (f, node) in enumerate(open_set):
                        if node == neighbor:
                            open_set[i] = (f_score, neighbor)
                            heapq.heapify(open_set)
                            break
                    else:
                        heapq.heappush(open_set, (f_score, neighbor))
        
        return [], len(expanded_set)
    
    def _line_of_sight(self, grid: np.ndarray, start: Tuple[int, int], 
                      end: Tuple[int, int]) -> bool:
        """视线检查"""
        x0, y0 = start
        x1, y1 = end
        
        dx = abs(x1 - x0)
        dy = abs(y1 - y0)
        x = x0
        y = y0
        n = 1 + dx + dy
        x_inc = 1 if x1 > x0 else -1
        y_inc = 1 if y1 > y0 else -1
        error = dx - dy
        dx *= 2
        dy *= 2
        
        for _ in range(n):
            if not self._is_valid_cell(grid, (x, y)):
                return False
                
            if error > 0:
                x += x_inc
                error -= dy
            else:
                y += y_inc
                error += dx
                
        return True
    
    def _distance(self, a: Tuple[int, int], b: Tuple[int, int]) -> float:
        """计算两点间距离"""
        dx = a[0] - b[0]
        dy = a[1] - b[1]
        return np.sqrt(dx*dx + dy*dy)
    
    def _heuristic(self, a: Tuple[int, int], b: Tuple[int, int]) -> float:
        """启发式函数"""
        return self._distance(a, b)
    
    def _reconstruct_path(self, parent: Dict, start: Tuple[int, int], 
                         goal: Tuple[int, int]) -> List[Tuple[int, int]]:
        """重建路径"""
        path = [goal]
        current = goal
        
        while current != start:
            if current not in parent:
                return []
            current = parent[current]
            path.append(current)
            
        path.reverse()
        return path