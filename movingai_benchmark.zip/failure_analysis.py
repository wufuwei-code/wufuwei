import json
import os
import math
import hashlib
from dataclasses import dataclass, asdict
from datetime import datetime
from typing import Any, Dict, Optional, List, Tuple

import numpy as np

# 尝试复用已有的特征提取
try:
    from meta.map_features import extract_map_features as _extract_map_features
    HAS_EXTERNAL_EXTRACTOR = True
except Exception:
    HAS_EXTERNAL_EXTRACTOR = False

FAILURE_LOG_DIR = os.path.join('logs', 'failures')
FAILURE_JSONL = os.path.join(FAILURE_LOG_DIR, 'failure_cases.jsonl')
ALL_RUNS_JSONL = os.path.join(FAILURE_LOG_DIR, 'all_runs.jsonl')

os.makedirs(FAILURE_LOG_DIR, exist_ok=True)

# 失败原因初步分类标签
class FailureCategory:
    PARAM_PREDICTION_SUBOPTIMAL = 'param_prediction_suboptimal'
    MAP_HIGH_COMPLEXITY = 'map_high_complexity'
    SEARCH_STRATEGY_LIMITATION = 'search_strategy_limitation'
    UNKNOWN = 'unknown'

@dataclass
class RunRecord:
    timestamp: str
    map_hash: str
    rows: int
    cols: int
    obstacle_density: float
    start: Tuple[int, int]
    goal: Tuple[int, int]
    start_goal_distance: float
    features: List[float]
    predicted_params: Dict[str, Any]
    confidence_score: float
    outcome: str  # 'success' | 'failure'
    reason: Optional[str]
    expanded_nodes: int
    plan_time: float
    path_length: Optional[float]
    smooth_path_length: Optional[float]
    inflation_radius_used: Optional[int]
    num_inflation_attempts: Optional[int]
    failure_category: Optional[str]
    notes: Optional[str]

class FailureAnalyzer:
    """失败/成功案例记录与初步分类分析器"""

    def __init__(self,
                 failure_jsonl: str = FAILURE_JSONL,
                 all_runs_jsonl: str = ALL_RUNS_JSONL):
        self.failure_jsonl = failure_jsonl
        self.all_runs_jsonl = all_runs_jsonl

    # ========== 公共接口 ==========
    def log_run(self,
                map_grid: np.ndarray,
                start: Tuple[int, int],
                goal: Tuple[int, int],
                features: List[float],
                predicted_params: Dict[str, Any],
                confidence_score: float,
                outcome: str,
                expanded_nodes: int,
                plan_time: float,
                path_length: Optional[float],
                smooth_path_length: Optional[float],
                inflation_radius_used: Optional[int],
                num_inflation_attempts: Optional[int],
                reason: Optional[str] = None,
                notes: Optional[str] = None) -> RunRecord:
        rows, cols = map_grid.shape
        obstacle_density = float(np.mean(map_grid))
        start_goal_distance = float(math.hypot(goal[0]-start[0], goal[1]-start[1]))
        map_hash = self._hash_map(map_grid)

        failure_category = None
        if outcome == 'failure':
            failure_category = self._classify_failure(obstacle_density, predicted_params, expanded_nodes, reason)

        record = RunRecord(
            timestamp=datetime.utcnow().isoformat(),
            map_hash=map_hash,
            rows=rows,
            cols=cols,
            obstacle_density=obstacle_density,
            start=start,
            goal=goal,
            start_goal_distance=start_goal_distance,
            features=list(map(float, features)) if features is not None else [],
            predicted_params={k: float(v) if isinstance(v, (int, float, np.floating)) else v for k, v in (predicted_params or {}).items()},
            confidence_score=float(confidence_score),
            outcome=outcome,
            reason=reason,
            expanded_nodes=int(expanded_nodes),
            plan_time=float(plan_time),
            path_length=float(path_length) if path_length is not None else None,
            smooth_path_length=float(smooth_path_length) if smooth_path_length is not None else None,
            inflation_radius_used=inflation_radius_used,
            num_inflation_attempts=num_inflation_attempts,
            failure_category=failure_category,
            notes=notes
        )

        # 写入全量日志
        self._append_jsonl(self.all_runs_jsonl, asdict(record))
        if outcome == 'failure':
            self._append_jsonl(self.failure_jsonl, asdict(record))
        return record

    def extract_features(self, map_grid: np.ndarray, start: Tuple[int, int], goal: Tuple[int, int]) -> List[float]:
        if HAS_EXTERNAL_EXTRACTOR:
            try:
                feats = _extract_map_features(map_grid, start, goal)
                # 兼容：若返回字典则提取其值；保留原有顺序（按key排序防止顺序不确定）
                if isinstance(feats, dict):
                    numeric_vals = []
                    for k in sorted(feats.keys()):
                        v = feats[k]
                        if isinstance(v, (int, float, np.floating)):
                            numeric_vals.append(float(v))
                    return numeric_vals
                # 可迭代序列
                return [float(v) for v in feats if isinstance(v, (int, float, np.floating))]
            except Exception:
                pass
        # 简单后备特征: [rows, cols, density, start_goal_distance, free_ratio]
        rows, cols = map_grid.shape
        density = float(np.mean(map_grid))
        dist = float(math.hypot(goal[0]-start[0], goal[1]-start[1]))
        free_ratio = 1.0 - density
        return [rows, cols, density, dist, free_ratio]

    # ========== 内部方法 ==========
    def _hash_map(self, map_grid: np.ndarray) -> str:
        return hashlib.md5(map_grid.tobytes()).hexdigest()[:16]

    def _append_jsonl(self, path: str, obj: Dict[str, Any]):
        with open(path, 'a', encoding='utf-8') as f:
            f.write(json.dumps(obj, ensure_ascii=False) + '\n')

    def _classify_failure(self,
                          obstacle_density: float,
                          predicted_params: Dict[str, Any],
                          expanded_nodes: int,
                          reason: Optional[str]) -> str:
        # 规则 1: 参数预测过激 -> initial_weight 过大导致启发偏置
        iw = predicted_params.get('initial_weight', None)
        if iw is not None and iw > 30:
            return FailureCategory.PARAM_PREDICTION_SUBOPTIMAL
        # 规则 2: 高复杂度地图 (高障碍率)
        if obstacle_density >= 0.35:
            return FailureCategory.MAP_HIGH_COMPLEXITY
        # 规则 3: 扩展节点很多但仍失败 -> 搜索策略局限
        if expanded_nodes > 5000:
            return FailureCategory.SEARCH_STRATEGY_LIMITATION
        # 规则 4: reason包含关键词
        if reason:
            if '参数' in reason:
                return FailureCategory.PARAM_PREDICTION_SUBOPTIMAL
            if '障碍' in reason or '死路' in reason:
                return FailureCategory.MAP_HIGH_COMPLEXITY
        return FailureCategory.UNKNOWN

# 全局单例（方便直接导入使用）
ANALYZER = FailureAnalyzer()

__all__ = [
    'FailureAnalyzer', 'ANALYZER', 'FailureCategory', 'RunRecord'
]
