
def validate_parameters_optimized(params):
    """
    优化的智能参数验证函数
    平衡约束严格度与模型灵活性
    """
    validated_params = params.copy()
    violations = []
    
    # 整数类型参数列表
    integer_params = {'frontier_radius', 'recent_visited_len', 'curvature_window'}
    
    # 优化后的参数约束规则
    constraints = {
        'initial_weight': {
            'min': 35.000,
            'max': 42.000,
            'preferred_min': 37.000,
            'preferred_max': 41.000
        },
        'lambda_risk': {
            'min': 2.000,
            'max': 3.000,
            'preferred_min': 2.300,
            'preferred_max': 2.700
        },
        'lambda_smooth': {
            'min': 1.200,
            'max': 1.800,
            'preferred_min': 1.400,
            'preferred_max': 1.700
        },
        'lambda_bonus': {
            'min': 1.200,
            'max': 1.600,
            'preferred_min': 1.300,
            'preferred_max': 1.500
        },
        'frontier_radius': {
            'min': 2.000,
            'max': 5.000,
            'preferred_min': 2.000,
            'preferred_max': 4.000
        },
        'recent_visited_len': {
            'min': 10.000,
            'max': 60.000,
            'preferred_min': 15.000,
            'preferred_max': 50.000
        },
        'curvature_window': {
            'min': 3.000,
            'max': 8.000,
            'preferred_min': 4.000,
            'preferred_max': 7.000
        },
        'risk_power': {
            'min': 1.500,
            'max': 2.000,
            'preferred_min': 1.600,
            'preferred_max': 1.800
        },
        'min_weight': {
            'min': 1.000,
            'max': 1.000,
            'preferred_min': 1.000,
            'preferred_max': 1.000
        },
    }
    
    for param_name, value in params.items():
        if param_name in constraints:
            constraint = constraints[param_name]
            original_value = value
            
            # 硬约束：超出范围的强制修正
            if value < constraint['min']:
                validated_params[param_name] = constraint['min']
                violations.append(f"{param_name}: {original_value:.3f} -> {constraint['min']:.3f} (下限)")
            elif value > constraint['max']:
                validated_params[param_name] = constraint['max']
                violations.append(f"{param_name}: {original_value:.3f} -> {constraint['max']:.3f} (上限)")
            
            # 软建议：偏离首选范围的警告（仅记录，不强制修正）
            elif value < constraint['preferred_min'] or value > constraint['preferred_max']:
                violations.append(f"{param_name}: {value:.3f} (建议范围: {constraint['preferred_min']:.3f}-{constraint['preferred_max']:.3f})")
    
    # 类型转换：确保整数参数为整数类型
    for param_name in integer_params:
        if param_name in validated_params:
            validated_params[param_name] = int(round(validated_params[param_name]))
    
    return validated_params, violations

def get_confidence_score_optimized(params):
    """
    优化的置信度评估函数
    更宽松的评分标准
    """
    constraints = {
        'initial_weight': {
            'preferred_min': 37.000,
            'preferred_max': 41.000,
            'success_mean': 39.000,
            'success_std': 1.000
        },
        'lambda_risk': {
            'preferred_min': 2.300,
            'preferred_max': 2.700,
            'success_mean': 2.500,
            'success_std': 0.100
        },
        'lambda_smooth': {
            'preferred_min': 1.400,
            'preferred_max': 1.700,
            'success_mean': 1.550,
            'success_std': 0.075
        },
        'lambda_bonus': {
            'preferred_min': 1.300,
            'preferred_max': 1.500,
            'success_mean': 1.400,
            'success_std': 0.050
        },
        'frontier_radius': {
            'preferred_min': 2.000,
            'preferred_max': 4.000,
            'success_mean': 3.000,
            'success_std': 0.500
        },
        'recent_visited_len': {
            'preferred_min': 15.000,
            'preferred_max': 50.000,
            'success_mean': 32.500,
            'success_std': 8.750
        },
        'curvature_window': {
            'preferred_min': 4.000,
            'preferred_max': 7.000,
            'success_mean': 5.500,
            'success_std': 0.750
        },
        'risk_power': {
            'preferred_min': 1.600,
            'preferred_max': 1.800,
            'success_mean': 1.700,
            'success_std': 0.050
        },
        'min_weight': {
            'preferred_min': 1.000,
            'preferred_max': 1.000,
            'success_mean': 1.000,
            'success_std': 0.000
        },
    }
    
    total_score = 0
    param_count = 0
    
    for param_name, value in params.items():
        if param_name in constraints:
            constraint = constraints[param_name]
            param_count += 1
            
            # 计算该参数的置信度
            preferred_min = constraint['preferred_min']
            preferred_max = constraint['preferred_max']
            mean = constraint['success_mean']
            std = constraint['success_std']
            
            if preferred_min <= value <= preferred_max:
                # 在首选范围内，给高分
                if std > 0:
                    distance_from_mean = abs(value - mean) / std
                    param_score = max(0.7, 1.0 - distance_from_mean * 0.1)  # 更宽松的评分
                else:
                    param_score = 1.0 if value == mean else 0.9
            else:
                # 在首选范围外，但在硬约束内，给中等分
                param_score = 0.6  # 提高基础分数
            
            total_score += param_score
    
    if param_count == 0:
        return 0.7  # 提高默认置信度
    
    confidence = total_score / param_count
    return min(1.0, max(0.0, confidence))
