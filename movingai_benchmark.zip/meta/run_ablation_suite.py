"""
批量运行消融实验的辅助脚本

自动执行 train_focus_param_net.py 的多个不同 --disable-* 组合，
并将每次运行的核心结果 (val score, MAE, acc) 汇总到 CSV。
"""
import os
import subprocess
import json
import pandas as pd
from typing import List, Dict, Any

# --- 实验配置 ---

# 基础训练参数 (会被每个 run 的特定参数覆盖)
BASE_TRAIN_ARGS = {
    "--train": "data_v2/focused_training_dataset_v3.jsonl",
    "--epochs": 30,
    "--batch-size": 512,
    "--lr": 1e-3,
    "--early-patience": 8,
}

# 实验套件定义
ABLATION_SUITE: List[Dict[str, Any]] = [
    {
        "tag": "full_model",
        "desc": "完整模型，作为基线",
        "params": {}
    },
    {
        "tag": "no_risk",
        "desc": "禁用 lambda_risk",
        "params": {"--disable-cont": ["lambda_risk"]}
    },
    {
        "tag": "no_smooth",
        "desc": "禁用 lambda_smooth",
        "params": {"--disable-cont": ["lambda_smooth"]}
    },
    {
        "tag": "no_bonus",
        "desc": "禁用 lambda_bonus",
        "params": {"--disable-cont": ["lambda_bonus"]}
    },
    {
        "tag": "cont_only",
        "desc": "仅连续参数",
        "params": {"--disable-disc": ["frontier_radius", "recent_visited_len"]}
    },
    {
        "tag": "disc_only",
        "desc": "仅离散参数",
        "params": {"--disable-cont": ["initial_weight", "lambda_risk", "lambda_smooth", "lambda_bonus"]}
    },
    {
        "tag": "no_uncertainty_guidance",
        "desc": "禁用所有与不确定度/风险相关的参数",
        "params": {"--disable-cont": ["lambda_risk", "lambda_bonus"]}
    },
]

# --- 脚本实现 ---

def run_command(cmd: List[str]):
    """执行命令并实时打印输出"""
    print(f"🚀 Executing: {' '.join(cmd)}")
    process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding='utf-8')
    if process.stdout:
        for line in iter(process.stdout.readline, ''):
            print(line.strip())
    returncode = process.wait()
    if returncode != 0:
        print(f"❌ Command failed with exit code {returncode}")
    return returncode

def parse_history(history_path: str) -> Dict[str, Any]:
    """从 training_history.json 解析最佳 epoch 的指标"""
    if not os.path.exists(history_path):
        return {}
    with open(history_path, 'r') as f:
        history = json.load(f)
    
    best_epoch_data = max(history, key=lambda x: x.get('composite_score', -1e9))
    
    results = {
        'best_epoch': best_epoch_data.get('epoch'),
        'best_val_score': best_epoch_data.get('composite_score'),
    }
    for k, v in best_epoch_data.items():
        if k.startswith('mae_') or k.startswith('acc_') or k.startswith('var_'):
            results[f'val_{k}'] = v
    return results

def main():
    suite_results = []
    output_dir_base = "models_runs/ablation_suite"
    os.makedirs(output_dir_base, exist_ok=True)

    for i, run_config in enumerate(ABLATION_SUITE):
        tag = run_config['tag']
        print(f"\n{'='*20} [{i+1}/{len(ABLATION_SUITE)}] Running Ablation: {tag} {'='*20}")
        print(f"Description: {run_config['desc']}")

        run_out_dir = os.path.join(output_dir_base, tag)
        
        # 构建训练命令
        cmd = ["python", "-m", "meta.train_focus_param_net"]
        run_args = {**BASE_TRAIN_ARGS, "--out-dir": run_out_dir, "--ablation-tag": tag}
        
        for arg, val in run_args.items():
            cmd.extend([arg, str(val)])
        
        for arg, val_list in run_config.get('params', {}).items():
            cmd.append(arg)
            cmd.extend(val_list)
            
        # 执行训练
        if run_command(cmd) != 0:
            print(f"⚠️ Training for '{tag}' failed. Skipping.")
            continue
            
        # 解析结果
        history_path = os.path.join(run_out_dir, 'training_history.json')
        run_summary = parse_history(history_path)
        
        final_summary = {
            'tag': tag,
            'description': run_config['desc'],
            **run_summary
        }
        suite_results.append(final_summary)
        
        print(f"✅ Finished run '{tag}'. Best score: {run_summary.get('best_val_score', 'N/A'):.4f}")

    # 汇总结果到 CSV
    if not suite_results:
        print("No results to save.")
        return
        
    df = pd.DataFrame(suite_results)
    # 重新排序列，把 tag 和 desc 放前面
    cols = ['tag', 'description', 'best_epoch', 'best_val_score']
    other_cols = [c for c in df.columns if c not in cols]
    df = df[cols + sorted(other_cols)]
    
    csv_path = os.path.join(output_dir_base, "ablation_summary.csv")
    df.to_csv(csv_path, index=False)
    
    print(f"\n{'='*20} Ablation Suite Finished {'='*20}")
    print(f"📊 Summary saved to: {csv_path}")
    print(df.to_string(index=False))

if __name__ == "__main__":
    main()
