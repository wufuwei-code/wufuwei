import os
import time
import math
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import networkx as nx

from scipy.spatial import cKDTree

# ensure local package imports work when script executed directly
import sys
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from astar_demo import (
    prepare_random_map,
    search_with_decreasing_inflation,
    astar_hierarchical_hybrid,
    prune_path,
    smooth_path_with_bezier_adaptive,
    is_strict_line_clear,
)


def prm_plan(map_grid, start, goal, n_samples=5000, k=30, max_attempts=20000):
    rows, cols = map_grid.shape
    free_cells = np.argwhere(map_grid == 0)
    free_set = set(map(tuple, free_cells.tolist()))

    samples = set()
    attempts = 0
    # include start and goal
    samples.add(tuple(start))
    samples.add(tuple(goal))

    while len(samples) < n_samples and attempts < max_attempts:
        attempts += 1
        idx = np.random.randint(0, len(free_cells))
        pt = tuple(map(int, free_cells[idx]))
        samples.add(pt)

    samples = np.array(sorted(list(samples)))
    pts = samples.astype(float)

    tree = cKDTree(pts)
    G = nx.Graph()
    for i, p in enumerate(samples.tolist()):
        G.add_node(tuple(p))

    # connect k nearest (symmetric) if collision free
    dists, nbrs = tree.query(pts, k=k + 1)
    for i, nbr_list in enumerate(nbrs):
        pi = tuple(samples[i])
        for j in nbr_list[1:]:
            pj = tuple(samples[j])
            if G.has_edge(pi, pj):
                continue
            if is_strict_line_clear(pi, pj, map_grid):
                dist = math.hypot(pi[0] - pj[0], pi[1] - pj[1])
                G.add_edge(pi, pj, weight=dist)

    if tuple(start) not in G or tuple(goal) not in G:
        return [], {'graph_nodes': G.number_of_nodes(), 'graph_edges': G.number_of_edges()}

    try:
        path_nodes = nx.shortest_path(G, source=tuple(start), target=tuple(goal), weight='weight')
        path = np.array(path_nodes)
        return path, {'graph_nodes': G.number_of_nodes(), 'graph_edges': G.number_of_edges()}
    except Exception:
        return [], {'graph_nodes': G.number_of_nodes(), 'graph_edges': G.number_of_edges()}


def rrt_plan(map_grid, start, goal, max_iters=20000, step_size=2.0):
    rows, cols = map_grid.shape
    start = tuple(map(int, start))
    goal = tuple(map(int, goal))

    tree = {start: None}
    nodes = [start]

    def random_sample():
        if np.random.random() < 0.1:
            return goal
        idx = np.random.randint(0, rows), np.random.randint(0, cols)
        return idx

    def steer(a, b, step=step_size):
        ay, ax = a
        by, bx = b
        vec = (by - ay, bx - ax)
        dist = math.hypot(vec[0], vec[1])
        if dist <= step:
            return (int(round(by)), int(round(bx)))
        ratio = step / dist
        ny = ay + vec[0] * ratio
        nx_ = ax + vec[1] * ratio
        return (int(round(ny)), int(round(nx_)))

    tic = time.time()
    for i in range(int(max_iters)):
        rand = random_sample()
        # find nearest node
        dmin = float('inf')
        nearest = None
        for n in nodes:
            d = math.hypot(n[0] - rand[0], n[1] - rand[1])
            if d < dmin:
                dmin = d
                nearest = n
        new = steer(nearest, rand)
        if not (0 <= new[0] < rows and 0 <= new[1] < cols):
            continue
        if not is_strict_line_clear(nearest, new, map_grid):
            continue
        if new in tree:
            continue
        tree[new] = nearest
        nodes.append(new)
        if math.hypot(new[0] - goal[0], new[1] - goal[1]) <= step_size:
            if is_strict_line_clear(new, goal, map_grid):
                tree[goal] = new
                # reconstruct
                path = []
                cur = goal
                while cur is not None:
                    path.append(cur)
                    cur = tree.get(cur)
                path.reverse()
                return np.array(path), {'tree_size': len(nodes), 'iterations': i + 1, 'time': time.time() - tic}

    return [], {'tree_size': len(nodes), 'iterations': max_iters, 'time': time.time() - tic}


def path_length(path):
    if len(path) < 2:
        return 0.0
    return np.sum(np.linalg.norm(np.diff(path.astype(float), axis=0), axis=1))


def run_single_map_test(out_dir='outputs/ablation_results'):
    os.makedirs(out_dir, exist_ok=True)
    rows, cols = 100, 100
    obstacle_ratio = 0.2
    seed = 2

    grid, start, goal = prepare_random_map(rows=rows, cols=cols, obstacle_ratio=obstacle_ratio, seed=seed)
    print(f"[compare] map prepared: size={grid.shape}, start={start}, goal={goal}")

    planners = {}

    # RL-A* (project implementation)
    print('[compare] running RL-A*...')
    tic = time.time()
    path_rl, expanded_order, used_radius, attempts, plan_time = search_with_decreasing_inflation(grid, start, goal, inflation_radius=2, complex_params={})
    rl_plan_time = plan_time
    rl_success = len(path_rl) > 0
    print(f"[compare] RL-A* success={rl_success}, time={rl_plan_time:.4f}s")
    if rl_success:
        path_rl = prune_path(path_rl, grid)
        smooth_rl = smooth_path_with_bezier_adaptive(path_rl, grid)
        rl_orig_len = path_length(path_rl)
        rl_smooth_len = path_length(smooth_rl)
        rl_expanded = int(np.max(expanded_order))
    else:
        smooth_rl = np.array([])
        rl_orig_len = rl_smooth_len = rl_expanded = None

    planners['RL-A*'] = {
        'success': rl_success,
        'plan_time': rl_plan_time,
        'orig_len': rl_orig_len,
        'smooth_len': rl_smooth_len,
        'expanded_nodes': rl_expanded,
        'path_points': len(path_rl) if rl_success else 0,
    }

    # A* (direct)
    print('[compare] running A*...')
    tic = time.time()
    path_a, expanded_a = astar_hierarchical_hybrid(grid, start, goal, {})
    a_time = time.time() - tic
    a_success = len(path_a) > 0
    print(f"[compare] A* success={a_success}, time={a_time:.4f}s")
    if a_success:
        path_a = prune_path(path_a, grid)
        smooth_a = smooth_path_with_bezier_adaptive(path_a, grid)
        a_orig_len = path_length(path_a)
        a_smooth_len = path_length(smooth_a)
        a_expanded = int(np.max(expanded_a))
    else:
        smooth_a = np.array([])
        a_orig_len = a_smooth_len = a_expanded = None

    planners['A*'] = {
        'success': a_success,
        'plan_time': a_time,
        'orig_len': a_orig_len,
        'smooth_len': a_smooth_len,
        'expanded_nodes': a_expanded,
        'path_points': len(path_a) if a_success else 0,
    }

    # PRM
    print('[compare] running PRM (samples=5000, k=30)...')
    tic = time.time()
    path_prm, meta_prm = prm_plan(grid, start, goal, n_samples=5000, k=30)
    prm_time = time.time() - tic
    prm_success = len(path_prm) > 0
    print(f"[compare] PRM success={prm_success}, graph_nodes={meta_prm.get('graph_nodes')}, edges={meta_prm.get('graph_edges')}, time={prm_time:.4f}s")
    if prm_success:
        path_prm = prune_path(path_prm, grid)
        smooth_prm = smooth_path_with_bezier_adaptive(path_prm, grid)
        prm_orig_len = path_length(path_prm)
        prm_smooth_len = path_length(smooth_prm)
    else:
        smooth_prm = np.array([])
        prm_orig_len = prm_smooth_len = None

    planners['PRM'] = {
        'success': prm_success,
        'plan_time': prm_time,
        'orig_len': prm_orig_len,
        'smooth_len': prm_smooth_len,
        'expanded_nodes': meta_prm.get('graph_nodes'),
        'path_points': len(path_prm) if prm_success else 0,
    }

    # RRT
    print('[compare] running RRT (max_iters=20000, step_size=2.0)...')
    tic = time.time()
    path_rrt, meta_rrt = rrt_plan(grid, start, goal, max_iters=20000, step_size=2.0)
    rrt_time = time.time() - tic
    rrt_success = len(path_rrt) > 0
    print(f"[compare] RRT success={rrt_success}, tree_size={meta_rrt.get('tree_size')}, iterations={meta_rrt.get('iterations')}, time={rrt_time:.4f}s")
    if rrt_success:
        path_rrt = prune_path(path_rrt, grid)
        smooth_rrt = smooth_path_with_bezier_adaptive(path_rrt, grid)
        rrt_orig_len = path_length(path_rrt)
        rrt_smooth_len = path_length(smooth_rrt)
    else:
        smooth_rrt = np.array([])
        rrt_orig_len = rrt_smooth_len = None

    planners['RRT'] = {
        'success': rrt_success,
        'plan_time': rrt_time,
        'orig_len': rrt_orig_len,
        'smooth_len': rrt_smooth_len,
        'expanded_nodes': meta_rrt.get('tree_size'),
        'path_points': len(path_rrt) if rrt_success else 0,
    }

    # save CSV
    rows_out = []
    for name, info in planners.items():
        rows_out.append({
            'planner': name,
            'success': bool(info['success']),
            'plan_time': float(info['plan_time']) if info['plan_time'] is not None else None,
            'expanded_nodes': int(info['expanded_nodes']) if info['expanded_nodes'] is not None else None,
            'orig_len': float(info['orig_len']) if info['orig_len'] is not None else None,
            'smooth_len': float(info['smooth_len']) if info['smooth_len'] is not None else None,
            'path_points': int(info['path_points']) if info['path_points'] is not None else None,
        })

    df = pd.DataFrame(rows_out)
    csv_path = os.path.join(out_dir, 'compare_planners_single_map.csv')
    df.to_csv(csv_path, index=False)

    # visualization overlay
    fig, ax = plt.subplots(figsize=(6, 6))
    ax.imshow(np.where(grid == 1, 0, 1), cmap='gray', origin='lower')
    colors = {'RL-A*': 'cyan', 'A*': 'yellow', 'PRM': 'magenta', 'RRT': 'lime'}
    for name in planners:
        if planners[name]['path_points'] and planners[name]['path_points'] > 0:
            if name == 'RL-A*':
                path = path_rl
            elif name == 'A*':
                path = path_a
            elif name == 'PRM':
                path = path_prm
            else:
                path = path_rrt
            ax.plot(path[:, 1], path[:, 0], '-', color=colors.get(name, 'white'), label=f"{name}")
    ax.plot(start[1], start[0], 'ro', label='start')
    ax.plot(goal[1], goal[0], 'bs', label='goal')
    ax.legend()
    ax.set_title('Planner overlay')
    png_path = os.path.join(out_dir, 'compare_planners_single_map.png')
    fig.tight_layout()
    fig.savefig(png_path, dpi=200)
    plt.close(fig)

    print(f"Results saved to: {csv_path}, {png_path}")


if __name__ == '__main__':
    run_single_map_test()
