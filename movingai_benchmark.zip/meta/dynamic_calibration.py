#!/usr/bin/env python3
"""
动态校准研究模块

实现动态校准技术：
1. 在线学习校准 (Online Calibration)
2. 时间序列校准 (Temporal Calibration)
3. 反馈驱动校准 (Feedback-driven Calibration)
4. 元学习校准 (Meta-learning Calibration)
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__)))

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import json
from typing import Dict, List, Tuple, Any, Optional, Callable
from collections import deque
import time
import argparse

from models_arch.focus_param_net import FocusParamNet
from models_arch.focus_dataset import FocusParamDataset

class OnlineCalibration:
    """
    在线校准：实时更新校准参数

    使用在线学习算法，随着新数据的到来持续更新校准器
    """

    def __init__(self, learning_rate: float = 0.01, window_size: int = 1000):
        self.learning_rate = learning_rate
        self.window_size = window_size

        # 在线校准参数
        self.scale = torch.nn.Parameter(torch.ones(1))
        self.bias = torch.nn.Parameter(torch.zeros(1))

        # 滑动窗口数据
        self.prediction_window = deque(maxlen=window_size)
        self.target_window = deque(maxlen=window_size)
        self.uncertainty_window = deque(maxlen=window_size)

        self.optimizer = torch.optim.SGD([self.scale, self.bias], lr=learning_rate)
        self.fitted = False

    def update(self, prediction: float, uncertainty: float, target: float):
        """在线更新校准器"""

        # 添加到滑动窗口
        self.prediction_window.append(prediction)
        self.uncertainty_window.append(uncertainty)
        self.target_window.append(target)

        if len(self.prediction_window) < 10:  # 需要最小样本数
            return

        # 转换为tensor
        pred_tensor = torch.FloatTensor(list(self.prediction_window))
        uncert_tensor = torch.FloatTensor(list(self.uncertainty_window))
        target_tensor = torch.FloatTensor(list(self.target_window))

        # 在线更新
        self.optimizer.zero_grad()

        # 当前校准
        calibrated_uncert = uncert_tensor * self.scale + self.bias
        calibrated_uncert = torch.clamp(calibrated_uncert, min=1e-6)

        # 损失函数：NLL + 覆盖率正则化
        errors = torch.abs(pred_tensor - target_tensor)

        # NLL损失
        nll_loss = 0.5 * torch.log(2 * torch.pi * calibrated_uncert**2) + \
                   0.5 * (errors**2 / calibrated_uncert**2)
        nll_loss = torch.mean(nll_loss)

        # 覆盖率损失（鼓励68%覆盖率）
        coverage = torch.mean((errors <= calibrated_uncert).float())
        coverage_loss = (coverage - 0.68) ** 2

        # 总损失
        total_loss = nll_loss + 0.1 * coverage_loss

        total_loss.backward()
        self.optimizer.step()

        self.fitted = True

    def calibrate(self, uncertainty: float) -> float:
        """应用在线校准"""
        if not self.fitted:
            return uncertainty

        with torch.no_grad():
            calibrated = uncertainty * self.scale.item() + self.bias.item()
            return max(calibrated, 1e-6)

    def get_calibration_stats(self) -> Dict[str, float]:
        """获取校准统计信息"""
        if not self.fitted or len(self.prediction_window) == 0:
            return {}

        pred_array = np.array(list(self.prediction_window))
        uncert_array = np.array(list(self.uncertainty_window))
        target_array = np.array(list(self.target_window))

        calibrated_uncert = np.array([self.calibrate(u) for u in uncert_array])

        errors = np.abs(pred_array - target_array)
        coverage_68 = np.mean(errors <= calibrated_uncert)
        coverage_95 = np.mean(errors <= 1.96 * calibrated_uncert)

        ece = self._compute_ece(pred_array, calibrated_uncert, target_array)

        return {
            'window_size': len(self.prediction_window),
            'scale': self.scale.item(),
            'bias': self.bias.item(),
            'coverage_68': coverage_68,
            'coverage_95': coverage_95,
            'ece': ece
        }

    def _compute_ece(self, predictions: np.ndarray, uncertainties: np.ndarray,
                    targets: np.ndarray, n_bins: int = 10) -> float:
        """计算ECE"""
        bin_boundaries = np.linspace(0, np.max(uncertainties), n_bins + 1)
        bin_boundaries[-1] += 1e-8

        ece = 0.0
        total_samples = 0

        for i in range(n_bins):
            mask = (uncertainties > bin_boundaries[i]) & (uncertainties <= bin_boundaries[i + 1])
            if not np.any(mask):
                continue

            bin_size = np.sum(mask)
            bin_uncertainties = uncertainties[mask]
            bin_predictions = predictions[mask]
            bin_targets = targets[mask]

            coverage = np.mean(np.abs(bin_predictions - bin_targets) <= bin_uncertainties)
            expected_coverage = 0.68

            ece += bin_size * abs(coverage - expected_coverage)
            total_samples += bin_size

        return ece / total_samples if total_samples > 0 else 0.0


class TemporalCalibration:
    """
    时间序列校准：考虑预测的时间依赖性

    建模不确定度随时间的变化模式
    """

    def __init__(self, sequence_length: int = 50, hidden_dim: int = 32):
        self.sequence_length = sequence_length
        self.hidden_dim = hidden_dim

        # RNN-based时序校准器
        self.rnn = nn.LSTM(input_size=3, hidden_size=hidden_dim, batch_first=True)  # [pred, uncert, error]
        self.calibration_head = nn.Sequential(
            nn.Linear(hidden_dim, 16),
            nn.ReLU(),
            nn.Linear(16, 1),
            nn.Softplus()  # 确保正输出
        )

        self.optimizer = optim.Adam(list(self.rnn.parameters()) + list(self.calibration_head.parameters()))
        self.fitted = False

        # 时序数据缓冲
        self.prediction_history = deque(maxlen=sequence_length)
        self.uncertainty_history = deque(maxlen=sequence_length)
        self.error_history = deque(maxlen=sequence_length)

    def update(self, prediction: float, uncertainty: float, target: float):
        """更新时序校准器"""

        error = abs(prediction - target)

        self.prediction_history.append(prediction)
        self.uncertainty_history.append(uncertainty)
        self.error_history.append(error)

        if len(self.prediction_history) >= 10:  # 最小序列长度
            self._train_step()

    def _train_step(self):
        """执行一步训练"""

        # 准备序列数据
        seq_len = len(self.prediction_history)
        pred_seq = torch.FloatTensor(list(self.prediction_history)).unsqueeze(0)  # [1, seq_len]
        uncert_seq = torch.FloatTensor(list(self.uncertainty_history)).unsqueeze(0)
        error_seq = torch.FloatTensor(list(self.error_history)).unsqueeze(0)

        # 拼接输入特征
        x = torch.stack([pred_seq, uncert_seq, error_seq], dim=-1)  # [1, seq_len, 3]

        self.optimizer.zero_grad()

        # RNN前向传播
        rnn_out, _ = self.rnn(x)  # [1, seq_len, hidden_dim]

        # 校准头预测校准因子
        calibration_factors = self.calibration_head(rnn_out).squeeze(-1)  # [1, seq_len]

        # 计算损失：预测下一个时间步的校准因子
        # 这里简化为预测当前时间步的"理想"校准因子
        current_uncertainties = uncert_seq.squeeze(0)
        current_errors = error_seq.squeeze(0)

        # 理想校准因子：使覆盖率接近68%
        ideal_factors = current_errors / (current_uncertainties + 1e-6)
        ideal_factors = torch.clamp(ideal_factors, 0.1, 5.0)  # 合理范围

        loss = nn.functional.mse_loss(calibration_factors.squeeze(0), ideal_factors)

        loss.backward()
        self.optimizer.step()

        self.fitted = True

    def calibrate(self, uncertainty: float, prediction: float = 0.0, recent_error: float = 0.0) -> float:
        """应用时序校准"""
        if not self.fitted or len(self.prediction_history) == 0:
            return uncertainty

        # 准备当前输入
        current_input = torch.FloatTensor([[prediction, uncertainty, recent_error]])  # [1, 1, 3]

        with torch.no_grad():
            # 使用历史序列 + 当前输入
            if len(self.prediction_history) >= self.sequence_length:
                hist_pred = torch.FloatTensor(list(self.prediction_history)).unsqueeze(0)
                hist_uncert = torch.FloatTensor(list(self.uncertainty_history)).unsqueeze(0)
                hist_error = torch.FloatTensor(list(self.error_history)).unsqueeze(0)

                full_seq = torch.stack([hist_pred, hist_uncert, hist_error], dim=-1)  # [1, seq_len, 3]

                rnn_out, _ = self.rnn(full_seq)
                last_hidden = rnn_out[:, -1, :]  # [1, hidden_dim]
            else:
                # 如果历史不足，使用当前输入重复
                repeated_input = current_input.repeat(1, self.sequence_length, 1)
                rnn_out, _ = self.rnn(repeated_input)
                last_hidden = rnn_out[:, -1, :]

            # 预测校准因子
            calibration_factor = self.calibration_head(last_hidden).item()

            calibrated_uncertainty = uncertainty * calibration_factor

            return max(calibrated_uncertainty, 1e-6)


class FeedbackDrivenCalibration:
    """
    反馈驱动校准：基于性能反馈调整校准策略

    使用强化学习的思想，根据校准性能的反馈来调整校准参数
    """

    def __init__(self, learning_rate: float = 0.01, feedback_window: int = 20):
        self.learning_rate = learning_rate
        self.feedback_window = feedback_window

        # 校准参数（可学习）
        self.temperature = torch.nn.Parameter(torch.ones(1))
        self.scale_factor = torch.nn.Parameter(torch.ones(1))

        # 反馈历史
        self.recent_ece_scores = deque(maxlen=feedback_window)
        self.recent_coverage_scores = deque(maxlen=feedback_window)

        self.optimizer = torch.optim.Adam([self.temperature, self.scale_factor], lr=learning_rate)
        self.fitted = False

    def update_with_feedback(self, predictions: np.ndarray, uncertainties: np.ndarray,
                           targets: np.ndarray, performance_reward: float = None):
        """基于反馈更新校准器"""

        # 应用当前校准
        calibrated_uncert = self._apply_calibration(uncertainties)

        # 计算性能指标
        ece = self._compute_ece(predictions, calibrated_uncert, targets)
        coverage_68 = np.mean(np.abs(predictions - targets) <= calibrated_uncert)

        # 存储反馈
        self.recent_ece_scores.append(ece)
        self.recent_coverage_scores.append(coverage_68)

        if len(self.recent_ece_scores) < 5:  # 需要足够的历史
            return

        # 计算奖励信号
        if performance_reward is None:
            # 自动计算奖励：ECE减少 + 覆盖率接近68%
            avg_ece = np.mean(self.recent_ece_scores)
            avg_coverage = np.mean(self.recent_coverage_scores)

            ece_reward = -avg_ece  # 负ECE（越低越好）
            coverage_reward = -abs(avg_coverage - 0.68)  # 接近68%的奖励

            reward = ece_reward + coverage_reward
        else:
            reward = performance_reward

        # 策略梯度更新
        self.optimizer.zero_grad()

        # 创建可微分的奖励
        reward_tensor = torch.FloatTensor([reward])

        # 计算梯度（这里简化为直接基于奖励的更新）
        # 在实际RL中，这会更复杂
        reward_tensor.backward()

        # 手动应用梯度（简化版）
        with torch.no_grad():
            # 根据奖励调整参数
            if reward > 0:  # 好的性能，保持当前方向
                pass  # 让Adam优化器处理
            else:  # 差的性能，尝试不同参数
                # 随机扰动
                noise_scale = 0.1
                self.temperature.data += torch.randn_like(self.temperature) * noise_scale
                self.scale_factor.data += torch.randn_like(self.scale_factor) * noise_scale

                # 确保参数合理
                self.temperature.data.clamp_(0.1, 5.0)
                self.scale_factor.data.clamp_(0.1, 5.0)

        self.fitted = True

    def _apply_calibration(self, uncertainties: np.ndarray) -> np.ndarray:
        """应用当前校准策略"""
        uncert_tensor = torch.FloatTensor(uncertainties)

        # 温度缩放 + 尺度调整
        calibrated = uncert_tensor * self.temperature * self.scale_factor
        return calibrated.detach().numpy()

    def calibrate(self, uncertainties: np.ndarray) -> np.ndarray:
        """应用反馈驱动校准"""
        if not self.fitted:
            return uncertainties

        return self._apply_calibration(uncertainties)

    def _compute_ece(self, predictions: np.ndarray, uncertainties: np.ndarray,
                    targets: np.ndarray) -> float:
        """计算ECE"""
        n_bins = 10
        bin_boundaries = np.linspace(0, np.max(uncertainties), n_bins + 1)
        bin_boundaries[-1] += 1e-8

        ece = 0.0
        total_samples = 0

        for i in range(n_bins):
            mask = (uncertainties > bin_boundaries[i]) & (uncertainties <= bin_boundaries[i + 1])
            if not np.any(mask):
                continue

            bin_size = np.sum(mask)
            bin_uncertainties = uncertainties[mask]
            bin_predictions = predictions[mask]
            bin_targets = targets[mask]

            coverage = np.mean(np.abs(bin_predictions - bin_targets) <= bin_uncertainties)
            expected_coverage = 0.68

            ece += bin_size * abs(coverage - expected_coverage)
            total_samples += bin_size

        return ece / total_samples if total_samples > 0 else 0.0


class MetaLearningCalibration:
    """
    元学习校准：学习如何快速适应新的校准任务

    使用元学习框架，使校准器能够快速适应新的数据集或领域
    """

    def __init__(self, meta_learning_rate: float = 0.001, adaptation_steps: int = 5):
        self.meta_learning_rate = meta_learning_rate
        self.adaptation_steps = adaptation_steps

        # 元学习器：学习校准器的初始化参数
        self.meta_temperature_init = torch.nn.Parameter(torch.ones(1))
        self.meta_scale_init = torch.nn.Parameter(torch.ones(1))

        self.meta_optimizer = torch.optim.Adam([self.meta_temperature_init, self.meta_scale_init],
                                             lr=meta_learning_rate)

        # 任务历史
        self.task_history = []

        self.fitted = False

    def meta_train(self, task_datasets: List[Tuple[np.ndarray, np.ndarray, np.ndarray]]):
        """
        元训练：学习如何初始化校准器

        Args:
            task_datasets: 列表，每个元素是 (predictions, uncertainties, targets) 的三元组
        """

        for task_idx, (predictions, uncertainties, targets) in enumerate(task_datasets):
            print(f"元训练任务 {task_idx + 1}/{len(task_datasets)}")

            # 为每个任务创建新的校准器实例（使用元学习器初始化的参数）
            task_temperature = self.meta_temperature_init.clone().detach().requires_grad_(True)
            task_scale = self.meta_scale_init.clone().detach().requires_grad_(True)

            task_optimizer = torch.optim.SGD([task_temperature, task_scale], lr=0.01)

            # 内循环：快速适应当前任务
            for adaptation_step in range(self.adaptation_steps):
                task_optimizer.zero_grad()

                # 应用当前参数
                calibrated_uncert = uncertainties * task_temperature.item() * task_scale.item()
                calibrated_uncert = np.maximum(calibrated_uncert, 1e-6)

                # 计算任务损失
                task_loss = self._compute_task_loss(predictions, calibrated_uncert, targets)
                task_loss.backward()

                task_optimizer.step()

            # 外循环：更新元学习器
            self.meta_optimizer.zero_grad()

            # 计算在当前任务上的最终性能
            final_calibrated = uncertainties * task_temperature.item() * task_scale.item()
            final_calibrated = np.maximum(final_calibrated, 1e-6)
            final_loss = self._compute_task_loss(predictions, final_calibrated, targets)

            # 元损失：所有任务的性能
            final_loss.backward()
            self.meta_optimizer.step()

        self.fitted = True
        print("元学习训练完成")

    def adapt_to_task(self, predictions: np.ndarray, uncertainties: np.ndarray,
                     targets: np.ndarray, adaptation_steps: int = 3) -> 'TaskCalibration':
        """快速适应新任务"""

        # 使用元学习器初始化的参数
        task_calibrator = TaskCalibration(
            initial_temperature=self.meta_temperature_init.item(),
            initial_scale=self.meta_scale_init.item()
        )

        # 快速适应
        task_calibrator.adapt(predictions, uncertainties, targets, adaptation_steps)

        return task_calibrator

    def _compute_task_loss(self, predictions: np.ndarray, uncertainties: np.ndarray,
                          targets: np.ndarray) -> torch.Tensor:
        """计算任务损失"""
        errors = np.abs(predictions - targets)

        # ECE-like损失
        coverage = np.mean(errors <= uncertainties)
        coverage_loss = (coverage - 0.68) ** 2

        # NLL损失
        nll = 0.5 * np.log(2 * np.pi * uncertainties**2) + 0.5 * (errors**2 / uncertainties**2)
        nll_loss = np.mean(nll)

        total_loss = coverage_loss + 0.1 * nll_loss

        return torch.FloatTensor([total_loss])


class TaskCalibration:
    """单个任务的校准器（用于元学习）"""

    def __init__(self, initial_temperature: float = 1.0, initial_scale: float = 1.0):
        self.temperature = initial_temperature
        self.scale = initial_scale

    def adapt(self, predictions: np.ndarray, uncertainties: np.ndarray,
             targets: np.ndarray, steps: int = 3):
        """快速适应任务"""

        for step in range(steps):
            # 应用当前参数
            calibrated_uncert = uncertainties * self.temperature * self.scale
            calibrated_uncert = np.maximum(calibrated_uncert, 1e-6)

            # 计算梯度（简化版）
            errors = np.abs(predictions - targets)
            coverage = np.mean(errors <= calibrated_uncert)

            # 简单的梯度更新
            coverage_gradient = 2 * (coverage - 0.68) * coverage * (1 - coverage)

            # 更新参数（经验法则）
            learning_rate = 0.1
            self.temperature -= learning_rate * coverage_gradient * 0.1
            self.scale -= learning_rate * coverage_gradient * 0.1

            # 确保参数合理
            self.temperature = np.clip(self.temperature, 0.1, 5.0)
            self.scale = np.clip(self.scale, 0.1, 5.0)

    def calibrate(self, uncertainties: np.ndarray) -> np.ndarray:
        """应用校准"""
        calibrated = uncertainties * self.temperature * self.scale
        return np.maximum(calibrated, 1e-6)


# 动态校准评估器
class DynamicCalibrationEvaluator:
    """动态校准方法评估器"""

    def __init__(self):
        self.methods = {
            'online': OnlineCalibration,
            'temporal': TemporalCalibration,
            'feedback_driven': FeedbackDrivenCalibration,
            'meta_learning': MetaLearningCalibration
        }

    def evaluate_online_calibration(self, model_path: str, data_path: str):
        """评估在线校准"""

        print("🔄 评估在线校准...")

        # 加载数据
        model, dataloader, enabled_cont = self._load_model_and_data(model_path, data_path)

        # 模拟在线学习场景
        online_calibrators = {param: OnlineCalibration() for param in enabled_cont}

        all_stats = {param: [] for param in enabled_cont}

        with torch.no_grad():
            for batch_idx, batch in enumerate(dataloader):
                if batch_idx >= 50:  # 限制批次数
                    break

                features = batch['features']
                mc_pred = model.predict_with_uncertainty(features, mc_times=10)

                for param in enabled_cont:
                    if param in batch['targets_cont']:
                        pred = mc_pred[param].cpu().numpy()
                        uncert = torch.sqrt(mc_pred[f"{param}_var"]).cpu().numpy()
                        target = batch['targets_cont'][param].cpu().numpy()

                        # 在线更新
                        for i in range(len(pred)):
                            online_calibrators[param].update(pred[i], uncert[i], target[i])

                        # 记录统计
                        if batch_idx % 10 == 0:
                            stats = online_calibrators[param].get_calibration_stats()
                            if stats:
                                all_stats[param].append(stats)

        # 分析结果
        self._analyze_online_results(all_stats)

    def evaluate_temporal_calibration(self, model_path: str, data_path: str):
        """评估时序校准"""

        print("⏰ 评估时序校准...")

        # 类似实现...

    def _load_model_and_data(self, model_path: str, data_path: str):
        """加载模型和数据（复用现有代码）"""
        # 复用现有加载逻辑
        from evaluate_advanced_calibration import AdvancedCalibrationEvaluator
        evaluator = AdvancedCalibrationEvaluator()
        return evaluator.load_model_and_data(model_path, data_path)

    def _analyze_online_results(self, all_stats: Dict[str, List[Dict]]):
        """分析在线校准结果"""

        print("\n📊 在线校准分析:")

        for param, stats_history in all_stats.items():
            if not stats_history:
                continue

            print(f"\n🔹 参数: {param}")

            # 分析ECE变化
            ece_values = [s['ece'] for s in stats_history]
            print(f"  ECE变化: {ece_values[0]:.3f} → {ece_values[-1]:.3f}")

            # 分析覆盖率变化
            cov_values = [s['coverage_68'] for s in stats_history]
            print(f"  覆盖率变化: {cov_values[0]:.3f} → {cov_values[-1]:.3f}")

            # 分析参数变化
            scale_values = [s['scale'] for s in stats_history]
            print(f"  尺度参数变化: {scale_values[0]:.3f} → {scale_values[-1]:.3f}")


def main():
    """主函数：运行动态校准评估"""

    parser = argparse.ArgumentParser(description="动态校准研究")
    parser.add_argument('--model', type=str, required=True, help='模型路径')
    parser.add_argument('--data', type=str, required=True, help='数据集路径')
    parser.add_argument('--method', type=str, choices=['online', 'temporal', 'feedback', 'meta', 'all'],
                       default='online', help='评估方法')

    args = parser.parse_args()

    evaluator = DynamicCalibrationEvaluator()

    if args.method in ['online', 'all']:
        evaluator.evaluate_online_calibration(args.model, args.data)

    if args.method in ['temporal', 'all']:
        evaluator.evaluate_temporal_calibration(args.model, args.data)


if __name__ == "__main__":
    main()