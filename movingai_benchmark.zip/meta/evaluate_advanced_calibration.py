#!/usr/bin/env python3
"""
高级校准方法评估和比较脚本

评估多种先进的校准技术：
1. 集成校准 (Ensemble Calibration)
2. 自适应校准 (Adaptive Calibration)
3. 条件校准 (Conditional Calibration)
4. 贝叶斯校准 (Bayesian Calibration)
5. 多尺度校准 (Multi-scale Calibration)
6. 鲁棒校准 (Robust Calibration)

与传统方法进行全面比较
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__)))

import torch
import numpy as np
import json
import pandas as pd
from pathlib import Path
from typing import Dict, List, Tuple, Any
from sklearn.model_selection import train_test_split
import argparse
import time

from models_arch.focus_param_net import FocusParamNet
from models_arch.focus_dataset import FocusParamDataset
from advanced_calibration import (
    EnsembleCalibration, AdaptiveCalibration, ConditionalCalibration,
    BayesianCalibration, MultiScaleCalibration, RobustCalibration
)
from calibrate_uncertainty import TemperatureScaling, VarianceScaling, IsotonicCalibration

class AdvancedCalibrationEvaluator:
    """高级校准方法评估器"""

    def __init__(self):
        self.methods = {}
        self.results = {}
        self.setup_methods()

    def setup_methods(self):
        """设置所有校准方法"""

        # 传统方法
        self.methods['original'] = lambda: None  # 占位符
        self.methods['temperature'] = TemperatureScaling
        self.methods['variance'] = VarianceScaling
        self.methods['isotonic'] = IsotonicCalibration

        # 高级方法
        self.methods['ensemble'] = EnsembleCalibration
        self.methods['adaptive'] = AdaptiveCalibration
        self.methods['conditional'] = ConditionalCalibration
        self.methods['bayesian'] = BayesianCalibration
        self.methods['multiscale'] = MultiScaleCalibration
        self.methods['robust'] = RobustCalibration

    def evaluate_all_methods(self, model_path: str, data_path: str,
                           output_path: str = 'advanced_calibration_results.json'):
        """评估所有校准方法"""

        print("🚀 开始高级校准方法评估")
        print(f"模型: {model_path}")
        print(f"数据: {data_path}")

        # 加载数据
        model, dataloader, enabled_cont = self.load_model_and_data(model_path, data_path)
        print(f"启用参数: {enabled_cont}")

        # 收集预测结果
        print("📊 收集模型预测...")
        all_predictions, all_targets, all_uncertainties, all_features = self.collect_predictions_with_features(
            model, dataloader, enabled_cont
        )

        # 评估每种方法
        for param in enabled_cont:
            if len(all_predictions[param]) == 0:
                continue

            print(f"\n🎯 评估参数: {param}")

            pred_arr = np.array(all_predictions[param])
            target_arr = np.array(all_targets[param])
            uncert_arr = np.array(all_uncertainties[param])
            features_arr = np.array(all_features[param])

            param_results = self.evaluate_parameter_methods(
                param, pred_arr, uncert_arr, target_arr, features_arr
            )

            self.results[param] = param_results

        # 保存结果
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(self.results, f, indent=2, default=float, ensure_ascii=False)

        print(f"\n💾 高级校准结果已保存到: {output_path}")

        # 生成比较报告
        self.generate_comparison_report()

    def load_model_and_data(self, model_path: str, data_path: str):
        """加载模型和数据"""
        # 加载模型
        checkpoint = torch.load(model_path, map_location='cpu')
        args_in_ckpt = checkpoint.get('args', {}) or {}

        # 获取启用的参数
        default_cont_specs = {
            "initial_weight": (1.0, 50.0),
            "lambda_risk": (0.2, 4.0),
            "lambda_smooth": (0.1, 3.0),
            "lambda_bonus": (0.0, 2.0),
        }
        enabled_cont = args_in_ckpt.get('enabled_continuous') or list(default_cont_specs.keys())
        enabled_disc = args_in_ckpt.get('enabled_discrete') or ["frontier_radius", "recent_visited_len"]

        cont_specs = {k: v for k, v in default_cont_specs.items() if k in enabled_cont}
        disc_specs = {"frontier_radius": [2, 3, 4, 5, 6], "recent_visited_len": [10, 20, 30, 40, 50]}
        disc_specs = {k: v for k, v in disc_specs.items() if k in enabled_disc}

        model = FocusParamNet(input_dim=4, continuous_specs=cont_specs, discrete_specs=disc_specs)
        model.load_state_dict(checkpoint['model_state'], strict=False)
        model.eval()

        # 加载数据
        dataset = FocusParamDataset(data_path, continuous_params=enabled_cont, discrete_params=enabled_disc)
        dataloader = torch.utils.data.DataLoader(dataset, batch_size=32, shuffle=False,
                                                collate_fn=dataset.collate_fn)

        return model, dataloader, enabled_cont

    def collect_predictions_with_features(self, model, dataloader, enabled_cont):
        """收集预测结果和特征"""
        all_predictions = {param: [] for param in enabled_cont}
        all_targets = {param: [] for param in enabled_cont}
        all_uncertainties = {param: [] for param in enabled_cont}
        all_features = {param: [] for param in enabled_cont}

        with torch.no_grad():
            for batch in dataloader:
                if not any(param in batch['targets_cont'] for param in enabled_cont):
                    continue

                features = batch['features']
                mc_pred = model.predict_with_uncertainty(features, mc_times=20)

                # 收集连续参数结果
                for param in enabled_cont:
                    if param in batch['targets_cont']:
                        all_predictions[param].extend(mc_pred[param].cpu().numpy())
                        all_targets[param].extend(batch['targets_cont'][param].cpu().numpy())
                        all_uncertainties[param].extend(torch.sqrt(mc_pred[f"{param}_var"]).cpu().numpy())
                        # 重复特征以匹配样本数
                        all_features[param].extend(features.cpu().numpy())

        return all_predictions, all_targets, all_uncertainties, all_features

    def evaluate_parameter_methods(self, param: str, predictions: np.ndarray,
                                 uncertainties: np.ndarray, targets: np.ndarray,
                                 features: np.ndarray) -> Dict[str, Any]:
        """评估单个参数的所有校准方法"""

        param_results = {}

        # 分割训练/测试集
        train_idx, test_idx = train_test_split(
            range(len(predictions)), test_size=0.2, random_state=42
        )

        train_pred = predictions[train_idx]
        train_uncert = uncertainties[train_idx]
        train_target = targets[train_idx]
        train_features = features[train_idx]

        test_pred = predictions[test_idx]
        test_uncert = uncertainties[test_idx]
        test_target = targets[test_idx]
        test_features = features[test_idx]

        # 评估每种方法
        for method_name, method_class in self.methods.items():
            try:
                start_time = time.time()

                if method_name == 'original':
                    # 原始方法不需要训练
                    calibrated_uncert = test_uncert.copy()
                    training_time = 0.0
                else:
                    # 训练校准器
                    calibrator = method_class()

                    # 根据方法类型传递不同参数
                    if method_name in ['adaptive', 'robust']:
                        calibrator.fit(train_pred, train_uncert, train_target, train_features)
                    else:
                        calibrator.fit(train_pred, train_uncert, train_target)

                    # 校准测试集
                    if method_name in ['adaptive', 'robust']:
                        calibrated_uncert = calibrator.calibrate(test_uncert, test_features)
                    elif method_name == 'conditional':
                        calibrated_uncert = calibrator.calibrate(test_uncert, test_pred)
                    else:
                        calibrated_uncert = calibrator.calibrate(test_uncert)

                    training_time = time.time() - start_time

                # 评估校准质量
                metrics = self.evaluate_calibration_quality(
                    test_pred, calibrated_uncert, test_target
                )
                metrics['training_time'] = training_time

                param_results[method_name] = metrics
                print(f"  {method_name}: ECE={metrics['ece']:.3f}, Coverage_68={metrics['coverage_68']:.3f}, Time={training_time:.3f}s")

            except Exception as e:
                print(f"  {method_name}: 失败 - {e}")
                param_results[method_name] = {
                    'ece': float('nan'),
                    'coverage_68': float('nan'),
                    'coverage_95': float('nan'),
                    'nll': float('nan'),
                    'training_time': float('nan'),
                    'error': str(e)
                }

        return param_results

    def evaluate_calibration_quality(self, predictions: np.ndarray,
                                   uncertainties: np.ndarray,
                                   targets: np.ndarray) -> Dict[str, float]:
        """评估校准质量"""

        # ECE (期望校准误差)
        n_bins = 10
        bin_boundaries = np.linspace(0, np.max(uncertainties), n_bins + 1)
        bin_boundaries[-1] += 1e-8

        ece = 0.0
        total_samples = 0

        for i in range(n_bins):
            mask = (uncertainties > bin_boundaries[i]) & (uncertainties <= bin_boundaries[i + 1])
            if not np.any(mask):
                continue

            bin_size = np.sum(mask)
            bin_uncertainties = uncertainties[mask]
            bin_predictions = predictions[mask]
            bin_targets = targets[mask]

            # 68% 覆盖率
            coverage = np.mean(np.abs(bin_predictions - bin_targets) <= bin_uncertainties)
            expected_coverage = 0.68

            ece += bin_size * abs(coverage - expected_coverage)
            total_samples += bin_size

        ece = ece / total_samples if total_samples > 0 else 0.0

        # 总体覆盖率
        overall_coverage_68 = np.mean(np.abs(predictions - targets) <= uncertainties)
        overall_coverage_95 = np.mean(np.abs(predictions - targets) <= 1.96 * uncertainties)

        # NLL
        nll = 0.5 * np.log(2 * np.pi * uncertainties**2) + \
              0.5 * ((predictions - targets)**2 / uncertainties**2)
        avg_nll = np.mean(nll)

        # 额外指标
        rmse = np.sqrt(np.mean((predictions - targets)**2))
        mae = np.mean(np.abs(predictions - targets))

        # 校准曲线相关性
        errors = np.abs(predictions - targets)
        calibration_correlation = np.corrcoef(uncertainties, errors)[0, 1]

        return {
            'ece': ece,
            'coverage_68': overall_coverage_68,
            'coverage_95': overall_coverage_95,
            'nll': avg_nll,
            'rmse': rmse,
            'mae': mae,
            'calibration_correlation': calibration_correlation
        }

    def generate_comparison_report(self):
        """生成比较报告"""

        print("\n" + "="*80)
        print("📊 高级校准方法比较报告")
        print("="*80)

        # 收集所有结果
        all_results = []
        for param, param_results in self.results.items():
            for method, metrics in param_results.items():
                if 'error' not in metrics:
                    all_results.append({
                        'parameter': param,
                        'method': method,
                        **metrics
                    })

        if not all_results:
            print("没有有效的评估结果")
            return

        df = pd.DataFrame(all_results)

        # 按参数分组显示结果
        for param in df['parameter'].unique():
            param_df = df[df['parameter'] == param]

            print(f"\n🔹 参数: {param}")
            print("-" * 50)

            # 排序：按ECE升序
            sorted_df = param_df.sort_values('ece')

            for _, row in sorted_df.iterrows():
                method = row['method']
                ece = row['ece']
                coverage_68 = row['coverage_68']
                coverage_95 = row['coverage_95']
                nll = row['nll']
                train_time = row['training_time']

                status = "✅" if ece == sorted_df['ece'].min() else "  "

                print(f"{status} {method:<12}: ECE={ece:.3f}, Cov68={coverage_68:.3f}, "
                      f"Cov95={coverage_95:.3f}, NLL={nll:.3f}, Time={train_time:.3f}s")

        # 总体统计
        print(f"\n📈 总体统计")
        print("-" * 30)

        method_stats = df.groupby('method').agg({
            'ece': ['mean', 'std', 'min'],
            'coverage_68': 'mean',
            'training_time': 'mean'
        }).round(4)

        print("平均ECE (越低越好):")
        ece_means = method_stats['ece']['mean'].sort_values()
        for method, mean_ece in ece_means.items():
            print(f"  {method:<12}: {mean_ece:.4f}")

        print("\n平均68%覆盖率 (越接近0.68越好):")
        cov_means = method_stats['coverage_68']['mean'].sort_values(key=lambda x: abs(x - 0.68))
        for method, mean_cov in cov_means.items():
            deviation = abs(mean_cov - 0.68)
            print(f"  {method:<12}: {mean_cov:.4f} (偏差: {deviation:.4f})")

        print("\n平均训练时间:")
        time_means = method_stats['training_time']['mean'].sort_values()
        for method, mean_time in time_means.items():
            print(f"  {method:<12}: {mean_time:.3f}s")

        # 最佳方法推荐
        best_methods = {}
        for param in df['parameter'].unique():
            param_df = df[df['parameter'] == param]
            best_method = param_df.loc[param_df['ece'].idxmin(), 'method']
            best_methods[param] = best_method

        print(f"\n🏆 最佳方法推荐:")
        for param, method in best_methods.items():
            print(f"  {param}: {method}")

        print("\n" + "="*80)


def main():
    parser = argparse.ArgumentParser(description="高级校准方法评估")
    parser.add_argument('--model', type=str, required=True, help='模型路径')
    parser.add_argument('--data', type=str, required=True, help='数据集路径')
    parser.add_argument('--output', type=str, default='advanced_calibration_results.json',
                       help='输出结果路径')

    args = parser.parse_args()

    evaluator = AdvancedCalibrationEvaluator()
    evaluator.evaluate_all_methods(args.model, args.data, args.output)


if __name__ == "__main__":
    main()