#!/usr/bin/env python3
"""
训练贝叶斯校准模型

使用校准基准测试的结果来训练贝叶斯校准模型，用于校准FocusParamNet的预测结果。
"""

import sys
import os
import argparse
import pickle
import numpy as np
from pathlib import Path
from typing import Dict, List, Any

# 添加项目根目录到Python路径
sys.path.append(str(Path(__file__).parent.parent))

from advanced_calibration import BayesianCalibration


def load_calibration_data(data_path: str) -> Dict[str, Dict[str, Any]]:
    """从校准基准测试结果中加载数据"""
    import json

    with open(data_path, 'r', encoding='utf-8') as f:
        results = json.load(f)

    # 提取训练数据
    calibration_data = {}

    # 从traditional_methods组中提取数据（因为它有最简单的结构）
    if 'traditional_methods' in results:
        for param_name, param_data in results['traditional_methods'].items():
            if param_name in ['initial_weight', 'lambda_risk', 'lambda_smooth', 'lambda_bonus']:
                # 提取预测值和目标值
                predictions = []
                targets = []

                # 这里需要从实际的基准测试结果中提取数据
                # 由于结果文件格式，我们需要重新运行数据收集
                print(f"参数 {param_name}: 需要重新收集训练数据")

    return calibration_data


def collect_training_data(model_path: str, data_path: str) -> Dict[str, Dict[str, np.ndarray]]:
    """收集校准训练数据"""
    from meta.calibration_benchmark import CalibrationBenchmark
    import pandas as pd

    print("🔄 收集校准训练数据...")

    # 创建基准测试实例
    benchmark = CalibrationBenchmark()

    # 加载模型和数据
    model, dataloader, enabled_cont = benchmark.load_model_and_data(model_path, data_path)

    # 收集预测结果
    all_predictions, all_targets, all_uncertainties, all_features = benchmark.collect_predictions_with_features(
        model, dataloader, enabled_cont
    )

    # 准备校准训练数据
    training_data = {}
    for param in ['initial_weight', 'lambda_risk', 'lambda_smooth', 'lambda_bonus']:
        if param in all_predictions and len(all_predictions[param]) > 0:
            predictions = np.array(all_predictions[param])
            targets = np.array(all_targets[param])
            uncertainties = np.array(all_uncertainties[param])

            training_data[param] = {
                'predictions': predictions,
                'targets': targets,
                'uncertainties': uncertainties,
                'features': np.array(all_features[param])
            }
            print(f"📊 参数 {param}: {len(predictions)} 个训练样本")

    return training_data


def train_bayesian_calibration(training_data: Dict[str, Dict[str, np.ndarray]],
                              output_dir: str) -> Dict[str, BayesianCalibration]:
    """训练贝叶斯校准模型"""
    print("🎯 训练贝叶斯校准模型...")

    calibration_models = {}
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    for param_name, data in training_data.items():
        print(f"🔧 训练参数 {param_name} 的校准模型...")

        try:
            # 创建贝叶斯校准器
            calibrator = BayesianCalibration()

            # 准备训练数据
            predictions = data['predictions']
            targets = data['targets']
            uncertainties = data['uncertainties']

            # 训练校准模型
            calibrator.fit(predictions, targets, uncertainties)

            # 保存模型
            model_path = output_path / f"{param_name}_bayesian.pkl"
            with open(model_path, 'wb') as f:
                pickle.dump(calibrator, f)

            calibration_models[param_name] = calibrator
            print(f"✅ 参数 {param_name} 校准模型训练完成")

        except Exception as e:
            print(f"❌ 参数 {param_name} 校准训练失败: {e}")
            continue

    print(f"💾 校准模型已保存到: {output_dir}")
    return calibration_models


def evaluate_calibration_models(calibration_models: Dict[str, BayesianCalibration],
                               training_data: Dict[str, Dict[str, np.ndarray]]):
    """评估校准模型性能"""
    print("📈 评估校准模型性能...")

    for param_name, calibrator in calibration_models.items():
        if param_name not in training_data:
            continue

        data = training_data[param_name]
        predictions = data['predictions']
        targets = data['targets']

        try:
            # 应用校准
            calibrated_predictions = calibrator.calibrate(predictions.reshape(-1, 1))

            # 计算校准后的ECE
            from meta.calibration_benchmark import CalibrationBenchmark
            benchmark = CalibrationBenchmark()

            ece = benchmark.compute_calibration_error(
                calibrated_predictions.flatten(),
                np.sqrt(np.abs(predictions - targets)),  # 简化的不确定性估计
                targets
            )

            print(f"📊 参数 {param_name}: ECE = {ece:.4f}")

        except Exception as e:
            print(f"❌ 参数 {param_name} 评估失败: {e}")


def main():
    parser = argparse.ArgumentParser(description="训练贝叶斯校准模型")
    parser.add_argument('--model', type=str, required=True, help='FocusParamNet模型路径')
    parser.add_argument('--data', type=str, required=True, help='训练数据集路径')
    parser.add_argument('--output', type=str, default='meta/models/calibration', help='校准模型输出目录')

    args = parser.parse_args()

    print("🚀 开始训练贝叶斯校准模型")
    print(f"模型: {args.model}")
    print(f"数据: {args.data}")
    print(f"输出: {args.output}")

    # 收集训练数据
    training_data = collect_training_data(args.model, args.data)

    if not training_data:
        print("❌ 无法收集训练数据")
        return

    # 训练校准模型
    calibration_models = train_bayesian_calibration(training_data, args.output)

    if calibration_models:
        # 评估校准模型
        evaluate_calibration_models(calibration_models, training_data)

        print("🎉 贝叶斯校准模型训练完成！")
    else:
        print("❌ 校准模型训练失败")


if __name__ == "__main__":
    main()