import sys
from pathlib import Path

MD = Path('meta/figs/report.md')
OUT = Path('meta/figs/report.pdf')

def main():
    if not MD.exists():
        print('report.md not found, abort')
        sys.exit(1)
    text = MD.read_text(encoding='utf-8')

    # try fpdf first
    try:
        from fpdf import FPDF

        pdf = FPDF()
        pdf.set_auto_page_break(auto=True, margin=15)
        pdf.add_page()
        pdf.set_font('Arial', size=12)
        for line in text.splitlines():
            # very simple wrapping
            if len(line) == 0:
                pdf.ln(6)
                continue
            pdf.multi_cell(0, 6, line)
        pdf.output(str(OUT))
        print('Wrote PDF via fpdf to', OUT)
        return
    except Exception:
        pass

    # fallback: write plain text and inform user how to convert
    txt_out = Path('meta/figs/report.txt')
    txt_out.write_text(text, encoding='utf-8')
    print('fpdf not available. Wrote plain text to', txt_out)
    print('To make a PDF, install pandoc+LaTeX or install fpdf (pip install fpdf) and re-run this script.')

if __name__ == '__main__':
    main()
