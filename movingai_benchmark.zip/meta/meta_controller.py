"""meta_controller.py
元策略控制器：根据地图特征（+可选运行中反馈）输出搜索/优化的参数集合。
当前为 rule+MLP 混合：
- 快速可用：未训练时使用 rule_based_init
- 可扩展：后续可添加训练收集与保存/加载
"""
from __future__ import annotations
import numpy as np
from typing import Dict, Any, Optional

try:
    import torch
    import torch.nn as nn
    TORCH_AVAILABLE = True
except Exception:
    TORCH_AVAILABLE = False

PARAM_BOUNDS = {
    'initial_weight': (1.0, 40.0),
    'lambda_risk': (0.1, 3.0),
    'lambda_smooth': (0.1, 2.0),
    'lambda_bonus': (0.0, 2.0),
    'frontier_radius': (2, 8),
    'recent_visited_len': (10, 120),
    'curvature_window': (2, 6),
    'risk_power': (1.0, 2.0),
}

FEATURE_ORDER = [
    'height','width','obstacle_ratio','free_ratio','dist_mean','dist_std','dist_min',
    'dist_p25','dist_p50','dist_p75','num_components','largest_component_ratio',
    'narrow_region_ratio','approx_path_len','approx_reachable','start_goal_euclid',
    'start_local_free','goal_local_free','row_entropy','col_entropy'
]

class SimpleMLP(nn.Module):
    def __init__(self, in_dim: int, hidden: int = 64, out_dim: int = 8, use_multi_head: bool = False):
        super().__init__()
        self.use_multi_head = use_multi_head
        self.out_dim = out_dim
        
        if use_multi_head:
            # 多头架构：按参数功能分组
            # Group 1: 探索参数 (initial_weight, lambda_bonus, frontier_radius)
            # Group 2: 稳定参数 (lambda_risk, recent_visited_len, risk_power)  
            # Group 3: 平滑参数 (lambda_smooth, curvature_window)
            self.shared_backbone = nn.Sequential(
                nn.Linear(in_dim, hidden), nn.ReLU(),
                nn.Linear(hidden, hidden), nn.ReLU()
            )
            self.head_exploration = nn.Linear(hidden, 3)  # initial_weight, lambda_bonus, frontier_radius
            self.head_stability = nn.Linear(hidden, 3)    # lambda_risk, recent_visited_len, risk_power
            self.head_smoothness = nn.Linear(hidden, 2)   # lambda_smooth, curvature_window
        else:
            # 标准单头架构
            self.net = nn.Sequential(
                nn.Linear(in_dim, hidden), nn.ReLU(),
                nn.Linear(hidden, hidden), nn.ReLU(),
                nn.Linear(hidden, out_dim)
            )
    
    def forward(self, x):
        if self.use_multi_head:
            shared = self.shared_backbone(x)
            head1 = self.head_exploration(shared)  # [initial_weight, lambda_bonus, frontier_radius]
            head2 = self.head_stability(shared)    # [lambda_risk, recent_visited_len, risk_power]  
            head3 = self.head_smoothness(shared)   # [lambda_smooth, curvature_window]
            # 重新排列为标准参数顺序: [initial_weight, lambda_risk, lambda_smooth, lambda_bonus, frontier_radius, recent_visited_len, curvature_window, risk_power]
            out = torch.cat([
                head1[:, 0:1],  # initial_weight
                head2[:, 0:1],  # lambda_risk
                head3[:, 0:1],  # lambda_smooth
                head1[:, 1:2],  # lambda_bonus
                head1[:, 2:3],  # frontier_radius
                head2[:, 1:2],  # recent_visited_len
                head3[:, 1:2],  # curvature_window
                head2[:, 2:3],  # risk_power
            ], dim=1)
            return out
        else:
            return self.net(x)

class MetaController:
    def __init__(self, use_mlp: bool = True, direct_mode: bool = False, delta_mode: bool = False, use_multi_head: bool = False, use_calibration: bool = False):
        """模式说明:
        direct_mode=True: MLP 输出归一化绝对参数 (0~1) -> 映射到范围
        delta_mode=True:  MLP 输出残差 delta_scaled (-1~1) -> 反缩放后加到 rule 基线
        use_multi_head=True: 使用多头架构，按参数功能分组
        use_calibration=True: 使用贝叶斯校准来校准模型预测
        若两者都 False:  使用 rule + 相对 multiplicative 调整 (旧逻辑)
        二者不应同时 True (优先 direct)。
        """
        self.use_mlp = use_mlp and TORCH_AVAILABLE
        self.direct_mode = direct_mode
        self.delta_mode = False if direct_mode else delta_mode
        self.use_multi_head = use_multi_head
        self.use_calibration = use_calibration
        self.model: Optional[SimpleMLP] = None
        self.scaler_mean: Optional[np.ndarray] = None
        self.scaler_std: Optional[np.ndarray] = None
        self.trained_delta_flag: bool = False  # 从 scaler 文件读取

        # 校准相关属性
        self.calibration_models: Dict[str, Any] = {}  # 参数名 -> 校准模型
        self.calibration_method: str = 'bayesian'  # 默认使用贝叶斯校准

        if self.use_mlp:
            self.model = SimpleMLP(in_dim=len(FEATURE_ORDER), hidden=96, out_dim=8, use_multi_head=use_multi_head)

    def rule_based_init(self, feats: Dict[str,float]) -> Dict[str, Any]:
        """基于直觉的规则：根据地图拥挤程度/路径可行性调参"""
        obstacle_ratio = feats['obstacle_ratio']
        narrow_ratio = feats['narrow_region_ratio']
        reachable = feats['approx_reachable'] > 0.5

        # 初始启发式权重：拥挤时调高以更贪心
        if obstacle_ratio < 0.15:
            init_w = 12.0
        elif obstacle_ratio < 0.25:
            init_w = 18.0
        elif obstacle_ratio < 0.35:
            init_w = 24.0
        else:
            init_w = 30.0

        # 风险系数：狭窄区域多时增大风险规避
        lambda_risk = 0.8 + 1.5 * min(1.0, narrow_ratio)

        # 平滑系数：如果路径估计长度很长且地图多弯，适度加大平滑惩罚
        lambda_smooth = 0.4 + 0.6 * (obstacle_ratio)  # 粗略线性

        # 探索奖励：当存在多个连通块或可行性不明确时提升
        lambda_bonus = 0.3 + 0.7 * (1.0 - feats['largest_component_ratio'])

        # 前沿窗口：大地图或者障碍多时加大
        frontier_radius = int(np.clip(3 + (obstacle_ratio*10), 2, 8))

        # 防震荡窗口大小：路径估计长 → 增大
        recent_visited_len = int(np.clip(30 + feats['start_goal_euclid']*1.5, 10, 120))

        curvature_window = 3 if obstacle_ratio < 0.3 else 4

        risk_power = 1.1 + 0.6 * narrow_ratio

        return {
            'initial_weight': init_w,
            'lambda_risk': lambda_risk,
            'lambda_smooth': lambda_smooth,
            'lambda_bonus': lambda_bonus,
            'frontier_radius': frontier_radius,
            'recent_visited_len': recent_visited_len,
            'curvature_window': curvature_window,
            'risk_power': risk_power,
            'min_weight': 1.0,
        }

    def mlp_adjust(self, feats: Dict[str,float], base: Dict[str,Any]) -> Dict[str,Any]:
        if not self.model:
            return base
        self.model.eval()
        with torch.no_grad():
            vec = np.array([feats[k] for k in FEATURE_ORDER], dtype=np.float32)
            t = torch.from_numpy(vec).unsqueeze(0)
            out = self.model(t).squeeze(0).numpy()
        # 输出8维，对应 base 中的8个主参数的相对调整因子（-0.5~0.5 sigmoid 映射）
        adj = 1.0 / (1.0 + np.exp(-out))  # sigmoid 0~1
        adj = (adj - 0.5) * 1.0  # -> -0.5~0.5
        keys = ['initial_weight','lambda_risk','lambda_smooth','lambda_bonus','frontier_radius','recent_visited_len','curvature_window','risk_power']
        for i,k in enumerate(keys):
            low, high = PARAM_BOUNDS[k]
            raw = base[k] * (1.0 + adj[i])
            # 对整数型参数四舍五入
            if k in ['frontier_radius','recent_visited_len','curvature_window']:
                raw = int(round(raw))
            base[k] = float(np.clip(raw, low, high)) if k not in ['frontier_radius','recent_visited_len','curvature_window'] else int(np.clip(raw, low, high))
        return base

    def get_params(self, feats: Dict[str,float]) -> Dict[str,Any]:
        if self.use_mlp and self.direct_mode:
            params = self.predict_absolute(feats)
        elif self.use_mlp and (self.delta_mode or self.trained_delta_flag):
            params = self.predict_delta(feats)
        else:
            base = self.rule_based_init(feats)
            if self.use_mlp and not self.direct_mode and not self.delta_mode:
                params = self.mlp_adjust(feats, base)
            else:
                params = base

        # 应用校准（如果启用）
        if self.use_calibration and self.calibration_models:
            # 为校准准备预测值和不确定性
            predictions = {k: v for k, v in params.items() if k in ['initial_weight', 'lambda_risk', 'lambda_smooth', 'lambda_bonus']}
            uncertainties = {}  # 如果有不确定性估计，可以在这里添加

            # 应用校准
            calibrated_predictions = self.apply_calibration(predictions, uncertainties)

            # 更新参数
            params.update(calibrated_predictions)

        return params

    # ---- direct mode 支持 ----
    def predict_absolute(self, feats: Dict[str,float]) -> Dict[str,Any]:
        if not self.model:
            return self.rule_based_init(feats)
        self.model.eval()
        vec = np.array([feats[k] for k in FEATURE_ORDER], dtype=np.float32)
        if self.scaler_mean is not None and self.scaler_std is not None:
            # 确保 scaler dtype 一致
            mean = self.scaler_mean.astype(np.float32)
            std = self.scaler_std.astype(np.float32)
            vec = (vec - mean) / (std + 1e-6)
        import torch
        with torch.no_grad():
            tensor_in = torch.from_numpy(vec.astype(np.float32)).unsqueeze(0)
            out = self.model(tensor_in).squeeze(0).cpu().numpy()
        # sigmoid -> 0~1
        norm = 1.0 / (1.0 + np.exp(-out))
        keys = ['initial_weight','lambda_risk','lambda_smooth','lambda_bonus','frontier_radius','recent_visited_len','curvature_window','risk_power']
        params = {}
        for i,k in enumerate(keys):
            lo,hi = PARAM_BOUNDS[k]
            val = lo + (hi-lo) * norm[i]
            if k in ['frontier_radius','recent_visited_len','curvature_window']:
                val = int(round(val))
            params[k] = float(val) if k not in ['frontier_radius','recent_visited_len','curvature_window'] else val
        params['min_weight'] = 1.0
        return params

    def save(self, path: str, scaler_path: Optional[str]=None):
        if self.model:
            import torch
            torch.save(self.model.state_dict(), path)
        if scaler_path and self.scaler_mean is not None:
            np.savez(scaler_path, mean=self.scaler_mean, std=self.scaler_std, delta_mode=np.array([1 if (self.delta_mode or self.trained_delta_flag) else 0]))

    def load(self, path: str, scaler_path: Optional[str]=None):
        if self.model and PathExists(path):
            import torch
            try:
                # 尝试使用即将成为默认的安全方式
                self.model.load_state_dict(torch.load(path, map_location='cpu', weights_only=True))
            except TypeError:
                # 旧版本 torch 无 weights_only 参数
                self.model.load_state_dict(torch.load(path, map_location='cpu'))
            except Exception as e:
                print(f"[WARN] load model with weights_only failed: {e}, fallback normal load")
                self.model.load_state_dict(torch.load(path, map_location='cpu'))
        if scaler_path and PathExists(scaler_path):
            data = np.load(scaler_path)
            self.scaler_mean = data['mean'].astype(np.float32)
            self.scaler_std = data['std'].astype(np.float32)
            if 'delta_mode' in data:
                self.trained_delta_flag = bool(int(data['delta_mode'][0]))

    # ---- 校准支持 ----
    def load_calibration_models(self, calibration_dir: str):
        """加载校准模型"""
        if not self.use_calibration:
            return

        # 动态导入校准模块
        try:
            from advanced_calibration import BayesianCalibration
        except ImportError:
            try:
                from .advanced_calibration import BayesianCalibration
            except ImportError:
                print("[WARN] 无法导入BayesianCalibration，使用无校准模式")
                return

        import pickle
        import os
        from pathlib import Path

        calibration_path = Path(calibration_dir)
        if not calibration_path.exists():
            print(f"[WARN] 校准模型目录不存在: {calibration_dir}")
            return

        # 加载贝叶斯校准模型
        for param in ['initial_weight', 'lambda_risk', 'lambda_smooth', 'lambda_bonus']:
            model_path = calibration_path / f"{param}_bayesian.pkl"
            if model_path.exists():
                try:
                    with open(model_path, 'rb') as f:
                        self.calibration_models[param] = pickle.load(f)
                    print(f"[INFO] 加载校准模型: {param}")
                except Exception as e:
                    print(f"[WARN] 加载校准模型失败 {param}: {e}")

    def save_calibration_models(self, calibration_dir: str):
        """保存校准模型"""
        if not self.use_calibration or not self.calibration_models:
            return

        import pickle
        import os
        from pathlib import Path

        calibration_path = Path(calibration_dir)
        calibration_path.mkdir(parents=True, exist_ok=True)

        for param, model in self.calibration_models.items():
            model_path = calibration_path / f"{param}_bayesian.pkl"
            try:
                with open(model_path, 'wb') as f:
                    pickle.dump(model, f)
                print(f"[INFO] 保存校准模型: {param}")
            except Exception as e:
                print(f"[WARN] 保存校准模型失败 {param}: {e}")

    def apply_calibration(self, predictions: Dict[str, float], uncertainties: Dict[str, float] = None) -> Dict[str, float]:
        """应用贝叶斯校准到预测结果"""
        if not self.use_calibration or not self.calibration_models:
            return predictions

        calibrated_predictions = predictions.copy()

        for param in ['initial_weight', 'lambda_risk', 'lambda_smooth', 'lambda_bonus']:
            if param in self.calibration_models and param in predictions:
                try:
                    calibrator = self.calibration_models[param]
                    pred_value = predictions[param]

                    # 应用校准
                    calibrated_value = calibrator.calibrate(np.array([pred_value]))[0]
                    calibrated_predictions[param] = float(calibrated_value)

                except Exception as e:
                    print(f"[WARN] 校准参数 {param} 失败: {e}")
                    # 如果校准失败，使用原始预测

        return calibrated_predictions

    # ---- delta mode 支持 ----
    def predict_delta(self, feats: Dict[str,float]) -> Dict[str,Any]:
        base = self.rule_based_init(feats)
        if not self.model:
            return base
        self.model.eval()
        vec = np.array([feats[k] for k in FEATURE_ORDER], dtype=np.float32)
        if self.scaler_mean is not None and self.scaler_std is not None:
            vec = (vec - self.scaler_mean.astype(np.float32)) / (self.scaler_std.astype(np.float32) + 1e-6)
        import torch
        with torch.no_grad():
            out = self.model(torch.from_numpy(vec).unsqueeze(0)).squeeze(0).cpu().numpy()
        # 训练阶段输出为 delta_scaled (目标范围 [-1,1])，此处使用 tanh 约束到 [-1,1]
        delta_scaled = np.tanh(out)
        keys = ['initial_weight','lambda_risk','lambda_smooth','lambda_bonus','frontier_radius','recent_visited_len','curvature_window','risk_power']
        for i,k in enumerate(keys):
            lo, hi = PARAM_BOUNDS[k]
            scale = (hi - lo)/2.0
            delta = delta_scaled[i] * scale
            new_val = base[k] + delta
            # 裁剪并针对整数参数取整
            if k in ['frontier_radius','recent_visited_len','curvature_window']:
                new_val = int(np.clip(round(new_val), lo, hi))
            else:
                new_val = float(np.clip(new_val, lo, hi))
            base[k] = new_val
        return base

def PathExists(p: str) -> bool:
    try:
        from pathlib import Path
        return Path(p).exists()
    except Exception:
        return False

if __name__ == "__main__":
    # 简单伪测试
    feats = {k:0.1 for k in FEATURE_ORDER}
    feats.update({'obstacle_ratio':0.28,'largest_component_ratio':0.6,'narrow_region_ratio':0.3,'start_goal_euclid':50,'approx_reachable':1.0})
    mc = MetaController(use_mlp=False)
    params = mc.get_params(feats)
    print(params)
