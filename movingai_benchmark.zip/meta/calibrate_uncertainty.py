#!/usr/bin/env python3
"""
不确定度校准改进脚本

实现多种校准技术来改善模型的不确定度估计：
1. 温度缩放 (Temperature Scaling)
2. 后处理校准 (Post-hoc Calibration)
3. 方差缩放 (Variance Scaling)
4. 混合校准 (Ensemble Calibration)
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__)))

import torch
import numpy as np
import json
from pathlib import Path
from typing import Dict, List, Tuple, Any, Optional
from sklearn.model_selection import train_test_split
from sklearn.isotonic import IsotonicRegression
from sklearn.linear_model import LinearRegression
import argparse

from models_arch.focus_param_net import FocusParamNet
from models_arch.focus_dataset import FocusParamDataset

class TemperatureScaling:
    """温度缩放校准器"""
    
    def __init__(self):
        self.temperature = torch.nn.Parameter(torch.ones(1))
        self.fitted = False
    
    def fit(self, predictions: np.ndarray, uncertainties: np.ndarray, targets: np.ndarray):
        """学习最优温度参数"""
        pred_tensor = torch.FloatTensor(predictions)
        uncert_tensor = torch.FloatTensor(uncertainties)
        target_tensor = torch.FloatTensor(targets)
        
        optimizer = torch.optim.LBFGS([self.temperature], lr=0.01, max_iter=50)
        
        def eval_loss():
            optimizer.zero_grad()
            # 缩放不确定度
            scaled_uncert = uncert_tensor * self.temperature
            # 负对数似然损失
            nll = 0.5 * torch.log(2 * torch.pi * scaled_uncert**2) + 0.5 * ((pred_tensor - target_tensor)**2 / scaled_uncert**2)
            loss = nll.mean()
            loss.backward()
            return loss
        
        optimizer.step(eval_loss)
        self.fitted = True
        print(f"温度缩放训练完成，最优温度: {self.temperature.item():.4f}")
    
    def calibrate(self, uncertainties: np.ndarray) -> np.ndarray:
        """应用温度缩放"""
        if not self.fitted:
            raise ValueError("温度缩放器尚未训练")
        with torch.no_grad():
            return uncertainties * self.temperature.item()

class VarianceScaling:
    """方差缩放校准器"""
    
    def __init__(self):
        self.scale_factor = 1.0
        self.fitted = False
    
    def fit(self, predictions: np.ndarray, uncertainties: np.ndarray, targets: np.ndarray):
        """学习方差缩放因子"""
        squared_errors = (predictions - targets) ** 2
        predicted_variances = uncertainties ** 2
        
        # 使用线性回归学习缩放因子
        reg = LinearRegression(fit_intercept=False)
        reg.fit(predicted_variances.reshape(-1, 1), squared_errors)
        
        self.scale_factor = float(reg.coef_[0])
        self.fitted = True
        print(f"方差缩放训练完成，缩放因子: {self.scale_factor:.4f}")
    
    def calibrate(self, uncertainties: np.ndarray) -> np.ndarray:
        """应用方差缩放"""
        if not self.fitted:
            raise ValueError("方差缩放器尚未训练")
        return uncertainties * np.sqrt(self.scale_factor)

class IsotonicCalibration:
    """等温回归校准器"""
    
    def __init__(self):
        self.calibrator = IsotonicRegression(out_of_bounds='clip')
        self.fitted = False
    
    def fit(self, predictions: np.ndarray, uncertainties: np.ndarray, targets: np.ndarray):
        """学习等温映射"""
        # 计算标准化误差
        normalized_errors = np.abs(predictions - targets) / (uncertainties + 1e-8)
        
        # 将不确定度映射到实际误差分位数
        actual_quantiles = []
        for i, uncert in enumerate(uncertainties):
            # 计算该不确定度水平下的实际覆盖率
            similar_uncert_mask = np.abs(uncertainties - uncert) < 0.1 * uncert
            if np.sum(similar_uncert_mask) > 5:  # 至少5个样本
                similar_errors = normalized_errors[similar_uncert_mask]
                coverage = np.mean(similar_errors <= 1.0)  # 1σ 覆盖率
                actual_quantiles.append(coverage)
            else:
                actual_quantiles.append(0.68)  # 默认值
        
        # 训练等温回归
        self.calibrator.fit(uncertainties, actual_quantiles)
        self.fitted = True
        print("等温回归校准训练完成")
    
    def calibrate(self, uncertainties: np.ndarray) -> np.ndarray:
        """应用等温校准"""
        if not self.fitted:
            raise ValueError("等温校准器尚未训练")
        
        # 获取校准后的覆盖率
        calibrated_coverage = self.calibrator.predict(uncertainties)
        
        # 将覆盖率转换回不确定度（假设正态分布）
        # 68% 覆盖率对应1σ，所以我们需要反向计算
        z_scores = np.where(calibrated_coverage > 0.5, 
                           np.sqrt(2) * np.sqrt(-np.log(1 - calibrated_coverage + 1e-8)),
                           1.0)
        
        return uncertainties * z_scores

def load_model_and_data(model_path: str, data_path: str):
    """加载模型和数据"""
    # 加载模型
    checkpoint = torch.load(model_path, map_location='cpu')
    args_in_ckpt = checkpoint.get('args', {}) or {}
    
    # 获取启用的参数
    default_cont_specs = {
        "initial_weight": (1.0, 50.0),
        "lambda_risk": (0.2, 4.0),
        "lambda_smooth": (0.1, 3.0),
        "lambda_bonus": (0.0, 2.0),
    }
    enabled_cont = args_in_ckpt.get('enabled_continuous') or list(default_cont_specs.keys())
    enabled_disc = args_in_ckpt.get('enabled_discrete') or ["frontier_radius", "recent_visited_len"]
    
    cont_specs = {k: v for k, v in default_cont_specs.items() if k in enabled_cont}
    disc_specs = {"frontier_radius": [2, 3, 4, 5, 6], "recent_visited_len": [10, 20, 30, 40, 50]}
    disc_specs = {k: v for k, v in disc_specs.items() if k in enabled_disc}
    
    model = FocusParamNet(input_dim=4, continuous_specs=cont_specs, discrete_specs=disc_specs)
    model.load_state_dict(checkpoint['model_state'], strict=False)
    model.eval()
    
    # 加载数据
    dataset = FocusParamDataset(data_path, continuous_params=enabled_cont, discrete_params=enabled_disc)
    dataloader = torch.utils.data.DataLoader(dataset, batch_size=32, shuffle=False, 
                                            collate_fn=dataset.collate_fn)
    
    return model, dataloader, enabled_cont

def collect_predictions(model: FocusParamNet, dataloader, enabled_cont: List[str]):
    """收集模型预测和不确定度"""
    all_predictions = {param: [] for param in enabled_cont}
    all_targets = {param: [] for param in enabled_cont}
    all_uncertainties = {param: [] for param in enabled_cont}
    
    with torch.no_grad():
        for batch in dataloader:
            features = batch['features']
            
            # 标准预测
            mc_pred = model.predict_with_uncertainty(features, mc_times=20)
            
            # 收集连续参数结果
            for param in enabled_cont:
                if param in batch['targets_cont']:
                    all_predictions[param].extend(mc_pred[param].numpy())
                    all_targets[param].extend(batch['targets_cont'][param].numpy())
                    all_uncertainties[param].extend(torch.sqrt(mc_pred[f"{param}_var"]).numpy())
    
    return all_predictions, all_targets, all_uncertainties

def evaluate_calibration(predictions: np.ndarray, uncertainties: np.ndarray, targets: np.ndarray) -> Dict[str, float]:
    """评估校准质量"""
    # ECE (期望校准误差)
    n_bins = 10
    bin_boundaries = np.linspace(0, np.max(uncertainties), n_bins + 1)
    bin_boundaries[-1] += 1e-8
    
    ece = 0.0
    total_samples = 0
    
    for i in range(n_bins):
        mask = (uncertainties > bin_boundaries[i]) & (uncertainties <= bin_boundaries[i + 1])
        if not np.any(mask):
            continue
            
        bin_size = np.sum(mask)
        bin_uncertainties = uncertainties[mask]
        bin_predictions = predictions[mask]
        bin_targets = targets[mask]
        
        # 68% 覆盖率
        coverage = np.mean(np.abs(bin_predictions - bin_targets) <= bin_uncertainties)
        expected_coverage = 0.68
        
        ece += bin_size * abs(coverage - expected_coverage)
        total_samples += bin_size
    
    ece = ece / total_samples if total_samples > 0 else 0.0
    
    # 总体覆盖率
    overall_coverage_68 = np.mean(np.abs(predictions - targets) <= uncertainties)
    overall_coverage_95 = np.mean(np.abs(predictions - targets) <= 1.96 * uncertainties)
    
    # NLL
    nll = 0.5 * np.log(2 * np.pi * uncertainties**2) + 0.5 * ((predictions - targets)**2 / uncertainties**2)
    avg_nll = np.mean(nll)
    
    return {
        'ece': ece,
        'coverage_68': overall_coverage_68,
        'coverage_95': overall_coverage_95,
        'nll': avg_nll
    }

def main():
    parser = argparse.ArgumentParser(description="不确定度校准改进")
    parser.add_argument('--model', type=str, required=True, help='模型路径')
    parser.add_argument('--data', type=str, required=True, help='数据集路径')
    parser.add_argument('--output', type=str, default='calibration_results.json', help='输出结果路径')
    parser.add_argument('--method', type=str, choices=['temperature', 'variance', 'isotonic', 'all'], 
                       default='all', help='校准方法')
    
    args = parser.parse_args()
    
    print(f"🔧 开始不确定度校准改进")
    print(f"模型: {args.model}")
    print(f"数据: {args.data}")
    
    # 加载模型和数据
    model, dataloader, enabled_cont = load_model_and_data(args.model, args.data)
    print(f"启用参数: {enabled_cont}")
    
    # 收集预测结果
    print("📊 收集模型预测...")
    all_predictions, all_targets, all_uncertainties = collect_predictions(model, dataloader, enabled_cont)
    
    results = {}
    
    for param in enabled_cont:
        if len(all_predictions[param]) == 0:
            continue
            
        print(f"\n🎯 校准参数: {param}")
        
        pred_arr = np.array(all_predictions[param])
        target_arr = np.array(all_targets[param])
        uncert_arr = np.array(all_uncertainties[param])
        
        # 分割训练/测试集用于校准
        train_idx, test_idx = train_test_split(range(len(pred_arr)), test_size=0.2, random_state=42)
        
        train_pred = pred_arr[train_idx]
        train_target = target_arr[train_idx]
        train_uncert = uncert_arr[train_idx]
        
        test_pred = pred_arr[test_idx]
        test_target = target_arr[test_idx]
        test_uncert = uncert_arr[test_idx]
        
        param_results = {}
        
        # 原始性能
        original_metrics = evaluate_calibration(test_pred, test_uncert, test_target)
        param_results['original'] = original_metrics
        print(f"原始: ECE={original_metrics['ece']:.3f}, Coverage_68={original_metrics['coverage_68']:.3f}")
        
        # 应用不同校准方法
        if args.method in ['temperature', 'all']:
            try:
                temp_calibrator = TemperatureScaling()
                temp_calibrator.fit(train_pred, train_uncert, train_target)
                calibrated_uncert = temp_calibrator.calibrate(test_uncert)
                temp_metrics = evaluate_calibration(test_pred, calibrated_uncert, test_target)
                param_results['temperature'] = temp_metrics
                print(f"温度缩放: ECE={temp_metrics['ece']:.3f}, Coverage_68={temp_metrics['coverage_68']:.3f}")
            except Exception as e:
                print(f"温度缩放失败: {e}")
        
        if args.method in ['variance', 'all']:
            try:
                var_calibrator = VarianceScaling()
                var_calibrator.fit(train_pred, train_uncert, train_target)
                calibrated_uncert = var_calibrator.calibrate(test_uncert)
                var_metrics = evaluate_calibration(test_pred, calibrated_uncert, test_target)
                param_results['variance'] = var_metrics
                print(f"方差缩放: ECE={var_metrics['ece']:.3f}, Coverage_68={var_metrics['coverage_68']:.3f}")
            except Exception as e:
                print(f"方差缩放失败: {e}")
        
        if args.method in ['isotonic', 'all']:
            try:
                iso_calibrator = IsotonicCalibration()
                iso_calibrator.fit(train_pred, train_uncert, train_target)
                calibrated_uncert = iso_calibrator.calibrate(test_uncert)
                iso_metrics = evaluate_calibration(test_pred, calibrated_uncert, test_target)
                param_results['isotonic'] = iso_metrics
                print(f"等温回归: ECE={iso_metrics['ece']:.3f}, Coverage_68={iso_metrics['coverage_68']:.3f}")
            except Exception as e:
                print(f"等温回归失败: {e}")
        
        results[param] = param_results
    
    # 保存结果
    with open(args.output, 'w') as f:
        json.dump(results, f, indent=2, default=float)
    
    print(f"\n💾 校准结果已保存到: {args.output}")
    
    # 打印总结
    print(f"\n📋 校准改进总结:")
    for param, param_results in results.items():
        print(f"\n{param}:")
        for method, metrics in param_results.items():
            print(f"  {method}: ECE={metrics['ece']:.3f}, Coverage_68={metrics['coverage_68']:.3f}")

if __name__ == "__main__":
    main()