#!/usr/bin/env python3
"""
大规模数据采集脚本
基于meta.collect_meta_dataset的collect函数，支持多进程并行采集大量训练数据
"""
import argparse
import os
import sys
import time
import tempfile
import pickle
import numpy as np
from pathlib import Path
from typing import List, Dict, Any, Tuple
from concurrent.futures import ProcessPoolExecutor, as_completed
import multiprocessing as mp

# 添加项目根目录到Python路径
sys.path.append(str(Path(__file__).parent.parent))

def create_batch_config(batch_id: int, batch_size: int, base_seed: int = 42) -> argparse.Namespace:
    """为每个批次创建配置参数"""
    # 地图大小分布：small(30-45), medium(45-65), large(65-80)
    size_configs = [
        (30, 45),   # small
        (45, 65),   # medium  
        (65, 80)    # large
    ]
    
    # 障碍率分布：easy(0.10-0.25), medium(0.25-0.35), hard(0.35-0.45)
    obs_configs = [
        (0.10, 0.25),  # easy
        (0.25, 0.35),  # medium
        (0.35, 0.45)   # hard
    ]
    
    # 随机选择配置
    np.random.seed(base_seed + batch_id)
    size_min, size_max = size_configs[batch_id % len(size_configs)]
    obs_min, obs_max = obs_configs[(batch_id // len(size_configs)) % len(obs_configs)]
    
    # 随机生成具体尺寸
    rows = cols = np.random.randint(size_min, size_max + 1)
    
    # 创建配置对象
    args = argparse.Namespace()
    args.maps = batch_size
    args.param_trials = 25
    args.local_trials = 5  # 增加局部搜索
    args.local_scale = 0.08
    args.topk = 3  # 使用软标签
    args.soft_alpha = 25.0
    args.rows = rows
    args.cols = cols
    args.min_obs = obs_min
    args.max_obs = obs_max
    args.seed = base_seed + batch_id * 1000
    
    # 临时输出文件
    temp_dir = Path(f"meta/dataset/temp_batch_{batch_id}")
    temp_dir.mkdir(parents=True, exist_ok=True)
    args.output = str(temp_dir / f"batch_{batch_id}.csv")
    
    return args

def collect_batch_data(batch_config: Tuple[int, int, int]) -> Tuple[int, str, bool]:
    """收集单个批次的数据"""
    batch_id, batch_size, base_seed = batch_config
    
    try:
        # 导入collect函数
        from meta.collect_meta_dataset import collect
        
        # 创建批次配置
        args = create_batch_config(batch_id, batch_size, base_seed)
        
        print(f"开始处理批次 {batch_id}: {args.rows}x{args.cols}, 障碍率 {args.min_obs:.2f}-{args.max_obs:.2f}")
        
        # 执行数据收集
        start_time = time.time()
        collect(args)
        elapsed = time.time() - start_time
        
        # 检查输出文件
        output_path = Path(args.output)
        if output_path.exists():
            # 读取样本数量
            with open(output_path, 'r') as f:
                lines = f.readlines()
                sample_count = len(lines) - 1  # 减去表头
            
            print(f"✓ 批次 {batch_id} 完成: {sample_count} 样本, 用时 {elapsed:.1f}s")
            return batch_id, str(output_path), True
        else:
            print(f"✗ 批次 {batch_id} 失败: 无输出文件")
            return batch_id, "", False
            
    except Exception as e:
        print(f"✗ 批次 {batch_id} 异常: {e}")
        return batch_id, "", False

def merge_batch_results(batch_files: List[str], output_path: str) -> int:
    """合并所有批次结果"""
    all_records = []
    header = None
    
    for batch_file in batch_files:
        if not batch_file or not Path(batch_file).exists():
            continue
            
        with open(batch_file, 'r') as f:
            import csv
            reader = csv.DictReader(f)
            if header is None:
                header = reader.fieldnames
            
            for row in reader:
                all_records.append(row)
    
    if all_records and header:
        with open(output_path, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=header)
            writer.writeheader()
            writer.writerows(all_records)
        
        print(f"合并完成: {output_path} ({len(all_records)} 样本)")
        return len(all_records)
    
    return 0

def analyze_dataset_diversity(csv_path: str):
    """分析数据集多样性"""
    import pandas as pd
    
    try:
        df = pd.read_csv(csv_path)
        print(f"\n📊 数据集分析:")
        print(f"总样本数: {len(df)}")
        
        # 地图尺寸分布
        if 'height' in df.columns and 'width' in df.columns:
            size_stats = df['height'].describe()
            print(f"地图尺寸: {size_stats['min']:.0f}-{size_stats['max']:.0f} (平均: {size_stats['mean']:.1f})")
        
        # 障碍率分布
        if 'obstacle_ratio' in df.columns:
            obs_stats = df['obstacle_ratio'].describe()
            print(f"障碍率: {obs_stats['min']:.3f}-{obs_stats['max']:.3f} (平均: {obs_stats['mean']:.3f})")
        
        # 成功率
        if 'metric_success' in df.columns:
            success_rate = df['metric_success'].mean()
            print(f"成功率: {success_rate:.1%}")
        
        # 参数范围
        param_cols = [col for col in df.columns if col.startswith('param_')]
        if param_cols:
            print(f"参数列数: {len(param_cols)}")
            
    except Exception as e:
        print(f"分析失败: {e}")

def cleanup_temp_files():
    """清理临时文件"""
    temp_base = Path("meta/dataset")
    for temp_dir in temp_base.glob("temp_batch_*"):
        if temp_dir.is_dir():
            for file in temp_dir.iterdir():
                file.unlink()
            temp_dir.rmdir()
    print("临时文件清理完成")

def main():
    parser = argparse.ArgumentParser(description="大规模数据采集")
    parser.add_argument('--samples', type=int, default=1000, help='目标样本数')
    parser.add_argument('--workers', type=int, default=4, help='并行进程数')
    parser.add_argument('--batch-size', type=int, default=50, help='每批次样本数')
    parser.add_argument('--output', type=str, default='meta/dataset/large_dataset.csv', help='输出文件')
    parser.add_argument('--seed', type=int, default=42, help='随机种子')
    
    args = parser.parse_args()
    
    # 确保输出目录存在
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    # 计算批次配置
    num_batches = (args.samples + args.batch_size - 1) // args.batch_size
    batch_configs = [(i, args.batch_size, args.seed) for i in range(num_batches)]
    
    print(f"🚀 开始大规模数据采集")
    print(f"目标样本: {args.samples}, 批次数: {num_batches}, 并行度: {args.workers}")
    print(f"输出路径: {args.output}")
    
    start_time = time.time()
    successful_batches = []
    
    # 并行执行批次
    with ProcessPoolExecutor(max_workers=args.workers) as executor:
        # 提交所有任务
        future_to_batch = {executor.submit(collect_batch_data, config): config[0] 
                          for config in batch_configs}
        
        # 收集结果
        for future in as_completed(future_to_batch):
            batch_id, output_file, success = future.result()
            if success:
                successful_batches.append(output_file)
    
    total_time = time.time() - start_time
    
    print(f"\n📈 采集完成统计:")
    print(f"成功批次: {len(successful_batches)}/{num_batches}")
    print(f"总用时: {total_time:.1f}s")
    
    # 合并结果
    if successful_batches:
        total_samples = merge_batch_results(successful_batches, args.output)
        print(f"最终样本数: {total_samples}")
        
        # 分析数据集
        analyze_dataset_diversity(args.output)
        
        # 清理临时文件
        cleanup_temp_files()
        
        return total_samples
    else:
        print("❌ 没有成功的批次")
        return 0

if __name__ == "__main__":
    main()