#!/usr/bin/env python3
"""
生成随机对照数据集脚本

读取现有 focused 数据集的地图特征，为每个地图随机生成参数组合，
并评估这些随机参数的性能，生成与原数据集格式相同的随机参数数据集。
用于训练"随机基线"模型，与失败聚焦模型进行对比分析。
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

import json
import random
import numpy as np
from concurrent.futures import ProcessPoolExecutor
from typing import Dict, List, Any, Tuple
import argparse
from pathlib import Path

# 参数范围定义（与训练数据保持一致）
PARAM_RANGES = {
    "initial_weight": (1.0, 50.0),
    "lambda_risk": (0.2, 4.0), 
    "lambda_smooth": (0.1, 3.0),
    "lambda_bonus": (0.0, 2.0),
    "frontier_radius": [2, 3, 4, 5, 6],
    "recent_visited_len": [10, 20, 30, 40, 50],
}

def sample_random_parameters() -> Dict[str, Any]:
    """随机采样参数"""
    params = {}
    
    # 连续参数：均匀分布采样
    continuous_params = ["initial_weight", "lambda_risk", "lambda_smooth", "lambda_bonus"]
    for param in continuous_params:
        low, high = PARAM_RANGES[param]
        params[param] = random.uniform(low, high)
    
    # 离散参数：从选项中随机选择
    discrete_params = ["frontier_radius", "recent_visited_len"]
    for param in discrete_params:
        options = PARAM_RANGES[param]
        params[param] = random.choice(options)
    
    return params

def evaluate_random_params_on_map(map_features: List[float], num_samples: int = 5) -> List[Dict[str, Any]]:
    """为一个地图评估多组随机参数"""
    # 导入 A* 相关模块
    try:
        from astar_demo import astar_hierarchical_hybrid, generate_grid_map
    except ImportError:
        print("Warning: 无法导入 astar_demo，使用模拟评估")
        return simulate_random_evaluation(map_features, num_samples)
    
    results = []
    
    # 根据特征重建地图（简化版本）
    obstacle_density, confidence_score, start_goal_distance, connectivity_ratio = map_features
    
    # 生成地图
    try:
        grid_map = generate_simplified_map(obstacle_density, int(start_goal_distance))
        start = (1, 1)  # 固定起点
        goal = (int(start_goal_distance * 0.8), int(start_goal_distance * 0.8))  # 近似终点
        
        for _ in range(num_samples):
            params = sample_random_parameters()
            
            # 调用 A* 算法
            try:
                result = astar_hierarchical_hybrid(
                    grid_map, start, goal,
                    initial_weight=params["initial_weight"],
                    lambda_risk=params["lambda_risk"],
                    lambda_smooth=params["lambda_smooth"],
                    lambda_bonus=params["lambda_bonus"],
                    frontier_radius=params["frontier_radius"],
                    recent_visited_len=params["recent_visited_len"]
                )
                
                # 评估成功性
                if result['path'] and len(result['path']) > 1:
                    outcome = "success"
                    label = 1
                    confidence_score_result = min(1.0, max(0.1, 1.0 - result['nodes_explored'] / 10000.0))
                else:
                    outcome = "failure"
                    label = 0
                    confidence_score_result = 0.1
                    
            except Exception as e:
                print(f"A* 评估失败: {e}")
                outcome = "failure"
                label = 0
                confidence_score_result = 0.1
            
            sample_data = {
                "features": map_features,
                "params": params,
                "outcome": outcome,
                "label": label,
                "confidence_score": confidence_score_result,
                "obstacle_density": obstacle_density,
                "start_goal_distance": start_goal_distance,
                "connectivity_ratio": connectivity_ratio,
                "source": "random_sampling"
            }
            results.append(sample_data)
            
    except Exception as e:
        print(f"地图生成失败: {e}，使用模拟评估")
        return simulate_random_evaluation(map_features, num_samples)
    
    return results

def simulate_random_evaluation(map_features: List[float], num_samples: int) -> List[Dict[str, Any]]:
    """模拟随机参数评估（当无法运行真实 A* 时使用）"""
    obstacle_density = map_features[0]
    
    results = []
    for _ in range(num_samples):
        params = sample_random_parameters()
        
        # 简单的模拟评估：根据障碍密度和参数合理性判断成功概率
        base_success_prob = max(0.1, 1.0 - obstacle_density)
        
        # 参数合理性调整（启发式）
        if 10 <= params["initial_weight"] <= 30:
            base_success_prob += 0.1
        if 1.0 <= params["lambda_risk"] <= 2.5:
            base_success_prob += 0.05
        if 0.5 <= params["lambda_smooth"] <= 2.0:
            base_success_prob += 0.05
            
        success = random.random() < base_success_prob
        
        sample_data = {
            "features": map_features,
            "params": params,
            "outcome": "success" if success else "failure",
            "label": 1 if success else 0,
            "confidence_score": base_success_prob,
            "obstacle_density": map_features[0],
            "start_goal_distance": map_features[2],
            "connectivity_ratio": map_features[3],
            "source": "simulated_random"
        }
        results.append(sample_data)
    
    return results

def generate_simplified_map(obstacle_density: float, size: int) -> np.ndarray:
    """生成简化的网格地图"""
    grid_map = np.zeros((size, size), dtype=int)
    
    # 随机放置障碍物
    total_cells = size * size
    num_obstacles = int(total_cells * obstacle_density)
    
    for _ in range(num_obstacles):
        x, y = random.randint(0, size-1), random.randint(0, size-1)
        grid_map[x, y] = 1
    
    # 确保起点和终点可达
    grid_map[1, 1] = 0
    grid_map[size-2, size-2] = 0
    
    return grid_map

def process_single_map(args_tuple: Tuple[List[float], int, int]) -> List[Dict[str, Any]]:
    """处理单个地图的随机参数评估（用于并行处理）"""
    map_features, num_samples, seed_offset = args_tuple
    
    # 设置随机种子
    random.seed(42 + seed_offset)
    np.random.seed(42 + seed_offset)
    
    return evaluate_random_params_on_map(map_features, num_samples)

def main():
    parser = argparse.ArgumentParser(description="生成随机对照数据集")
    parser.add_argument('--input', type=str, required=True,
                       help='输入的 focused 数据集路径')
    parser.add_argument('--output', type=str, required=True,
                       help='输出的随机数据集路径')
    parser.add_argument('--samples-per-map', type=int, default=1,
                       help='每个地图生成的随机样本数量')
    parser.add_argument('--workers', type=int, default=4,
                       help='并行处理的进程数')
    parser.add_argument('--max-maps', type=int, default=None,
                       help='最大处理地图数量（用于测试）')
    
    args = parser.parse_args()
    
    # 检查输入文件
    if not Path(args.input).exists():
        print(f"❌ 输入文件不存在: {args.input}")
        return
    
    print(f"🔄 从 {args.input} 读取地图特征...")
    
    # 读取原始数据集，提取唯一的地图特征
    unique_map_features = []
    seen_features = set()
    
    with open(args.input, 'r', encoding='utf-8') as f:
        for i, line in enumerate(f):
            if args.max_maps and len(unique_map_features) >= args.max_maps:
                break
                
            line = line.strip()
            if not line:
                continue
                
            try:
                data = json.loads(line)
                features = data.get('features') or [
                    data.get('obstacle_density', 0.3),
                    data.get('confidence_score', 0.5),
                    data.get('start_goal_distance', 20.0),
                    data.get('connectivity_ratio', 0.8)
                ]
                
                # 转换为元组以便哈希
                features_tuple = tuple(features)
                if features_tuple not in seen_features:
                    seen_features.add(features_tuple)
                    unique_map_features.append(features)
                    
            except json.JSONDecodeError:
                continue
    
    print(f"📍 发现 {len(unique_map_features)} 个唯一地图")
    
    # 准备并行处理参数
    process_args = [
        (features, args.samples_per_map, i) 
        for i, features in enumerate(unique_map_features)
    ]
    
    # 并行生成随机样本
    print(f"🚀 使用 {args.workers} 进程并行生成随机样本...")
    all_random_samples = []
    
    with ProcessPoolExecutor(max_workers=args.workers) as executor:
        results = executor.map(process_single_map, process_args)
        
        for map_samples in results:
            all_random_samples.extend(map_samples)
    
    print(f"✅ 生成了 {len(all_random_samples)} 个随机样本")
    
    # 统计信息
    success_count = sum(1 for s in all_random_samples if s['outcome'] == 'success')
    success_rate = success_count / len(all_random_samples) if all_random_samples else 0
    
    print(f"📊 随机参数成功率: {success_rate:.3f} ({success_count}/{len(all_random_samples)})")
    
    # 保存结果
    print(f"💾 保存到 {args.output}...")
    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    
    with open(args.output, 'w', encoding='utf-8') as f:
        for sample in all_random_samples:
            f.write(json.dumps(sample, ensure_ascii=False) + '\n')
    
    # 保存元数据
    meta_data = {
        "total_samples": len(all_random_samples),
        "unique_maps": len(unique_map_features),
        "samples_per_map": args.samples_per_map,
        "success_rate": success_rate,
        "param_ranges": PARAM_RANGES,
        "source_dataset": args.input
    }
    
    meta_path = args.output.replace('.jsonl', '.meta.json')
    with open(meta_path, 'w', encoding='utf-8') as f:
        json.dump(meta_data, f, indent=2, ensure_ascii=False)
    
    print(f"🎉 随机对照数据集生成完成!")
    print(f"   数据文件: {args.output}")
    print(f"   元数据: {meta_path}")

if __name__ == "__main__":
    main()