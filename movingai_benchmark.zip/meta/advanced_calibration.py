#!/usr/bin/env python3
"""
高级不确定度校准研究模块

实现多种先进的校准技术：
1. 集成校准 (Ensemble Calibration)
2. 自适应校准 (Adaptive Calibration)
3. 条件校准 (Conditional Calibration)
4. 贝叶斯校准 (Bayesian Calibration)
5. 多尺度校准 (Multi-scale Calibration)
6. 鲁棒校准 (Robust Calibration)
7. 动态校准 (Dynamic Calibration)
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__)))

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import json
from typing import Dict, List, Tuple, Any, Optional, Callable
from sklearn.model_selection import train_test_split
from sklearn.isotonic import IsotonicRegression
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
import argparse
import warnings
warnings.filterwarnings('ignore')

from models_arch.focus_param_net import FocusParamNet
from models_arch.focus_dataset import FocusParamDataset

class EnsembleCalibration:
    """
    集成校准：结合多种校准方法的优势

    使用加权集成多个校准器，提高整体校准性能
    """

    def __init__(self, base_calibrators: List[Any] = None):
        if base_calibrators is None:
            # 默认集成多种校准器
            self.base_calibrators = [
                TemperatureScaling(),
                VarianceScaling(),
                IsotonicCalibration(),
            ]
        else:
            self.base_calibrators = base_calibrators

        self.weights = None
        self.fitted = False

    def fit(self, predictions: np.ndarray, uncertainties: np.ndarray,
            targets: np.ndarray, validation_split: float = 0.2):
        """训练集成校准器"""

        # 分割训练和验证集
        n_samples = len(predictions)
        val_size = int(validation_split * n_samples)

        train_pred = predictions[:-val_size]
        train_uncert = uncertainties[:-val_size]
        train_target = targets[:-val_size]

        val_pred = predictions[-val_size:]
        val_uncert = uncertainties[-val_size:]
        val_target = targets[-val_size:]

        # 训练基础校准器
        calibrated_uncerts = []
        for calibrator in self.base_calibrators:
            try:
                calibrator.fit(train_pred, train_uncert, train_target)
                cal_uncert = calibrator.calibrate(val_uncert)
                calibrated_uncerts.append(cal_uncert)
            except Exception as e:
                print(f"基础校准器训练失败: {e}")
                calibrated_uncerts.append(val_uncert)  # 使用原始不确定度

        calibrated_uncerts = np.array(calibrated_uncerts).T  # [n_val, n_calibrators]

        # 学习最优权重
        self.weights = self._learn_ensemble_weights(
            calibrated_uncerts, val_pred, val_target
        )

        self.fitted = True
        print(f"集成校准训练完成，权重: {self.weights}")

    def _learn_ensemble_weights(self, calibrated_uncerts: np.ndarray,
                               predictions: np.ndarray, targets: np.ndarray) -> np.ndarray:
        """学习集成权重"""

        n_calibrators = calibrated_uncerts.shape[1]

        # 使用优化方法学习权重
        weights = np.ones(n_calibrators) / n_calibrators  # 均匀初始化

        def ensemble_uncertainty(weights):
            weighted_uncert = np.sum(calibrated_uncerts * weights, axis=1)
            return weighted_uncert

        def objective(weights):
            weights = np.clip(weights, 0, 1)  # 确保权重非负
            weights = weights / np.sum(weights)  # 归一化

            ensemble_uncert = ensemble_uncertainty(weights)
            ece = self._compute_ece(predictions, ensemble_uncert, targets)
            return ece

        # 简单网格搜索优化权重
        best_weights = weights.copy()
        best_ece = objective(weights)

        for i in range(n_calibrators):
            for w in np.linspace(0.1, 0.9, 9):
                test_weights = weights.copy()
                test_weights[i] = w
                test_weights = test_weights / np.sum(test_weights)

                test_ece = objective(test_weights)
                if test_ece < best_ece:
                    best_ece = test_ece
                    best_weights = test_weights.copy()

        return best_weights

    def _compute_ece(self, predictions: np.ndarray, uncertainties: np.ndarray,
                    targets: np.ndarray, n_bins: int = 10) -> float:
        """计算ECE"""
        bin_boundaries = np.linspace(0, np.max(uncertainties), n_bins + 1)
        bin_boundaries[-1] += 1e-8

        ece = 0.0
        total_samples = 0

        for i in range(n_bins):
            mask = (uncertainties > bin_boundaries[i]) & (uncertainties <= bin_boundaries[i + 1])
            if not np.any(mask):
                continue

            bin_size = np.sum(mask)
            bin_uncertainties = uncertainties[mask]
            bin_predictions = predictions[mask]
            bin_targets = targets[mask]

            coverage = np.mean(np.abs(bin_predictions - bin_targets) <= bin_uncertainties)
            expected_coverage = 0.68

            ece += bin_size * abs(coverage - expected_coverage)
            total_samples += bin_size

        return ece / total_samples if total_samples > 0 else 0.0

    def calibrate(self, uncertainties: np.ndarray) -> np.ndarray:
        """应用集成校准"""
        if not self.fitted:
            raise ValueError("集成校准器尚未训练")

        # 获取各基础校准器的结果
        calibrated_results = []
        for calibrator in self.base_calibrators:
            try:
                cal_uncert = calibrator.calibrate(uncertainties)
                calibrated_results.append(cal_uncert)
            except:
                calibrated_results.append(uncertainties)

        calibrated_results = np.array(calibrated_results).T  # [n_samples, n_calibrators]

        # 加权集成
        ensemble_uncert = np.sum(calibrated_results * self.weights, axis=1)

        return ensemble_uncert


class AdaptiveCalibration:
    """
    自适应校准：根据输入特征动态调整校准策略

    使用条件校准，根据地图特征选择最适合的校准方法
    """

    def __init__(self, n_clusters: int = 5):
        self.n_clusters = n_clusters
        self.cluster_models = {}
        self.feature_selector = None
        self.fitted = False

    def fit(self, predictions: np.ndarray, uncertainties: np.ndarray,
            targets: np.ndarray, features: np.ndarray):
        """训练自适应校准器"""

        from sklearn.cluster import KMeans
        from sklearn.preprocessing import StandardScaler

        # 标准化特征
        scaler = StandardScaler()
        scaled_features = scaler.fit_transform(features)

        # 聚类特征空间
        kmeans = KMeans(n_clusters=self.n_clusters, random_state=42, n_init=10)
        clusters = kmeans.fit_predict(scaled_features)

        self.feature_selector = {'scaler': scaler, 'kmeans': kmeans}

        # 为每个聚类训练专门的校准器
        for cluster_id in range(self.n_clusters):
            cluster_mask = clusters == cluster_id
            if np.sum(cluster_mask) < 10:  # 样本太少
                continue

            cluster_pred = predictions[cluster_mask]
            cluster_uncert = uncertainties[cluster_mask]
            cluster_target = targets[cluster_mask]

            # 为每个聚类选择最佳校准方法
            best_calibrator = self._select_best_calibrator(
                cluster_pred, cluster_uncert, cluster_target
            )

            self.cluster_models[cluster_id] = best_calibrator

        self.fitted = True
        print(f"自适应校准训练完成，{len(self.cluster_models)}个聚类模型")

    def _select_best_calibrator(self, predictions: np.ndarray, uncertainties: np.ndarray,
                               targets: np.ndarray) -> Any:
        """为聚类选择最佳校准器"""

        calibrators = [
            ('temperature', TemperatureScaling()),
            ('variance', VarianceScaling()),
            ('isotonic', IsotonicCalibration()),
        ]

        best_calibrator = None
        best_ece = float('inf')

        for name, calibrator in calibrators:
            try:
                # 留出验证
                train_idx = np.random.choice(len(predictions), size=int(0.8 * len(predictions)), replace=False)
                val_idx = np.setdiff1d(np.arange(len(predictions)), train_idx)

                calibrator.fit(predictions[train_idx], uncertainties[train_idx], targets[train_idx])
                cal_uncert = calibrator.calibrate(uncertainties[val_idx])

                ece = self._compute_ece_simple(predictions[val_idx], cal_uncert, targets[val_idx])

                if ece < best_ece:
                    best_ece = ece
                    best_calibrator = calibrator

            except Exception as e:
                continue

        return best_calibrator if best_calibrator is not None else TemperatureScaling()

    def _compute_ece_simple(self, predictions: np.ndarray, uncertainties: np.ndarray,
                           targets: np.ndarray) -> float:
        """简化ECE计算"""
        errors = np.abs(predictions - targets)
        coverage = np.mean(errors <= uncertainties)
        return abs(coverage - 0.68)

    def calibrate(self, uncertainties: np.ndarray, features: np.ndarray) -> np.ndarray:
        """应用自适应校准"""
        if not self.fitted:
            raise ValueError("自适应校准器尚未训练")

        # 预测聚类
        scaled_features = self.feature_selector['scaler'].transform(features)
        clusters = self.feature_selector['kmeans'].predict(scaled_features)

        calibrated_uncerts = np.zeros_like(uncertainties)

        for cluster_id in range(self.n_clusters):
            if cluster_id not in self.cluster_models:
                calibrated_uncerts[clusters == cluster_id] = uncertainties[clusters == cluster_id]
                continue

            cluster_mask = clusters == cluster_id
            cluster_uncert = uncertainties[cluster_mask]

            try:
                cal_uncert = self.cluster_models[cluster_id].calibrate(cluster_uncert)
                calibrated_uncerts[cluster_mask] = cal_uncert
            except:
                calibrated_uncerts[cluster_mask] = cluster_uncert

        return calibrated_uncerts


class ConditionalCalibration:
    """
    条件校准：基于预测值和不确定度进行条件校准

    使用条件密度估计来建模预测误差的条件分布
    """

    def __init__(self, n_bins: int = 20):
        self.n_bins = n_bins
        self.conditional_models = {}
        self.bin_edges = None
        self.fitted = False

    def fit(self, predictions: np.ndarray, uncertainties: np.ndarray, targets: np.ndarray):
        """训练条件校准器"""

        # 基于预测值和不确定度的联合条件进行分箱
        pred_bins = np.linspace(np.min(predictions), np.max(predictions), self.n_bins + 1)
        uncert_bins = np.linspace(np.min(uncertainties), np.max(uncertainties), self.n_bins + 1)

        self.bin_edges = {'pred': pred_bins, 'uncert': uncert_bins}

        # 为每个条件bin训练校准器
        for i in range(self.n_bins):
            for j in range(self.n_bins):
                pred_mask = (predictions >= pred_bins[i]) & (predictions < pred_bins[i+1])
                uncert_mask = (uncertainties >= uncert_bins[j]) & (uncertainties < uncert_bins[j+1])
                bin_mask = pred_mask & uncert_mask

                if np.sum(bin_mask) < 5:  # 样本不足
                    continue

                bin_pred = predictions[bin_mask]
                bin_uncert = uncertainties[bin_mask]
                bin_target = targets[bin_mask]

                # 为该bin训练简单的校准器
                try:
                    calibrator = VarianceScaling()
                    calibrator.fit(bin_pred, bin_uncert, bin_target)
                    self.conditional_models[(i, j)] = calibrator
                except:
                    pass

        self.fitted = True
        print(f"条件校准训练完成，{len(self.conditional_models)}个条件模型")

    def calibrate(self, uncertainties: np.ndarray, predictions: np.ndarray) -> np.ndarray:
        """应用条件校准"""
        if not self.fitted:
            raise ValueError("条件校准器尚未训练")

        calibrated_uncerts = np.zeros_like(uncertainties)

        pred_bins = self.bin_edges['pred']
        uncert_bins = self.bin_edges['uncert']

        for i in range(self.n_bins):
            for j in range(self.n_bins):
                pred_mask = (predictions >= pred_bins[i]) & (predictions < pred_bins[i+1])
                uncert_mask = (uncertainties >= uncert_bins[j]) & (uncertainties < uncert_bins[j+1])
                bin_mask = pred_mask & uncert_mask

                if np.sum(bin_mask) == 0:
                    continue

                if (i, j) in self.conditional_models:
                    try:
                        bin_uncert = uncertainties[bin_mask]
                        cal_uncert = self.conditional_models[(i, j)].calibrate(bin_uncert)
                        calibrated_uncerts[bin_mask] = cal_uncert
                    except:
                        calibrated_uncerts[bin_mask] = uncertainties[bin_mask]
                else:
                    calibrated_uncerts[bin_mask] = uncertainties[bin_mask]

        return calibrated_uncerts


class BayesianCalibration:
    """
    贝叶斯校准：使用贝叶斯方法进行不确定度校准

    建模校准参数的后验分布
    """

    def __init__(self, n_samples: int = 1000):
        self.n_samples = n_samples
        self.posterior_samples = None
        self.fitted = False

    def fit(self, predictions: np.ndarray, targets: np.ndarray, uncertainties: Optional[np.ndarray] = None):
        """使用MCMC采样学习贝叶斯校准参数"""

        # 简化的贝叶斯校准：学习校准参数的分布
        # 这里使用简化的方法，实际可以扩展到更复杂的贝叶斯模型

        def log_likelihood(params):
            """对数似然函数"""
            scale, bias = params

            # 应用校准到预测值
            calibrated_pred = predictions * scale + bias

            # 计算似然（假设预测误差服从正态分布）
            errors = np.abs(calibrated_pred - targets)
            if uncertainties is not None:
                # 如果有不确定性信息，使用它
                log_lik = -0.5 * np.log(2 * np.pi * uncertainties**2) - 0.5 * (errors**2 / uncertainties**2)
            else:
                # 使用固定的不确定性
                fixed_uncert = np.std(targets) * 0.1  # 假设10%的相对不确定性
                log_lik = -0.5 * np.log(2 * np.pi * fixed_uncert**2) - 0.5 * (errors**2 / fixed_uncert**2)
            return np.sum(log_lik)

        def log_prior(params):
            """先验分布"""
            scale, bias = params
            # 弱信息先验
            return -0.5 * ((scale - 1.0)**2 + bias**2)

        # Metropolis-Hastings采样
        samples = []
        current_params = np.array([1.0, 0.0])  # 初始值
        current_log_prob = log_likelihood(current_params) + log_prior(current_params)

        proposal_std = np.array([0.1, 0.1])

        for _ in range(self.n_samples):
            # 提出新参数
            proposal = current_params + np.random.normal(0, proposal_std, size=2)
            proposal_log_prob = log_likelihood(proposal) + log_prior(proposal)

            # 接受概率
            acceptance_ratio = np.exp(proposal_log_prob - current_log_prob)
            if np.random.random() < acceptance_ratio:
                current_params = proposal
                current_log_prob = proposal_log_prob

            samples.append(current_params.copy())

        self.posterior_samples = np.array(samples)
        self.fitted = True
        print(f"贝叶斯校准训练完成，{self.n_samples}个后验样本")

    def calibrate(self, predictions: np.ndarray) -> np.ndarray:
        """使用后验预测进行校准"""
        if not self.fitted:
            raise ValueError("贝叶斯校准器尚未训练")

        # 从后验分布采样参数
        n_preds = len(predictions) if hasattr(predictions, '__len__') else 1
        if not hasattr(predictions, '__len__'):
            predictions = np.array([predictions])
        
        sample_indices = np.random.choice(len(self.posterior_samples), size=n_preds)

        calibrated_preds = np.zeros(n_preds)
        for i in range(n_preds):
            scale, bias = self.posterior_samples[sample_indices[i]]
            calibrated_preds[i] = predictions[i] * scale + bias

        return calibrated_preds


class MultiScaleCalibration:
    """
    多尺度校准：在不同不确定度尺度上应用不同校准策略

    将不确定度分为不同范围，为每个范围使用专门的校准器
    """

    def __init__(self, scales: List[Tuple[float, float]] = None):
        if scales is None:
            # 默认尺度：低、中、高不确定度
            self.scales = [
                (0.0, 0.5),   # 低不确定度
                (0.5, 2.0),   # 中不确定度
                (2.0, float('inf'))  # 高不确定度
            ]
        else:
            self.scales = scales

        self.scale_calibrators = {}
        self.fitted = False

    def fit(self, predictions: np.ndarray, uncertainties: np.ndarray, targets: np.ndarray):
        """训练多尺度校准器"""

        for scale_min, scale_max in self.scales:
            # 选择该尺度的样本
            scale_mask = (uncertainties >= scale_min) & (uncertainties < scale_max)

            if np.sum(scale_mask) < 10:  # 样本不足
                continue

            scale_pred = predictions[scale_mask]
            scale_uncert = uncertainties[scale_mask]
            scale_target = targets[scale_mask]

            # 为该尺度选择最佳校准方法
            best_calibrator = self._select_best_for_scale(
                scale_pred, scale_uncert, scale_target
            )

            self.scale_calibrators[(scale_min, scale_max)] = best_calibrator

        self.fitted = True
        print(f"多尺度校准训练完成，{len(self.scale_calibrators)}个尺度模型")

    def _select_best_for_scale(self, predictions: np.ndarray, uncertainties: np.ndarray,
                              targets: np.ndarray) -> Any:
        """为特定尺度选择最佳校准器"""

        calibrators = [
            TemperatureScaling(),
            VarianceScaling(),
            IsotonicCalibration(),
        ]

        best_calibrator = None
        best_score = float('inf')

        for calibrator in calibrators:
            try:
                # 交叉验证
                scores = []
                n_folds = 3

                for fold in range(n_folds):
                    # 简单分割
                    n_samples = len(predictions)
                    val_size = n_samples // n_folds
                    val_start = fold * val_size
                    val_end = (fold + 1) * val_size

                    train_pred = np.concatenate([predictions[:val_start], predictions[val_end:]])
                    train_uncert = np.concatenate([uncertainties[:val_start], uncertainties[val_end:]])
                    train_target = np.concatenate([targets[:val_start], targets[val_end:]])

                    val_pred = predictions[val_start:val_end]
                    val_uncert = uncertainties[val_start:val_end]
                    val_target = targets[val_start:val_end]

                    calibrator.fit(train_pred, train_uncert, train_target)
                    cal_uncert = calibrator.calibrate(val_uncert)

                    score = self._compute_ece_simple(val_pred, cal_uncert, val_target)
                    scores.append(score)

                avg_score = np.mean(scores)
                if avg_score < best_score:
                    best_score = avg_score
                    best_calibrator = calibrator

            except Exception as e:
                continue

        return best_calibrator if best_calibrator is not None else TemperatureScaling()

    def _compute_ece_simple(self, predictions: np.ndarray, uncertainties: np.ndarray,
                           targets: np.ndarray) -> float:
        """简化ECE计算"""
        errors = np.abs(predictions - targets)
        coverage = np.mean(errors <= uncertainties)
        return abs(coverage - 0.68)

    def calibrate(self, uncertainties: np.ndarray) -> np.ndarray:
        """应用多尺度校准"""
        if not self.fitted:
            raise ValueError("多尺度校准器尚未训练")

        calibrated_uncerts = np.zeros_like(uncertainties)

        for scale_min, scale_max in self.scales:
            if (scale_min, scale_max) not in self.scale_calibrators:
                continue

            scale_mask = (uncertainties >= scale_min) & (uncertainties < scale_max)
            if np.sum(scale_mask) == 0:
                continue

            scale_uncert = uncertainties[scale_mask]

            try:
                cal_uncert = self.scale_calibrators[(scale_min, scale_max)].calibrate(scale_uncert)
                calibrated_uncerts[scale_mask] = cal_uncert
            except:
                calibrated_uncerts[scale_mask] = scale_uncert

        return calibrated_uncerts


class RobustCalibration:
    """
    鲁棒校准：对异常值和分布偏移具有鲁棒性

    使用鲁棒统计方法和异常值检测
    """

    def __init__(self, contamination: float = 0.1):
        self.contamination = contamination  # 预期异常值比例
        self.base_calibrator = None
        self.outlier_detector = None
        self.fitted = False

    def fit(self, predictions: np.ndarray, uncertainties: np.ndarray, targets: np.ndarray,
            features: Optional[np.ndarray] = None):
        """训练鲁棒校准器"""

        # 检测异常值
        from sklearn.ensemble import IsolationForest

        # 使用预测误差作为异常检测特征
        preliminary_uncert = uncertainties.copy()
        errors = np.abs(predictions - targets)

        # 标准化特征用于异常检测
        features = np.column_stack([
            predictions,
            uncertainties,
            errors / (uncertainties + 1e-6),  # 标准化误差
            np.log(uncertainties + 1e-6)     # 对数不确定度
        ])

        # 训练异常检测器
        self.outlier_detector = IsolationForest(
            contamination=self.contamination,
            random_state=42,
            n_estimators=100
        )
        outlier_scores = self.outlier_detector.fit_predict(features)
        inlier_mask = outlier_scores == 1

        print(f"检测到 {np.sum(outlier_scores == -1)} 个异常值，保留 {np.sum(inlier_mask)} 个正常样本")

        # 使用正常样本训练基础校准器
        if np.sum(inlier_mask) >= 10:
            clean_pred = predictions[inlier_mask]
            clean_uncert = uncertainties[inlier_mask]
            clean_target = targets[inlier_mask]

            # 尝试不同的校准器，选择最鲁棒的
            self.base_calibrator = self._select_robust_calibrator(
                clean_pred, clean_uncert, clean_target
            )
        else:
            # 如果正常样本太少，使用简单的方法
            self.base_calibrator = TemperatureScaling()

        self.fitted = True
        print("鲁棒校准训练完成")

    def _select_robust_calibrator(self, predictions: np.ndarray, uncertainties: np.ndarray,
                                 targets: np.ndarray) -> Any:
        """选择最鲁棒的校准器"""

        calibrators = [
            ('temperature', TemperatureScaling()),
            ('variance', VarianceScaling()),
        ]

        best_calibrator = None
        best_robustness = -float('inf')

        for name, calibrator in calibrators:
            try:
                # 使用鲁棒的交叉验证
                robustness_scores = []

                for _ in range(5):  # 多次随机分割
                    train_idx = np.random.choice(len(predictions), size=int(0.8 * len(predictions)), replace=False)
                    val_idx = np.setdiff1d(np.arange(len(predictions)), train_idx)

                    train_pred = predictions[train_idx]
                    train_uncert = uncertainties[train_idx]
                    train_target = targets[train_idx]

                    val_pred = predictions[val_idx]
                    val_uncert = uncertainties[val_idx]
                    val_target = targets[val_idx]

                    calibrator.fit(train_pred, train_uncert, train_target)
                    cal_uncert = calibrator.calibrate(val_uncert)

                    # 计算鲁棒性指标：ECE + 异常值敏感度
                    ece = self._compute_ece_simple(val_pred, cal_uncert, val_target)

                    # 添加正则化项，惩罚过大的不确定度变化
                    uncert_change = np.mean(np.abs(cal_uncert - val_uncert) / (val_uncert + 1e-6))
                    robustness = 1.0 / (1.0 + ece + 0.1 * uncert_change)

                    robustness_scores.append(robustness)

                avg_robustness = np.mean(robustness_scores)
                if avg_robustness > best_robustness:
                    best_robustness = avg_robustness
                    best_calibrator = calibrator

            except Exception as e:
                continue

        return best_calibrator if best_calibrator is not None else TemperatureScaling()

    def _compute_ece_simple(self, predictions: np.ndarray, uncertainties: np.ndarray,
                           targets: np.ndarray) -> float:
        """简化ECE计算"""
        errors = np.abs(predictions - targets)
        coverage = np.mean(errors <= uncertainties)
        return abs(coverage - 0.68)

    def calibrate(self, uncertainties: np.ndarray, features: Optional[np.ndarray] = None) -> np.ndarray:
        """应用鲁棒校准"""
        if not self.fitted:
            raise ValueError("鲁棒校准器尚未训练")

        # 如果有特征，使用异常检测
        if features is not None and self.outlier_detector is not None:
            outlier_scores = self.outlier_detector.predict(features)
            outlier_mask = outlier_scores == -1

            calibrated_uncerts = np.zeros_like(uncertainties)

            # 对正常样本应用校准
            normal_mask = ~outlier_mask
            if np.sum(normal_mask) > 0:
                normal_uncert = uncertainties[normal_mask]
                try:
                    cal_uncert = self.base_calibrator.calibrate(normal_uncert)
                    calibrated_uncerts[normal_mask] = cal_uncert
                except:
                    calibrated_uncerts[normal_mask] = normal_uncert

            # 对异常值使用保守策略（增加不确定度）
            if np.sum(outlier_mask) > 0:
                calibrated_uncerts[outlier_mask] = uncertainties[outlier_mask] * 1.5

            return calibrated_uncerts
        else:
            # 没有特征信息，直接应用基础校准
            try:
                return self.base_calibrator.calibrate(uncertainties)
            except:
                return uncertainties


# 导入现有校准器以保持兼容性
from calibrate_uncertainty import TemperatureScaling, VarianceScaling, IsotonicCalibration