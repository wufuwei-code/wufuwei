import os
import time
import math
import itertools
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from compare_planners_batch import (
    prepare_random_map,
    search_with_decreasing_inflation,
    astar_hierarchical_hybrid,
    prune_path,
    smooth_path_with_bezier_adaptive,
    prm_plan,
    rrt_plan,
    path_length,
)


def run_grid(sizes=[60,80,100], densities=[0.1,0.2,0.3], seeds=[0,1,2], rrt_repeats=5, out_dir='outputs/ablation_results'):
    os.makedirs(out_dir, exist_ok=True)
    rows = []
    print(f'[grid] sizes={sizes}, densities={densities}, seeds={seeds}, rrt_repeats={rrt_repeats}')

    total_runs = len(sizes) * len(densities) * len(seeds) * (1 + 1 + 1 + rrt_repeats)
    run_idx = 0

    for size, density, seed in itertools.product(sizes, densities, seeds):
        grid, start, goal = prepare_random_map(rows=size, cols=size, obstacle_ratio=density, seed=seed)

        # RL-A*
        run_idx += 1
        tic = time.time()
        path_rl, expanded_order, used_radius, attempts, plan_time = search_with_decreasing_inflation(grid, start, goal, inflation_radius=2, complex_params={})
        rl_success = len(path_rl) > 0
        rl_len = path_length(prune_path(path_rl, grid)) if rl_success else None
        rows.append({'size': size, 'density': density, 'seed': seed, 'planner': 'RL-A*', 'success': rl_success, 'plan_time': plan_time, 'path_len': rl_len, 'expanded': int(np.max(expanded_order)) if rl_success else None})

        # A*
        run_idx += 1
        tic = time.time()
        path_a, expanded_a = astar_hierarchical_hybrid(grid, start, goal, {})
        a_time = time.time() - tic
        a_success = len(path_a) > 0
        a_len = path_length(prune_path(path_a, grid)) if a_success else None
        rows.append({'size': size, 'density': density, 'seed': seed, 'planner': 'A*', 'success': a_success, 'plan_time': a_time, 'path_len': a_len, 'expanded': int(np.max(expanded_a)) if a_success else None})

        # PRM (use moderate samples to balance time)
        run_idx += 1
        tic = time.time()
        path_prm, meta_prm = prm_plan(grid, start, goal, n_samples=1000, k=15)
        prm_time = time.time() - tic
        prm_success = len(path_prm) > 0
        prm_len = path_length(prune_path(path_prm, grid)) if prm_success else None
        rows.append({'size': size, 'density': density, 'seed': seed, 'planner': 'PRM', 'success': prm_success, 'plan_time': prm_time, 'path_len': prm_len, 'expanded': meta_prm.get('graph_nodes')})
        print(f"[grid] size={size} density={density} seed={seed} PRM success={prm_success} nodes={meta_prm.get('graph_nodes')}")

        # RRT: repeat multiple seeds for stochasticity
        for r in range(rrt_repeats):
            run_idx += 1
            tic = time.time()
            path_rrt, meta_rrt = rrt_plan(grid, start, goal, max_iters=8000, step_size=2.0)
            rrt_time = time.time() - tic
            rrt_success = len(path_rrt) > 0
            print(f"[grid] size={size} density={density} seed={seed} RRT repeat={r} success={rrt_success} tree={meta_rrt.get('tree_size')}")
            rrt_len = path_length(prune_path(path_rrt, grid)) if rrt_success else None
            rows.append({'size': size, 'density': density, 'seed': seed, 'planner': 'RRT', 'repeat': r, 'success': rrt_success, 'plan_time': rrt_time, 'path_len': rrt_len, 'expanded': meta_rrt.get('tree_size')})

    df = pd.DataFrame(rows)
    csv_path = os.path.join(out_dir, 'compare_planners_grid.csv')
    df.to_csv(csv_path, index=False)

    # summary stats and plots
    summary = df.groupby(['planner', 'size', 'density']).agg({'success': ['mean','sum'],'plan_time': ['mean','std'],'path_len': ['mean','std'],'expanded': ['mean']}).reset_index()
    summary_csv = os.path.join(out_dir, 'compare_planners_grid_summary.csv')
    summary.to_csv(summary_csv, index=False)

    # Boxplot of plan_time by planner
    plt.figure(figsize=(8,6))
    df_box = df[['planner','plan_time']].dropna()
    df_box.boxplot(by='planner', column=['plan_time'])
    plt.title('Planning time by planner')
    plt.suptitle('')
    plt.ylabel('seconds')
    plt.savefig(os.path.join(out_dir, 'compare_planners_grid_plan_time_box.png'), dpi=200)
    plt.close()

    # Success rate bar
    succ = df.groupby('planner')['success'].mean().sort_values()
    plt.figure(figsize=(6,4))
    succ.plot(kind='bar')
    plt.ylabel('success rate')
    plt.ylim(0,1)
    plt.title('Overall success rate by planner')
    plt.savefig(os.path.join(out_dir, 'compare_planners_grid_success_rate.png'), dpi=200)
    plt.close()

    print(f'Grid results saved to {csv_path} and summary {summary_csv}')


if __name__ == '__main__':
    run_grid()
