#!/usr/bin/env python3
"""
FocusParamNet模型综合评估脚本
测试模型在各种地图场景下的参数预测准确性和不确定度校准
"""
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__)))

import torch
import numpy as np
import json
from pathlib import Path
from typing import Dict, List, Tuple, Any
from models_arch.focus_param_net import FocusParamNet
from models_arch.focus_dataset import FocusParamDataset

def load_model(model_path: str):
    """加载训练好的模型并返回 (model, checkpoint, enabled_cont, enabled_disc)"""
    checkpoint = torch.load(model_path, map_location='cpu')
    args_in_ckpt = checkpoint.get('args', {}) or {}

    # 默认 specs 与 train 中保持一致
    default_cont_specs = {
        "initial_weight": (1.0, 50.0),
        "lambda_risk": (0.2, 4.0),
        "lambda_smooth": (0.1, 3.0),
        "lambda_bonus": (0.0, 2.0),
    }
    default_disc_specs = {
        "frontier_radius": [2, 3, 4, 5, 6],
        "recent_visited_len": [10, 20, 30, 40, 50],
    }

    enabled_cont = args_in_ckpt.get('enabled_continuous') or list(default_cont_specs.keys())
    enabled_disc = args_in_ckpt.get('enabled_discrete') or list(default_disc_specs.keys())
    cont_specs = {k: v for k, v in default_cont_specs.items() if k in enabled_cont}
    disc_specs = {k: v for k, v in default_disc_specs.items() if k in enabled_disc}

    model = FocusParamNet(input_dim=4, continuous_specs=cont_specs, discrete_specs=disc_specs)
    missing, unexpected = model.load_state_dict(checkpoint['model_state'], strict=False)
    if missing:
        print('[Warn] Missing keys when loading:', missing)
    if unexpected:
        print('[Warn] Unexpected keys when loading:', unexpected)
    model.eval()
    return model, checkpoint, enabled_cont, enabled_disc

def evaluate_regression_metrics(predictions: np.ndarray, targets: np.ndarray) -> Dict[str, float]:
    """计算回归指标"""
    mae = np.mean(np.abs(predictions - targets))
    mse = np.mean((predictions - targets) ** 2)
    rmse = np.sqrt(mse)
    
    # 相对误差
    relative_error = np.mean(np.abs(predictions - targets) / (np.abs(targets) + 1e-8))
    
    return {
        'mae': mae,
        'mse': mse, 
        'rmse': rmse,
        'relative_error': relative_error
    }

def evaluate_classification_metrics(predictions: np.ndarray, targets: np.ndarray) -> Dict[str, float]:
    """计算分类指标"""
    accuracy = np.mean(predictions == targets)
    
    # 计算每个类别的精度
    unique_classes = np.unique(np.concatenate([predictions, targets]))
    class_accuracies = {}
    for cls in unique_classes:
        mask = targets == cls
        if np.sum(mask) > 0:
            class_acc = np.mean(predictions[mask] == targets[mask])
            class_accuracies[f'class_{int(cls)}_acc'] = class_acc
    
    return {'accuracy': accuracy, **class_accuracies}

def evaluate_uncertainty_calibration(means: np.ndarray, stds: np.ndarray, 
                                   targets: np.ndarray, confidence_levels: List[float] = [0.5, 0.8, 0.9, 0.95]) -> Dict[str, float]:
    """评估不确定度校准"""
    calibration_results = {}
    
    for conf_level in confidence_levels:
        # 计算置信区间
        z_score = {0.5: 0.674, 0.8: 1.282, 0.9: 1.645, 0.95: 1.96}[conf_level]
        lower = means - z_score * stds
        upper = means + z_score * stds
        
        # 计算实际覆盖率
        coverage = np.mean((targets >= lower) & (targets <= upper))
        calibration_error = abs(coverage - conf_level)
        
        calibration_results[f'coverage_{int(conf_level*100)}'] = coverage
        calibration_results[f'calibration_error_{int(conf_level*100)}'] = calibration_error
    
    # 平均校准误差
    avg_calibration_error = np.mean([calibration_results[k] for k in calibration_results.keys() if 'calibration_error' in k])
    calibration_results['avg_calibration_error'] = avg_calibration_error
    
    return calibration_results

def compute_detailed_calibration(predictions: np.ndarray, uncertainties: np.ndarray, 
                                targets: np.ndarray, n_bins: int = 10) -> Dict[str, Any]:
    """计算详细的不确定度校准指标，包括ECE和分箱分析"""
    
    # 确保有足够的样本
    if len(predictions) < n_bins:
        n_bins = max(1, len(predictions) // 2)
    
    # 按不确定度分箱
    bin_boundaries = np.percentile(uncertainties, np.linspace(0, 100, n_bins + 1))
    bin_boundaries[-1] += 1e-8  # 确保最大值被包含
    
    bin_stats = []
    total_samples = 0
    weighted_ece = 0.0
    
    for i in range(n_bins):
        # 找到当前分箱的样本
        if i == 0:
            mask = uncertainties <= bin_boundaries[i + 1]
        else:
            mask = (uncertainties > bin_boundaries[i]) & (uncertainties <= bin_boundaries[i + 1])
        
        if not np.any(mask):
            continue
            
        bin_predictions = predictions[mask]
        bin_uncertainties = uncertainties[mask]
        bin_targets = targets[mask]
        bin_size = len(bin_predictions)
        
        # 计算该分箱的指标
        bin_mae = np.mean(np.abs(bin_predictions - bin_targets))
        bin_rmse = np.sqrt(np.mean((bin_predictions - bin_targets) ** 2))
        avg_uncertainty = np.mean(bin_uncertainties)
        
        # 校准度分析：使用正态分布假设计算置信区间覆盖率
        coverage_68 = np.mean(np.abs(bin_predictions - bin_targets) <= bin_uncertainties)  # ~68% for 1σ
        coverage_95 = np.mean(np.abs(bin_predictions - bin_targets) <= 1.96 * bin_uncertainties)  # 95% for 1.96σ
        
        # 负对数似然 (假设正态分布)
        nll = 0.5 * np.log(2 * np.pi * bin_uncertainties**2) + 0.5 * ((bin_predictions - bin_targets)**2 / bin_uncertainties**2)
        avg_nll = np.mean(nll)
        
        bin_info = {
            'bin_index': i,
            'bin_range': [float(bin_boundaries[i]), float(bin_boundaries[i + 1])],
            'bin_size': int(bin_size),
            'avg_uncertainty': float(avg_uncertainty),
            'mae': float(bin_mae),
            'rmse': float(bin_rmse),
            'coverage_68': float(coverage_68),
            'coverage_95': float(coverage_95),
            'expected_coverage_68': 0.68,
            'expected_coverage_95': 0.95,
            'calibration_error_68': float(abs(coverage_68 - 0.68)),
            'calibration_error_95': float(abs(coverage_95 - 0.95)),
            'nll': float(avg_nll)
        }
        
        bin_stats.append(bin_info)
        total_samples += bin_size
        
        # 加权ECE贡献 (使用68%置信度)
        weighted_ece += bin_size * abs(coverage_68 - 0.68)
    
    # 计算总体ECE
    ece = weighted_ece / total_samples if total_samples > 0 else 0.0
    
    # 计算总体NLL
    all_nll = 0.5 * np.log(2 * np.pi * uncertainties**2) + 0.5 * ((predictions - targets)**2 / uncertainties**2)
    total_nll = np.mean(all_nll)
    
    return {
        'ece': float(ece),
        'total_nll': float(total_nll),
        'n_bins': len(bin_stats),
        'total_samples': int(total_samples),
        'bin_stats': bin_stats
    }

def create_test_scenarios() -> List[Dict[str, Any]]:
    """创建不同的测试场景"""
    scenarios = [
        # 简单场景
        {
            'name': 'simple_low_density',
            'features': [0.15, 0.95, 15.0, 0.98],
            'description': '低障碍密度，高连通性'
        },
        {
            'name': 'simple_medium_density', 
            'features': [0.25, 0.85, 25.0, 0.90],
            'description': '中等障碍密度，良好连通性'
        },
        # 复杂场景
        {
            'name': 'complex_high_density',
            'features': [0.40, 0.60, 40.0, 0.75],
            'description': '高障碍密度，中等连通性'
        },
        {
            'name': 'complex_very_high_density',
            'features': [0.45, 0.40, 50.0, 0.60],
            'description': '极高障碍密度，低连通性'
        },
        # 边界场景
        {
            'name': 'boundary_sparse',
            'features': [0.08, 1.00, 5.0, 1.00],
            'description': '极低障碍密度'
        },
        {
            'name': 'boundary_dense',
            'features': [0.50, 0.20, 80.0, 0.30],
            'description': '极高障碍密度'
        },
        # 异常场景
        {
            'name': 'anomaly_disconnected',
            'features': [0.35, 0.10, 60.0, 0.15],
            'description': '高障碍但极低连通性'
        },
        {
            'name': 'anomaly_far_distance',
            'features': [0.20, 0.80, 100.0, 0.85],
            'description': '中等障碍但极远距离'
        }
    ]
    
    return scenarios

def comprehensive_model_evaluation(model_path: str, test_data_path: str = None) -> Dict[str, Any]:
    """综合模型评估"""
    print(f"🔍 开始综合模型评估")
    print(f"模型路径: {model_path}")
    
    # 加载模型
    model, checkpoint, enabled_cont, enabled_disc = load_model(model_path)
    print(f"启用连续参数: {enabled_cont}")
    print(f"启用离散参数: {enabled_disc}")
    ablation_tag = (checkpoint.get('args') or {}).get('ablation_tag', '')
    if ablation_tag:
        print(f"Ablation Tag: {ablation_tag}")
    
    results = {
        'model_path': model_path,
        'scenario_results': {},
        'test_set_results': {},
        'uncertainty_analysis': {},
        'calibration_details': {}
    }
    
    # 1. 场景测试
    print("\n📋 场景测试:")
    scenarios = create_test_scenarios()
    
    for scenario in scenarios:
        print(f"\n--- {scenario['name']} ---")
        print(f"描述: {scenario['description']}")
        
        # 准备输入
        features = torch.tensor([scenario['features']], dtype=torch.float32)
        
        # 标准预测
        with torch.no_grad():
            pred = model.forward(features)
        
        # MC Dropout预测
        mc_pred = model.predict_with_uncertainty(features, mc_times=20)
        
        scenario_result = {
            'features': scenario['features'],
            'description': scenario['description'],
            'predictions': {},
            'uncertainties': {}
        }
        
        # 记录连续参数预测 (仅启用的连续头)
        continuous_params = enabled_cont
        for param in continuous_params:
            pred_val = pred[param].item()
            mc_mean = mc_pred[param].item()
            mc_std = torch.sqrt(mc_pred[f"{param}_var"]).item()
            
            scenario_result['predictions'][param] = pred_val
            scenario_result['uncertainties'][param] = {'mean': mc_mean, 'std': mc_std}
            
            print(f"{param}: {pred_val:.3f} ± {mc_std:.3f}")
        
        # 记录离散参数预测 (仅启用的离散头)
        discrete_params = enabled_disc
        for param in discrete_params:
            pred_val = int(pred[param].item())
            mc_mode = int(mc_pred[param].item())
            mc_var = mc_pred[f"{param}_var"].item()
            
            scenario_result['predictions'][param] = pred_val
            scenario_result['uncertainties'][param] = {'mode': mc_mode, 'var': mc_var}
            
            print(f"{param}: {pred_val} (方差: {mc_var:.2f})")
        
        results['scenario_results'][scenario['name']] = scenario_result
    
    # 2. 测试集评估（如果提供）
    if test_data_path and Path(test_data_path).exists():
        print(f"\n📊 测试集评估:")
        print(f"测试数据: {test_data_path}")
        
        # 加载测试数据
        test_dataset = FocusParamDataset(test_data_path,
                                         continuous_params=enabled_cont,
                                         discrete_params=enabled_disc)
        test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=32, shuffle=False, 
                                                  collate_fn=test_dataset.collate_fn)

        all_predictions = {param: [] for param in continuous_params + discrete_params}
        all_targets = {param: [] for param in continuous_params + discrete_params}
        all_uncertainties = {param: [] for param in continuous_params}

        with torch.no_grad():
            for batch in test_loader:
                features = batch['features']
                
                # 标准预测
                pred = model.forward(features)
                mc_pred = model.predict_with_uncertainty(features, mc_times=10)
                
                # 收集连续参数结果
                for param in continuous_params:
                    if param in batch['targets_cont']:
                        all_predictions[param].extend(pred[param].numpy())
                        all_targets[param].extend(batch['targets_cont'][param].numpy())
                        all_uncertainties[param].extend(torch.sqrt(mc_pred[f"{param}_var"]).numpy())
                
                # 收集离散参数结果
                for param in discrete_params:
                    if param in batch['targets_disc']:
                        all_predictions[param].extend(pred[param].numpy())
                        all_targets[param].extend(batch['targets_disc'][param].numpy())
        
        # 计算指标
        test_results = {}
        calibration_details = {}

        print("\n连续参数评估:")
        for param in continuous_params:
            if len(all_predictions[param]) > 0:
                pred_arr = np.array(all_predictions[param])
                target_arr = np.array(all_targets[param])
                std_arr = np.array(all_uncertainties[param])

                # 回归指标
                reg_metrics = evaluate_regression_metrics(pred_arr, target_arr)

                # 不确定度校准
                calib_metrics = evaluate_uncertainty_calibration(pred_arr, std_arr, target_arr)
                
                # 详细校准分析
                detailed_calib = compute_detailed_calibration(pred_arr, std_arr, target_arr)

                test_results[param] = {**reg_metrics, **calib_metrics}
                calibration_details[param] = detailed_calib

                print(f"{param}: MAE={reg_metrics['mae']:.3f}, RMSE={reg_metrics['rmse']:.3f}, "
                      f"ECE={detailed_calib['ece']:.3f}, NLL={detailed_calib['total_nll']:.3f}")

        print("\n离散参数评估:")
        for param in discrete_params:
            if len(all_predictions[param]) > 0:
                pred_arr = np.array(all_predictions[param])
                target_arr = np.array(all_targets[param])

                # 分类指标
                cls_metrics = evaluate_classification_metrics(pred_arr, target_arr)
                test_results[param] = cls_metrics

                print(f"{param}: Accuracy={cls_metrics['accuracy']:.3f}")

        results['test_set_results'] = test_results
        results['calibration_details'] = calibration_details
    
    # 3. 不确定度分析
    print(f"\n🔬 不确定度分析:")
    # 不确定度分析仅针对启用的连续参数
    uncertainty_analysis = analyze_uncertainty_patterns(results['scenario_results'], enabled_cont)
    results['uncertainty_analysis'] = uncertainty_analysis
    
    return results

def analyze_uncertainty_patterns(scenario_results: Dict[str, Any], enabled_continuous: List[str]) -> Dict[str, Any]:
    """分析不确定度模式"""
    analysis = {
        'difficulty_vs_uncertainty': {},
        'parameter_uncertainty_ranking': {},
        'uncertainty_correlations': {}
    }
    
    # 提取不确定度数据
    uncertainties = {param: [] for param in enabled_continuous}
    difficulties = []
    
    for scenario_name, result in scenario_results.items():
        # 简单的难度评分：障碍密度 + (1 - 连通性)
        features = result['features']
        difficulty = features[0] + (1 - features[1])  # obstacle_density + (1 - confidence_score)
        difficulties.append(difficulty)
        
        for param in uncertainties.keys():
            if param in result['uncertainties']:
                uncertainties[param].append(result['uncertainties'][param]['std'])
    
    # 难度vs不确定度关系
    for param in uncertainties.keys():
        if len(uncertainties[param]) > 0:
            corr = np.corrcoef(difficulties, uncertainties[param])[0, 1]
            analysis['difficulty_vs_uncertainty'][param] = corr
    
    # 参数不确定度排序
    avg_uncertainties = {param: np.mean(uncertainties[param]) for param in uncertainties.keys() if len(uncertainties[param]) > 0}
    sorted_params = sorted(avg_uncertainties.items(), key=lambda x: x[1], reverse=True)
    analysis['parameter_uncertainty_ranking'] = dict(sorted_params)
    
    print("难度vs不确定度相关性:")
    for param, corr in analysis['difficulty_vs_uncertainty'].items():
        print(f"  {param}: {corr:.3f}")
    
    print("\n参数不确定度排序:")
    for param, uncertainty in sorted_params:
        print(f"  {param}: {uncertainty:.3f}")
    
    return analysis

def save_evaluation_results(results: Dict[str, Any], output_path: str):
    """保存评估结果"""
    with open(output_path, 'w') as f:
        json.dump(results, f, indent=2, default=str)
    print(f"\n💾 评估结果已保存到: {output_path}")

def main():
    import argparse
    parser = argparse.ArgumentParser(description="FocusParamNet模型综合评估")
    parser.add_argument('--model', type=str, default='models/focus_param_v3/best.pt',
                       help='模型路径')
    parser.add_argument('--test-data', type=str, default=None,
                       help='测试数据路径（可选）')
    parser.add_argument('--output', type=str, default='evaluation_results.json',
                       help='输出结果路径')
    
    args = parser.parse_args()
    
    if not Path(args.model).exists():
        print(f"❌ 模型文件不存在: {args.model}")
        return
    
    # 执行评估
    results = comprehensive_model_evaluation(args.model, args.test_data)
    
    # 保存结果
    save_evaluation_results(results, args.output)
    
    print(f"\n🎉 评估完成!")

if __name__ == "__main__":
    main()