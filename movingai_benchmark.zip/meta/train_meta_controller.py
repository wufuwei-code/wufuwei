"""train_meta_controller.py
读取 collect_meta_dataset.py 生成的 CSV 数据集，训练一个 MLP。
支持两种训练模式：
1) direct 模式：直接回归 8 个参数的归一化值 (0~1)。
2) delta 模式：回归 (param - rule) 的残差（按各自参数范围线性缩放到 [-1,1]）。

direct: 损失 MSE；
delta: 采用 SmoothL1 Loss 以增强对噪声与异常点的鲁棒性。
输出：模型权重 + scaler (特征 mean/std)。

使用：
python -m meta.train_meta_controller \
  --data meta/dataset/meta_params_dataset.csv \
  --epochs 120 --lr 1e-3 --out-model meta/models/meta_mlp.pt --out-scaler meta/models/meta_scaler.npz
"""
from __future__ import annotations
import argparse
import csv
import numpy as np
from pathlib import Path
import math

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader

from meta.meta_controller import SimpleMLP, FEATURE_ORDER, PARAM_BOUNDS

PARAM_KEYS = ['initial_weight','lambda_risk','lambda_smooth','lambda_bonus','frontier_radius','recent_visited_len','curvature_window','risk_power']

def ranking_loss(pred, target, margin=0.5, threshold=0.1):
    """
    Ranking loss: 如果两个样本在某参数维度上有明显差异(>threshold)，
    则要求预测也要保持正确的相对顺序
    
    Args:
        pred: [batch, n_params] 预测值
        target: [batch, n_params] 目标值  
        margin: 排序违反时的惩罚margin
        threshold: 认为有显著差异的最小阈值
    """
    batch_size = pred.size(0)
    if batch_size < 2:
        return torch.tensor(0.0, device=pred.device)
    
    # 计算所有样本对之间的排序loss
    total_loss = 0.0
    count = 0
    
    for i in range(batch_size):
        for j in range(i+1, batch_size):
            # 对每个参数维度检查是否有显著差异
            target_diff = target[i] - target[j]  # [n_params]
            pred_diff = pred[i] - pred[j]        # [n_params]
            
            # 只考虑target差异超过threshold的维度
            significant_mask = torch.abs(target_diff) > threshold
            if not significant_mask.any():
                continue
                
            # 对显著差异的维度，要求pred保持同样的相对顺序
            for k in range(len(PARAM_KEYS)):
                if significant_mask[k]:
                    # target_diff[k] > 0 意味着 target[i] > target[j]，预测也应该 pred[i] > pred[j]
                    if target_diff[k] > 0:
                        # 希望 pred_diff[k] > 0，如果 pred_diff[k] < margin，则施加penalty
                        loss_k = torch.relu(margin - pred_diff[k])
                    else:
                        # target_diff[k] < 0，希望 pred_diff[k] < 0，如果 pred_diff[k] > -margin，则施加penalty
                        loss_k = torch.relu(margin + pred_diff[k])
                    total_loss += loss_k
                    count += 1
    
    return total_loss / max(count, 1)

class MetaDataset(Dataset):
    def __init__(self, rows):
        self.rows = rows
        self.X = np.stack([r['features'] for r in rows]).astype(np.float32)
        self.Y = np.stack([r['targets'] for r in rows]).astype(np.float32)
        # 保存原始数据用于ranking loss（当需要top-k时）
        self.raw_data = rows
    def __len__(self):
        return len(self.rows)
    def __getitem__(self, idx):
        return self.X[idx], self.Y[idx]


def load_csv(path: str, delta_mode: bool, use_soft: bool):
    rows = []
    with open(path,'r') as f:
        reader = csv.DictReader(f)
        for line in reader:
            # 跳过失败行
            if line.get('metric_success','1') in ['0','False','false']:
                continue
            feats = [float(line[k]) for k in FEATURE_ORDER]
            # direct: 目标为 param_* 或 soft_param_* 绝对值; delta: 目标为 (param - rule) 或 (soft - rule)
            param_vals = []  # 绝对参数 (硬或软)
            rule_vals = []
            valid = True
            for p in PARAM_KEYS:
                pk_hard = 'param_'+p
                pk_soft = 'soft_param_'+p
                pk = pk_soft if (use_soft and pk_soft in line) else pk_hard
                rk = 'rule_'+p
                if pk not in line:
                    valid = False; break
                param_vals.append(float(line[pk]))
                if delta_mode:
                    if rk not in line:
                        valid = False; break
                    rule_vals.append(float(line[rk]))
            if not valid:
                continue
            if delta_mode:
                targets = np.array(param_vals) - np.array(rule_vals)
                rows.append({'features': np.array(feats), 'targets': targets, 'rule': np.array(rule_vals)})
            else:
                rows.append({'features': np.array(feats), 'targets': np.array(param_vals)})
    return rows


def normalize_features(rows):
    X = np.stack([r['features'] for r in rows])
    mean = X.mean(axis=0)
    std = X.std(axis=0) + 1e-6
    for r in rows:
        r['features'] = (r['features'] - mean)/std
    return mean, std


def normalize_targets_direct(rows):
    """Direct 模式：参数线性映射到 [0,1]"""
    for r in rows:
        t = r['targets']
        out = []
        for val, p in zip(t, PARAM_KEYS):
            lo, hi = PARAM_BOUNDS[p]
            v = (val - lo)/(hi - lo)
            v = np.clip(v, 0.0, 1.0)
            out.append(v)
        r['targets'] = np.array(out, dtype=np.float32)

def normalize_targets_delta(rows):
    """Delta 模式：delta=(param-rule)，再除以 (hi-lo)/2，使其大致落在 [-1,1] 区间。"""
    for r in rows:
        t = r['targets']  # 原始 delta
        scaled = []
        for d, p in zip(t, PARAM_KEYS):
            lo, hi = PARAM_BOUNDS[p]
            scale = (hi - lo) / 2.0
            v = d / (scale + 1e-6)
            v = np.clip(v, -1.0, 1.0)
            scaled.append(v)
        r['targets'] = np.array(scaled, dtype=np.float32)


def train(args):
    delta_mode = args.delta_mode
    use_soft = args.use_soft_label
    rows = load_csv(args.data, delta_mode=delta_mode, use_soft=use_soft)
    if len(rows) == 0:
        print('No usable rows in dataset.')
        return
    feat_mean, feat_std = normalize_features(rows)
    if delta_mode:
        normalize_targets_delta(rows)
    else:
        normalize_targets_direct(rows)

    # 划分训练/验证
    rng = np.random.default_rng(123)
    rng.shuffle(rows)
    n = len(rows)
    n_val = max(1, int(n*0.15))
    val_rows = rows[:n_val]
    train_rows = rows[n_val:]

    train_ds = MetaDataset(train_rows)
    val_ds = MetaDataset(val_rows)

    train_loader = DataLoader(train_ds, batch_size=args.batch, shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=args.batch, shuffle=False)

    model = SimpleMLP(in_dim=len(FEATURE_ORDER), hidden=args.hidden, out_dim=len(PARAM_KEYS), use_multi_head=args.use_multi_head)
    if args.use_adamw:
        opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    else:
        opt = torch.optim.Adam(model.parameters(), lr=args.lr)
    scheduler = None
    if args.cosine:
        T_max = max(1, args.epochs - 1)
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=T_max, eta_min=args.eta_min)
    criterion = nn.SmoothL1Loss() if delta_mode else nn.MSELoss()

    best_val = math.inf
    patience = args.patience
    wait = 0
    min_epochs = args.min_epochs
    min_delta = args.min_delta
    use_early_stop = (not args.no_early_stop) and patience > 0

    # 确保模型输出目录存在
    model_path = Path(args.out_model)
    model_path.parent.mkdir(parents=True, exist_ok=True)

    # 参数损失权重
    if args.param_loss_weights:
        w_list = [float(x) for x in args.param_loss_weights.split(',')]
        if len(w_list) != len(PARAM_KEYS):
            raise ValueError('param_loss_weights 长度不等于参数数目')
        loss_weights = torch.tensor(w_list, dtype=torch.float32)
    else:
        # 默认：强调学习困难的参数 initial_weight / curvature_window
        default_w = [1.5,1.05,0.9,1.0,1.05,1.2,1.4,0.8]  # 加大 initial_weight(1.5) 和 curvature_window(1.4) 权重
        loss_weights = torch.tensor(default_w, dtype=torch.float32)

    for epoch in range(1, args.epochs+1):
        model.train()
        total_loss = 0.0
        for xb,yb in train_loader:
            opt.zero_grad()
            pred = model(xb)
            
            # 基础损失（MSE或SmoothL1）
            loss_basic = criterion(pred, yb)
            
            # 加入按参数维度加权（MSE或SmoothL1 逐元素后再加权）
            if isinstance(criterion, nn.MSELoss) or isinstance(criterion, nn.SmoothL1Loss):
                # 重新计算逐元素损失
                per_elem = (pred - yb).abs()
                if isinstance(criterion, nn.MSELoss):
                    per_elem = (pred - yb) ** 2
                # 按维度平均后加权再取均值
                per_dim = per_elem.mean(dim=0) * loss_weights.to(per_elem.device)
                loss = per_dim.mean()
            else:
                loss = loss_basic
            
            # 添加ranking loss（如果启用）
            if args.use_ranking:
                rank_loss = ranking_loss(pred, yb, margin=args.rank_margin, threshold=args.rank_threshold)
                loss = loss + args.ranking_weight * rank_loss
            
            loss.backward()
            opt.step()
            total_loss += loss.item() * xb.size(0)
        avg_train = total_loss / len(train_ds)

        model.eval()
        with torch.no_grad():
            val_loss = 0.0
            # 用于按维度日志：收集未加权 per-dim 误差（SmoothL1 -> L1， MSE -> MSE）
            per_dim_err_sum = torch.zeros(len(PARAM_KEYS))
            count_val = 0
            for xb,yb in val_loader:
                pred = model(xb)
                per_elem = (pred - yb).abs()
                if isinstance(criterion, nn.MSELoss):
                    per_elem = (pred - yb) ** 2
                # 聚合未加权 per-dim 平均
                per_dim_err_sum += per_elem.sum(dim=0).cpu()
                count_val += per_elem.size(0)
                per_dim = per_elem.mean(dim=0) * loss_weights.to(per_elem.device)
                loss = per_dim.mean()
                val_loss += loss.item() * xb.size(0)
            val_loss /= len(val_ds)
            if args.log_per_dim:
                mean_per_dim_raw = (per_dim_err_sum / count_val).numpy()
                metric_name = 'MAE' if isinstance(criterion, nn.SmoothL1Loss) else 'MSE'
                per_dim_str = ' '.join(f"{k}:{v:.4f}" for k,v in zip(PARAM_KEYS, mean_per_dim_raw))
                print(f"  val per-dim {metric_name}: {per_dim_str}")

        current_lr = opt.param_groups[0]['lr']
        print(f"Epoch {epoch} ({'delta' if delta_mode else 'direct'}): train={avg_train:.4f} val={val_loss:.4f} lr={current_lr:.6f}")
        improvement = best_val - val_loss
        if val_loss < best_val - min_delta:
            best_val = val_loss
            wait = 0
            try:
                torch.save(model.state_dict(), model_path)
            except Exception as e:
                print(f"[WARN] Save model failed: {e}")
        else:
            if use_early_stop and epoch >= min_epochs:
                wait += 1
                if wait >= patience:
                    print(f"Early stopping (no improvement > {min_delta} for {patience} epochs after epoch {min_epochs}).")
                    break
            # 仍然保存第一个 epoch 模型 (best_val==inf) 以防未改进
            if best_val is math.inf:
                try:
                    torch.save(model.state_dict(), model_path)
                except Exception:
                    pass
        if scheduler:
            scheduler.step()

    # 保存 scaler
    out_scaler = Path(args.out_scaler)
    out_scaler.parent.mkdir(parents=True, exist_ok=True)
    np.savez(out_scaler, mean=feat_mean, std=feat_std, delta_mode=np.array([1 if delta_mode else 0]))
    print(f"Saved model to {model_path}, scaler to {args.out_scaler} (delta_mode={delta_mode})")


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument('--data', type=str, default='meta/dataset/meta_params_dataset.csv')
    ap.add_argument('--epochs', type=int, default=120)
    ap.add_argument('--batch', type=int, default=32)
    ap.add_argument('--hidden', type=int, default=96)
    ap.add_argument('--lr', type=float, default=1e-3)
    ap.add_argument('--patience', type=int, default=15, help='早停耐心（在达到 min_epochs 后）')
    ap.add_argument('--min-epochs', type=int, default=40, help='最少训练轮数，未达到不触发早停')
    ap.add_argument('--min-delta', type=float, default=5e-4, help='验证集改进最小阈值，小于该值视为无改进')
    ap.add_argument('--no-early-stop', action='store_true', help='关闭早停，始终跑满 epochs')
    ap.add_argument('--out-model', type=str, default='meta/models/meta_mlp.pt')
    ap.add_argument('--out-scaler', type=str, default='meta/models/meta_scaler.npz')
    ap.add_argument('--delta-mode', action='store_true', help='训练 delta 残差模式而非 direct 绝对值模式')
    ap.add_argument('--use-soft-label', action='store_true', help='若存在 soft_param_* 列则优先使用软标签')
    ap.add_argument('--param-loss-weights', type=str, default='', help='以逗号分隔的8个浮点数，对各参数损失加权')
    ap.add_argument('--use-adamw', action='store_true', help='使用 AdamW 优化器')
    ap.add_argument('--weight-decay', type=float, default=1e-4, help='AdamW 权重衰减系数')
    ap.add_argument('--cosine', action='store_true', help='使用余弦退火学习率调度')
    ap.add_argument('--eta-min', type=float, default=1e-4, help='余弦退火最低学习率')
    ap.add_argument('--log-per-dim', action='store_true', help='打印验证集按参数维度的误差 (MAE 或 MSE)')
    
    # Ranking Loss参数
    ap.add_argument('--use-ranking', action='store_true', help='启用ranking loss利用参数相对顺序')
    ap.add_argument('--ranking-weight', type=float, default=0.1, help='ranking loss权重系数')
    ap.add_argument('--rank-margin', type=float, default=0.3, help='ranking违反惩罚margin')
    ap.add_argument('--rank-threshold', type=float, default=0.15, help='参数差异显著性阈值')
    
    # Multi-head架构参数
    ap.add_argument('--use-multi-head', action='store_true', help='使用多头架构按参数功能分组')
    
    return ap.parse_args()

if __name__ == '__main__':
    args = parse_args()
    train(args)
