#!/usr/bin/env python3
"""
深度校准网络 (Deep Calibration Network)

实现一个神经网络来学习更复杂的校准映射，
可以同时处理预测值、不确定度和特征信息进行校准。
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__)))

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import json
from typing import Dict, List, Tuple, Any
from sklearn.model_selection import train_test_split
import argparse

from models_arch.focus_param_net import FocusParamNet
from models_arch.focus_dataset import FocusParamDataset

class DeepCalibrationNetwork(nn.Module):
    """深度校准网络"""
    
    def __init__(self, input_dim: int = 6, hidden_dims: List[int] = [64, 32]):
        """
        Args:
            input_dim: 输入特征维度 (features + prediction + uncertainty)
            hidden_dims: 隐藏层维度列表
        """
        super().__init__()
        
        layers = []
        prev_dim = input_dim
        
        for hidden_dim in hidden_dims:
            layers.extend([
                nn.Linear(prev_dim, hidden_dim),
                nn.ReLU(),
                nn.Dropout(0.1)
            ])
            prev_dim = hidden_dim
        
        # 输出层：校准后的不确定度 (必须为正)
        layers.append(nn.Linear(prev_dim, 1))
        layers.append(nn.Softplus())  # 确保输出为正
        
        self.network = nn.Sequential(*layers)
    
    def forward(self, features: torch.Tensor, predictions: torch.Tensor, 
                uncertainties: torch.Tensor) -> torch.Tensor:
        """
        Args:
            features: 地图特征 [batch, 4]
            predictions: 模型预测值 [batch, 1]
            uncertainties: 原始不确定度 [batch, 1]
        
        Returns:
            校准后的不确定度 [batch, 1]
        """
        # 拼接输入特征
        x = torch.cat([features, predictions.unsqueeze(-1), uncertainties.unsqueeze(-1)], dim=-1)
        
        # 通过网络获得校准因子
        calibration_factor = self.network(x).squeeze(-1)
        
        # 应用校准
        calibrated_uncertainty = uncertainties * calibration_factor
        
        return calibrated_uncertainty

def calibration_loss(calibrated_uncertainties: torch.Tensor, 
                    predictions: torch.Tensor, 
                    targets: torch.Tensor,
                    coverage_weight: float = 1.0,
                    nll_weight: float = 0.1) -> torch.Tensor:
    """
    校准损失函数，结合覆盖率损失和NLL损失
    
    Args:
        calibrated_uncertainties: 校准后的不确定度
        predictions: 预测值
        targets: 真实值
        coverage_weight: 覆盖率损失权重
        nll_weight: NLL损失权重
    """
    errors = torch.abs(predictions - targets)
    
    # 覆盖率损失：希望68%的样本误差 <= 1σ
    within_1sigma = (errors <= calibrated_uncertainties).float()
    coverage_loss = torch.mean((within_1sigma - 0.68) ** 2)
    
    # NLL损失：负对数似然
    nll_loss = 0.5 * torch.log(2 * torch.pi * calibrated_uncertainties**2) + \
               0.5 * (errors**2 / calibrated_uncertainties**2)
    nll_loss = torch.mean(nll_loss)
    
    return coverage_weight * coverage_loss + nll_weight * nll_loss

def train_deep_calibrator(model: FocusParamNet, dataloader, param: str, 
                         device: str = 'cpu', epochs: int = 100) -> DeepCalibrationNetwork:
    """训练深度校准网络"""
    
    print(f"🧠 训练深度校准网络 for {param}...")
    
    # 收集训练数据
    all_features = []
    all_predictions = []
    all_uncertainties = []
    all_targets = []
    
    with torch.no_grad():
        for batch in dataloader:
            if param not in batch['targets_cont']:
                continue
                
            features = batch['features']
            mc_pred = model.predict_with_uncertainty(features, mc_times=10)
            
            all_features.append(features.cpu())
            all_predictions.append(mc_pred[param].cpu())
            all_uncertainties.append(torch.sqrt(mc_pred[f"{param}_var"]).cpu())
            all_targets.append(batch['targets_cont'][param].cpu())
    
    if not all_features:
        raise ValueError(f"No data found for parameter {param}")
    
    # 合并数据
    features = torch.cat(all_features, dim=0)
    predictions = torch.cat(all_predictions, dim=0)
    uncertainties = torch.cat(all_uncertainties, dim=0)
    targets = torch.cat(all_targets, dim=0)
    
    # 训练/验证分割
    n_samples = len(features)
    indices = torch.randperm(n_samples)
    train_size = int(0.8 * n_samples)
    
    train_indices = indices[:train_size]
    val_indices = indices[train_size:]
    
    train_features = features[train_indices].to(device)
    train_predictions = predictions[train_indices].to(device)
    train_uncertainties = uncertainties[train_indices].to(device)
    train_targets = targets[train_indices].to(device)
    
    val_features = features[val_indices].to(device)
    val_predictions = predictions[val_indices].to(device)
    val_uncertainties = uncertainties[val_indices].to(device)
    val_targets = targets[val_indices].to(device)
    
    # 初始化网络
    calibrator = DeepCalibrationNetwork().to(device)
    optimizer = optim.Adam(calibrator.parameters(), lr=1e-3, weight_decay=1e-4)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, patience=10, factor=0.5)
    
    best_val_loss = float('inf')
    patience_counter = 0
    
    for epoch in range(epochs):
        # 训练
        calibrator.train()
        optimizer.zero_grad()
        
        calibrated_uncert = calibrator(train_features, train_predictions, train_uncertainties)
        loss = calibration_loss(calibrated_uncert, train_predictions, train_targets)
        
        loss.backward()
        optimizer.step()
        
        # 验证
        calibrator.eval()
        with torch.no_grad():
            val_calibrated_uncert = calibrator(val_features, val_predictions, val_uncertainties)
            val_loss = calibration_loss(val_calibrated_uncert, val_predictions, val_targets)
            
            # 计算验证指标
            val_errors = torch.abs(val_predictions - val_targets)
            val_coverage = torch.mean((val_errors <= val_calibrated_uncert).float()).item()
        
        scheduler.step(val_loss)
        
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            patience_counter = 0
            best_model_state = calibrator.state_dict().copy()
        else:
            patience_counter += 1
        
        if epoch % 20 == 0:
            print(f"  Epoch {epoch}: Loss={loss.item():.4f}, Val_Loss={val_loss.item():.4f}, Coverage={val_coverage:.3f}")
        
        if patience_counter >= 15:
            print(f"  Early stopping at epoch {epoch}")
            break
    
    # 加载最佳模型
    calibrator.load_state_dict(best_model_state)
    print(f"✅ 深度校准网络训练完成，最佳验证损失: {best_val_loss:.4f}")
    
    return calibrator

def apply_deep_calibration(calibrator: DeepCalibrationNetwork, features: torch.Tensor,
                          predictions: torch.Tensor, uncertainties: torch.Tensor) -> np.ndarray:
    """应用深度校准"""
    calibrator.eval()
    with torch.no_grad():
        calibrated = calibrator(features, predictions, uncertainties)
        return calibrated.cpu().numpy()

def evaluate_deep_calibration(model: FocusParamNet, dataloader, param: str, 
                             calibrator: DeepCalibrationNetwork, device: str = 'cpu') -> Dict[str, float]:
    """评估深度校准效果"""
    
    all_features = []
    all_predictions = []
    all_uncertainties = []
    all_targets = []
    
    with torch.no_grad():
        for batch in dataloader:
            if param not in batch['targets_cont']:
                continue
                
            features = batch['features']
            mc_pred = model.predict_with_uncertainty(features, mc_times=10)
            
            all_features.append(features)
            all_predictions.append(mc_pred[param])
            all_uncertainties.append(torch.sqrt(mc_pred[f"{param}_var"]))
            all_targets.append(batch['targets_cont'][param])
    
    if not all_features:
        return {}
    
    features = torch.cat(all_features, dim=0).to(device)
    predictions = torch.cat(all_predictions, dim=0).to(device)
    uncertainties = torch.cat(all_uncertainties, dim=0).to(device)
    targets = torch.cat(all_targets, dim=0).to(device)
    
    # 应用校准
    calibrated_uncertainties = calibrator(features, predictions, uncertainties)
    
    # 计算指标
    errors = torch.abs(predictions - targets)
    
    coverage_68 = torch.mean((errors <= calibrated_uncertainties).float()).item()
    coverage_95 = torch.mean((errors <= 1.96 * calibrated_uncertainties).float()).item()
    
    # ECE计算
    n_bins = 10
    uncert_max = torch.max(calibrated_uncertainties).item()
    bin_boundaries = torch.linspace(0, uncert_max, n_bins + 1)
    bin_boundaries[-1] += 1e-8
    
    ece = 0.0
    total_samples = 0
    
    for i in range(n_bins):
        mask = (calibrated_uncertainties > bin_boundaries[i]) & (calibrated_uncertainties <= bin_boundaries[i + 1])
        if not torch.any(mask):
            continue
            
        bin_size = torch.sum(mask).item()
        bin_coverage = torch.mean((errors[mask] <= calibrated_uncertainties[mask]).float()).item()
        
        ece += bin_size * abs(bin_coverage - 0.68)
        total_samples += bin_size
    
    ece = ece / total_samples if total_samples > 0 else 0.0
    
    # NLL
    nll = 0.5 * torch.log(2 * torch.pi * calibrated_uncertainties**2) + \
          0.5 * (errors**2 / calibrated_uncertainties**2)
    avg_nll = torch.mean(nll).item()
    
    return {
        'ece': ece,
        'coverage_68': coverage_68,
        'coverage_95': coverage_95,
        'nll': avg_nll
    }

def main():
    parser = argparse.ArgumentParser(description="深度校准网络")
    parser.add_argument('--model', type=str, required=True, help='模型路径')
    parser.add_argument('--data', type=str, required=True, help='数据集路径')
    parser.add_argument('--output', type=str, default='deep_calibration_results.json', help='输出结果路径')
    parser.add_argument('--epochs', type=int, default=100, help='训练轮数')
    parser.add_argument('--device', type=str, default='cpu', help='设备')
    
    args = parser.parse_args()
    
    print(f"🚀 开始深度校准网络训练")
    
    # 加载模型和数据
    checkpoint = torch.load(args.model, map_location='cpu')
    args_in_ckpt = checkpoint.get('args', {}) or {}
    
    default_cont_specs = {
        "initial_weight": (1.0, 50.0),
        "lambda_risk": (0.2, 4.0),
        "lambda_smooth": (0.1, 3.0),
        "lambda_bonus": (0.0, 2.0),
    }
    enabled_cont = args_in_ckpt.get('enabled_continuous') or list(default_cont_specs.keys())
    enabled_disc = args_in_ckpt.get('enabled_discrete') or ["frontier_radius", "recent_visited_len"]
    
    cont_specs = {k: v for k, v in default_cont_specs.items() if k in enabled_cont}
    disc_specs = {"frontier_radius": [2, 3, 4, 5, 6], "recent_visited_len": [10, 20, 30, 40, 50]}
    disc_specs = {k: v for k, v in disc_specs.items() if k in enabled_disc}
    
    model = FocusParamNet(input_dim=4, continuous_specs=cont_specs, discrete_specs=disc_specs)
    model.load_state_dict(checkpoint['model_state'], strict=False)
    model.eval()
    model = model.to(args.device)
    
    dataset = FocusParamDataset(args.data, continuous_params=enabled_cont, discrete_params=enabled_disc)
    dataloader = torch.utils.data.DataLoader(dataset, batch_size=32, shuffle=True, 
                                            collate_fn=dataset.collate_fn)
    
    print(f"启用参数: {enabled_cont}")
    
    results = {}
    
    for param in enabled_cont:
        print(f"\n🎯 处理参数: {param}")
        
        try:
            # 训练深度校准器
            calibrator = train_deep_calibrator(model, dataloader, param, args.device, args.epochs)
            
            # 评估校准效果
            metrics = evaluate_deep_calibration(model, dataloader, param, calibrator, args.device)
            
            results[param] = {
                'deep_calibration': metrics
            }
            
            print(f"深度校准结果: ECE={metrics['ece']:.3f}, Coverage_68={metrics['coverage_68']:.3f}")
            
        except Exception as e:
            print(f"❌ 参数 {param} 校准失败: {e}")
            continue
    
    # 保存结果
    with open(args.output, 'w') as f:
        json.dump(results, f, indent=2, default=float)
    
    print(f"\n💾 深度校准结果已保存到: {args.output}")
    
    # 打印总结
    print(f"\n📋 深度校准总结:")
    for param, param_results in results.items():
        if 'deep_calibration' in param_results:
            metrics = param_results['deep_calibration']
            print(f"{param}: ECE={metrics['ece']:.3f}, Coverage_68={metrics['coverage_68']:.3f}")

if __name__ == "__main__":
    main()