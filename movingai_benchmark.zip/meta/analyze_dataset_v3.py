#!/usr/bin/env python3
"""
数据集质量分析脚本
分析focused_training_dataset_v3.jsonl的特征分布、参数范围和标签平衡性
"""
import json
import numpy as np
import pandas as pd
from pathlib import Path
import matplotlib.pyplot as plt

def analyze_dataset(jsonl_path: str):
    """分析JSONL数据集"""
    print(f"📊 分析数据集: {jsonl_path}")
    
    # 读取数据
    records = []
    with open(jsonl_path, 'r') as f:
        for line in f:
            records.append(json.loads(line.strip()))
    
    df = pd.DataFrame(records)
    print(f"总样本数: {len(df)}")
    
    # 标签分布
    label_counts = df['label'].value_counts()
    print(f"\n📈 标签分布:")
    print(f"成功样本 (label=1): {label_counts.get(1, 0)} ({label_counts.get(1, 0)/len(df)*100:.1f}%)")
    print(f"失败样本 (label=0): {label_counts.get(0, 0)} ({label_counts.get(0, 0)/len(df)*100:.1f}%)")
    
    # 特征分布
    print(f"\n🎯 核心特征分布:")
    feature_cols = ['obstacle_density', 'confidence_score', 'start_goal_distance']
    for col in feature_cols:
        if col in df.columns:
            stats = df[col].describe()
            print(f"{col}: 范围 {stats['min']:.3f}-{stats['max']:.3f}, 均值 {stats['mean']:.3f}")
    
    # 参数分布
    print(f"\n⚙️ 参数分布:")
    param_cols = ['initial_weight', 'lambda_risk', 'lambda_smooth', 'lambda_bonus', 
                  'frontier_radius', 'recent_visited_len']
    for col in param_cols:
        if col in df.columns:
            stats = df[col].describe()
            print(f"{col}: 范围 {stats['min']:.2f}-{stats['max']:.2f}, 均值 {stats['mean']:.2f}")
    
    # 成功vs失败的参数差异
    print(f"\n🔍 成功vs失败案例对比:")
    success_df = df[df['label'] == 1]
    fail_df = df[df['label'] == 0]
    
    if len(success_df) > 0 and len(fail_df) > 0:
        for col in param_cols:
            if col in df.columns:
                succ_mean = success_df[col].mean()
                fail_mean = fail_df[col].mean()
                print(f"{col}: 成功 {succ_mean:.2f} vs 失败 {fail_mean:.2f} (差异: {succ_mean-fail_mean:+.2f})")
    
    # 难度分布
    if 'difficulty_score' in df.columns:
        print(f"\n🏔️ 难度分布:")
        difficulty_stats = df['difficulty_score'].describe()
        print(f"难度分数: {difficulty_stats['min']:.3f}-{difficulty_stats['max']:.3f}, 均值 {difficulty_stats['mean']:.3f}")
        
        # 按难度分层的成功率
        df['difficulty_bin'] = pd.cut(df['difficulty_score'], bins=5, labels=['很容易', '容易', '中等', '困难', '很困难'])
        success_by_difficulty = df.groupby('difficulty_bin')['label'].agg(['count', 'mean'])
        print(f"不同难度的成功率:")
        for idx, row in success_by_difficulty.iterrows():
            print(f"  {idx}: {row['mean']*100:.1f}% ({int(row['count'])} 样本)")
    
    # 数据质量检查
    print(f"\n✅ 数据质量:")
    null_counts = df.isnull().sum()
    if null_counts.sum() > 0:
        print(f"缺失值:")
        for col, count in null_counts[null_counts > 0].items():
            print(f"  {col}: {count} ({count/len(df)*100:.1f}%)")
    else:
        print("无缺失值 ✓")
    
    # 重复样本检查
    duplicates = df.duplicated().sum()
    print(f"重复样本: {duplicates} ({duplicates/len(df)*100:.1f}%)")
    
    return df

def compare_datasets(old_path: str, new_path: str):
    """对比新旧数据集"""
    print(f"\n🔄 数据集对比:")
    
    # 读取旧数据集
    old_records = []
    with open(old_path, 'r') as f:
        for line in f:
            old_records.append(json.loads(line.strip()))
    old_df = pd.DataFrame(old_records)
    
    # 读取新数据集
    new_records = []
    with open(new_path, 'r') as f:
        for line in f:
            new_records.append(json.loads(line.strip()))
    new_df = pd.DataFrame(new_records)
    
    print(f"旧数据集: {len(old_df)} 样本")
    print(f"新数据集: {len(new_df)} 样本")
    print(f"扩展倍数: {len(new_df)/len(old_df):.1f}x")
    
    # 成功率对比
    old_success_rate = old_df['label'].mean()
    new_success_rate = new_df['label'].mean()
    print(f"成功率: 旧 {old_success_rate*100:.1f}% -> 新 {new_success_rate*100:.1f}%")

def main():
    # 分析新数据集
    new_dataset_path = "data_v2/focused_training_dataset_v3.jsonl"
    df = analyze_dataset(new_dataset_path)
    
    # 对比旧数据集
    old_dataset_path = "data_v2/focused_training_dataset_v2.jsonl"
    if Path(old_dataset_path).exists():
        compare_datasets(old_dataset_path, new_dataset_path)
    
    print(f"\n🎉 数据集分析完成!")
    print(f"建议: 数据质量良好，可以开始训练模型")

if __name__ == "__main__":
    main()