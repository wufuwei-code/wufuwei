"""训练多头 FocusParamNet 的脚本

特性:
  - 读取 JSONL 数据集 (failure-focused 或混合)
  - 连续参数: Huber 损失; 离散参数: 交叉熵 + 类别权重
  - 支持样本权重 (失败样本 / 难度标签)
  - 早停 (基于验证集综合得分) + 最佳模型保存
  - 可选: 启用 MC Dropout 验证不确定度统计 (var 平均)
  - 消融参数 (禁用某些参数预测) TODO: 后续扩展 --disable-* 参数

用法示例:
  python -m meta.train_focus_param_net \
      --train data_v2/focused_training_dataset_v2.jsonl \
      --val data_v2/focused_training_dataset_v2.jsonl \
      --out-dir models_runs/focus_multihead_v1 \
      --epochs 50 --batch-size 256

后续可扩展:
  - 添加 hard mining 缓冲
  - 添加蒸馏 (--teacher / KD loss)
  - 添加 resume (--resume ckpt)
"""
from __future__ import annotations
import argparse
import json
import math
import os
import time
from dataclasses import dataclass
from typing import Dict, Any, List

import torch
from torch.utils.data import DataLoader, random_split

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from models_arch.focus_param_net import FocusParamNet
from models_arch.focus_dataset import FocusParamDataset


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument('--train', type=str, required=True, help='训练集 JSONL')
    p.add_argument('--val', type=str, default=None, help='验证集 JSONL (若不提供则从训练集中切分)')
    p.add_argument('--val-split', type=float, default=0.1, help='未提供 --val 时从训练集中切分比例')
    p.add_argument('--out-dir', type=str, required=True)
    p.add_argument('--epochs', type=int, default=60)
    p.add_argument('--batch-size', type=int, default=256)
    p.add_argument('--lr', type=float, default=1e-3)
    p.add_argument('--weight-decay', type=float, default=1e-2)
    p.add_argument('--huber-delta', type=float, default=1.0)
    p.add_argument('--dropout', type=float, default=0.1)
    p.add_argument('--early-patience', type=int, default=10)
    p.add_argument('--device', type=str, default='cuda' if torch.cuda.is_available() else 'cpu')
    p.add_argument('--mc-dropout', action='store_true', help='在验证时执行 MC Dropout 不确定度统计')
    p.add_argument('--mc-times', type=int, default=8)
    p.add_argument('--num-workers', type=int, default=0)
    p.add_argument('--seed', type=int, default=42)
    # 消融：禁用特定连续/离散参数 (名称需与数据集中字段一致)
    p.add_argument('--disable-cont', nargs='*', default=[], help='禁用的连续参数名称列表')
    p.add_argument('--disable-disc', nargs='*', default=[], help='禁用的离散参数名称列表')
    p.add_argument('--ablation-tag', type=str, default='', help='为该次消融实验添加标签（写入 checkpoint args）')
    return p.parse_args()


def set_seed(seed: int):
    import random, numpy as np
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def build_datasets(args, enabled_continuous, enabled_discrete, discrete_value_space):
    full_train = FocusParamDataset(
        args.train,
        continuous_params=enabled_continuous,
        discrete_params=enabled_discrete,
        discrete_value_space=discrete_value_space,
    )
    if args.val:
        val_ds = FocusParamDataset(
            args.val,
            continuous_params=enabled_continuous,
            discrete_params=enabled_discrete,
            discrete_value_space=discrete_value_space,
            drop_missing=True,
        )
        train_ds = full_train
    else:
        n_total = len(full_train)
        n_val = max(1, int(math.ceil(n_total * args.val_split)))
        n_train = n_total - n_val
        train_ds, val_ds = random_split(full_train, [n_train, n_val])
    return train_ds, val_ds, full_train


def collate_wrapper(ds_like):
    # random_split 返回 Subset, 其 dataset 具有 collate_fn
    base = ds_like.dataset if hasattr(ds_like, 'dataset') else ds_like
    return base.collate_fn


def evaluate(model: FocusParamNet, loader: DataLoader, device: str, huber_delta: float, mc_dropout: bool = False, mc_times: int = 8):
    model.eval()
    total_cont_mae: Dict[str, float] = {}
    total_disc_acc: Dict[str, float] = {}
    counts_cont: Dict[str, int] = {}
    counts_disc: Dict[str, int] = {}
    total_batches = 0
    mc_var_accum: Dict[str, float] = {}
    mc_var_counts: Dict[str, int] = {}

    with torch.no_grad():
        for batch in loader:
            total_batches += 1
            x = batch['features'].to(device)
            # 将batch数据移到设备
            for key in ['targets_cont', 'targets_disc']:
                if key in batch:
                    for name, tensor in batch[key].items():
                        batch[key][name] = tensor.to(device)
            out = model.forward_train(x)
            # 连续 MAE
            for name, tgt in batch['targets_cont'].items():
                pred = out['continuous'][name]
                mae = (pred - tgt).abs().mean().item()
                total_cont_mae[name] = total_cont_mae.get(name, 0.0) + mae
                counts_cont[name] = counts_cont.get(name, 0) + 1
            # 离散 acc
            for name, tgt in batch['targets_disc'].items():
                logits = out['discrete'][name]
                pred_idx = logits.argmax(dim=-1)
                acc = (pred_idx == tgt).float().mean().item()
                total_disc_acc[name] = total_disc_acc.get(name, 0.0) + acc
                counts_disc[name] = counts_disc.get(name, 0) + 1
            # 不确定度 (MC variance) 可选
            if mc_dropout:
                # 暂时启用 train 再多次采样
                was_training = model.training
                model.train()
                mc_res = model.predict_with_uncertainty(x, mc_times=mc_times, return_all=False)
                if not was_training:
                    model.eval()
                for k, v in mc_res.items():
                    if k.endswith('_var'):  # 形如 name_var
                        base_name = k[:-4]
                        var_mean = v.mean().item()
                        mc_var_accum[base_name] = mc_var_accum.get(base_name, 0.0) + var_mean
                        mc_var_counts[base_name] = mc_var_counts.get(base_name, 0) + 1

    metrics = {}
    for k, v in total_cont_mae.items():
        metrics[f'mae_{k}'] = v / counts_cont[k]
    for k, v in total_disc_acc.items():
        metrics[f'acc_{k}'] = v / counts_disc[k]
    if mc_dropout:
        for k, v in mc_var_accum.items():
            metrics[f'var_{k}'] = v / mc_var_counts[k]
    # 合成一个 score：连续 MAE 的负和 + 离散准确率的和
    score = 0.0
    for k in total_cont_mae.keys():
        score -= metrics[f'mae_{k}']
    for k in total_disc_acc.keys():
        score += metrics[f'acc_{k}']
    metrics['composite_score'] = score
    return metrics


def save_checkpoint(state: Dict[str, Any], path: str):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    torch.save(state, path)


def main():
    args = parse_args()
    set_seed(args.seed)
    os.makedirs(args.out_dir, exist_ok=True)

    # 默认 specs (需与 FocusParamNet 内部保持一致; 为避免导入内部常量冗余，这里硬编码一次用于裁剪)
    default_cont_specs = {
        "initial_weight": (1.0, 50.0),
        "lambda_risk": (0.2, 4.0),
        "lambda_smooth": (0.1, 3.0),
        "lambda_bonus": (0.0, 2.0),
    }
    default_disc_specs = {
        "frontier_radius": [2, 3, 4, 5, 6],
        "recent_visited_len": [10, 20, 30, 40, 50],
    }

    # 过滤禁用列表
    enabled_continuous = [k for k in default_cont_specs.keys() if k not in set(args.disable_cont)]
    enabled_discrete = [k for k in default_disc_specs.keys() if k not in set(args.disable_disc)]
    filtered_cont_specs = {k: v for k, v in default_cont_specs.items() if k in enabled_continuous}
    filtered_disc_specs = {k: v for k, v in default_disc_specs.items() if k in enabled_discrete}

    if not filtered_cont_specs and not filtered_disc_specs:
        raise ValueError("禁止同时禁用全部连续与离散头：至少保留一个预测目标以进行训练。")

    print("[Ablation] Enabled continuous heads:", enabled_continuous)
    print("[Ablation] Enabled discrete heads:", enabled_discrete)
    if args.disable_cont:
        print("[Ablation] Disabled continuous:", args.disable_cont)
    if args.disable_disc:
        print("[Ablation] Disabled discrete:", args.disable_disc)
    if args.ablation_tag:
        print(f"[Ablation] Tag: {args.ablation_tag}")

    train_ds, val_ds, full_train = build_datasets(args, enabled_continuous, enabled_discrete, filtered_disc_specs)
    collate_fn_train = collate_wrapper(train_ds)
    collate_fn_val = collate_wrapper(val_ds)

    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True, collate_fn=collate_fn_train, num_workers=args.num_workers)
    val_loader = DataLoader(val_ds, batch_size=args.batch_size, shuffle=False, collate_fn=collate_fn_val, num_workers=args.num_workers)

    # 取一个样本确定特征维度
    first_item = train_ds[0] if not hasattr(train_ds, 'dataset') else train_ds.dataset[train_ds.indices[0]]
    feat_dim = first_item['features'].shape[0]

    model = FocusParamNet(
        input_dim=feat_dim,
        dropout=args.dropout,
        continuous_specs=filtered_cont_specs,
        discrete_specs=filtered_disc_specs,
    ).to(args.device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)

    # 类别权重
    if hasattr(full_train, 'class_weights'):
        class_weights = full_train.class_weights
    else:
        class_weights = {}

    best_score = -1e9
    best_epoch = -1
    history: List[Dict[str, Any]] = []
    patience_counter = 0

    for epoch in range(1, args.epochs + 1):
        model.train()
        epoch_loss = 0.0
        t0 = time.time()
        for batch in train_loader:
            x = batch['features'].to(args.device)
            # 将所有batch数据移到正确设备
            for key in ['targets_cont', 'targets_disc']:
                if key in batch:
                    for name, tensor in batch[key].items():
                        batch[key][name] = tensor.to(args.device)
            out = model.forward_train(x)
            sample_w = batch['sample_weight'].to(args.device)
            total_loss, metrics = model.compute_loss(batch, out, huber_delta=args.huber_delta, class_weights=class_weights, sample_weight=sample_w)
            optimizer.zero_grad()
            total_loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            epoch_loss += total_loss.item()
        scheduler.step()
        train_time = time.time() - t0

        # 验证
        val_metrics = evaluate(model, val_loader, args.device, args.huber_delta, mc_dropout=args.mc_dropout, mc_times=args.mc_times)
        composite = val_metrics['composite_score']

        history.append({
            'epoch': epoch,
            'train_loss_mean': epoch_loss / max(1, len(train_loader)),
            **val_metrics,
            'lr': scheduler.get_last_lr()[0],
            'time': train_time,
        })

        # 打印摘要
        summary = {k: round(v, 4) for k, v in val_metrics.items() if k.startswith('mae_') or k.startswith('acc_') or k == 'composite_score'}
        print(f"[Epoch {epoch}] train_loss={history[-1]['train_loss_mean']:.4f} score={composite:.4f} metrics={summary}")

        # 早停 & 保存
        if composite > best_score:
            best_score = composite
            best_epoch = epoch
            patience_counter = 0
            save_checkpoint({
                'model_state': model.state_dict(),
                'optimizer_state': optimizer.state_dict(),
                'args': {
                    **vars(args),
                    'enabled_continuous': enabled_continuous,
                    'enabled_discrete': enabled_discrete,
                },
                'epoch': epoch,
                'best_score': best_score,
                'history': history,
            }, os.path.join(args.out_dir, 'best.pt'))
        else:
            patience_counter += 1

        save_checkpoint({
            'model_state': model.state_dict(),
            'optimizer_state': optimizer.state_dict(),
            'args': {
                **vars(args),
                'enabled_continuous': enabled_continuous,
                'enabled_discrete': enabled_discrete,
            },
            'epoch': epoch,
            'best_score': best_score,
            'history': history,
        }, os.path.join(args.out_dir, 'last.pt'))

        if patience_counter >= args.early_patience:
            print(f"[EarlyStop] no improvement for {patience_counter} epochs (best epoch {best_epoch})")
            break

    # 写出训练历史 JSON
    with open(os.path.join(args.out_dir, 'training_history.json'), 'w', encoding='utf-8') as f:
        json.dump(history, f, ensure_ascii=False, indent=2)

    print(f"训练完成. 最佳 epoch={best_epoch}, best_score={best_score:.4f}")

if __name__ == '__main__':
    main()
