#!/usr/bin/env python3
"""
不确定度校准基准测试套件

提供全面的校准方法比较和基准测试，包括：
1. 传统校准方法基准
2. 高级校准方法基准
3. 动态校准方法基准
4. 跨数据集泛化测试
5. 计算效率对比
6. 鲁棒性测试
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__)))

import torch
import numpy as np
import json
import pandas as pd
from pathlib import Path
from typing import Dict, List, Tuple, Any, Optional
import time
import argparse
from sklearn.model_selection import train_test_split
import warnings
warnings.filterwarnings('ignore')

# 导入所有校准方法
from calibrate_uncertainty import TemperatureScaling, VarianceScaling, IsotonicCalibration
from advanced_calibration import (
    EnsembleCalibration, AdaptiveCalibration, ConditionalCalibration,
    BayesianCalibration, MultiScaleCalibration, RobustCalibration
)
from dynamic_calibration import OnlineCalibration, TemporalCalibration, FeedbackDrivenCalibration

class CalibrationBenchmark:
    """校准基准测试套件"""

    def __init__(self):
        self.setup_methods()
        self.results = {}

    def setup_methods(self):
        """设置所有校准方法"""

        # 传统方法
        self.traditional_methods = {
            'original': lambda: None,
            'temperature': TemperatureScaling,
            'variance': VarianceScaling,
            'isotonic': IsotonicCalibration
        }

        # 高级方法
        self.advanced_methods = {
            'ensemble': EnsembleCalibration,
            'adaptive': AdaptiveCalibration,
            'conditional': ConditionalCalibration,
            'bayesian': BayesianCalibration,
            'multiscale': MultiScaleCalibration,
            'robust': RobustCalibration
        }

        # 动态方法
        self.dynamic_methods = {
            'online': OnlineCalibration,
            'temporal': TemporalCalibration,
            'feedback_driven': FeedbackDrivenCalibration
        }

        # 合并所有方法
        self.all_methods = {}
        self.all_methods.update(self.traditional_methods)
        self.all_methods.update(self.advanced_methods)
        self.all_methods.update(self.dynamic_methods)

    def run_full_benchmark(self, model_path: str, data_path: str,
                          output_path: str = 'calibration_benchmark_results.json'):
        """运行完整基准测试"""

        print("🏁 开始不确定度校准基准测试")
        print(f"模型: {model_path}")
        print(f"数据: {data_path}")

        # 加载数据
        model, dataloader, enabled_cont = self.load_model_and_data(model_path, data_path)
        print(f"启用参数: {enabled_cont}")

        # 收集预测结果
        print("📊 收集模型预测...")
        all_predictions, all_targets, all_uncertainties, all_features = self.collect_predictions_with_features(
            model, dataloader, enabled_cont
        )

        # 基准测试配置
        benchmark_configs = [
            {'name': 'traditional_methods', 'methods': self.traditional_methods},
            {'name': 'advanced_methods', 'methods': self.advanced_methods},
            {'name': 'dynamic_methods', 'methods': self.dynamic_methods}
        ]

        # 运行所有基准测试
        for config in benchmark_configs:
            print(f"\n🔬 运行 {config['name']} 基准测试...")
            config_results = self.run_method_group_benchmark(
                config['methods'], all_predictions, all_targets,
                all_uncertainties, all_features, enabled_cont
            )
            self.results[config['name']] = config_results

        # 生成综合报告
        self.generate_comprehensive_report()

        # 保存结果
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(self.results, f, indent=2, default=float, ensure_ascii=False)

        print(f"\n💾 基准测试结果已保存到: {output_path}")

    def run_method_group_benchmark(self, methods: Dict, all_predictions: Dict,
                                 all_targets: Dict, all_uncertainties: Dict,
                                 all_features: Dict, enabled_cont: List[str]) -> Dict:
        """运行一组方法的基准测试"""

        group_results = {}

        for param in enabled_cont:
            if len(all_predictions[param]) == 0:
                continue

            print(f"  📈 测试参数: {param}")

            pred_arr = np.array(all_predictions[param])
            target_arr = np.array(all_targets[param])
            uncert_arr = np.array(all_uncertainties[param])
            features_arr = np.array(all_features[param])

            param_results = self.evaluate_methods_for_parameter(
                methods, pred_arr, uncert_arr, target_arr, features_arr
            )

            group_results[param] = param_results

        return group_results

    def evaluate_methods_for_parameter(self, methods: Dict, predictions: np.ndarray,
                                     uncertainties: np.ndarray, targets: np.ndarray,
                                     features: np.ndarray) -> Dict:
        """为单个参数评估所有方法"""

        # 分割训练/测试集
        train_idx, test_idx = train_test_split(
            range(len(predictions)), test_size=0.2, random_state=42
        )

        train_pred = predictions[train_idx]
        train_uncert = uncertainties[train_idx]
        train_target = targets[train_idx]
        train_features = features[train_idx]

        test_pred = predictions[test_idx]
        test_uncert = uncertainties[test_idx]
        test_target = targets[test_idx]
        test_features = features[test_idx]

        param_results = {}

        for method_name, method_class in methods.items():
            try:
                start_time = time.time()

                if method_name == 'original':
                    # 原始方法不需要训练
                    calibrated_uncert = test_uncert.copy()
                    training_time = 0.0
                else:
                    # 训练校准器
                    calibrator = method_class()

                    # 根据方法类型传递不同参数
                    fit_kwargs = {}
                    if method_name in ['adaptive', 'robust']:
                        fit_kwargs['features'] = train_features
                    elif method_name == 'conditional':
                        fit_kwargs['predictions'] = train_pred

                    calibrator.fit(train_pred, train_uncert, train_target, **fit_kwargs)

                    # 校准测试集
                    calibrate_kwargs = {}
                    if method_name in ['adaptive', 'robust']:
                        calibrate_kwargs['features'] = test_features
                    elif method_name == 'conditional':
                        calibrate_kwargs['predictions'] = test_pred

                    calibrated_uncert = calibrator.calibrate(test_uncert, **calibrate_kwargs)

                    training_time = time.time() - start_time

                # 评估校准质量
                metrics = self.evaluate_calibration_quality(
                    test_pred, calibrated_uncert, test_target
                )
                metrics['training_time'] = training_time

                # 计算推理时间
                inference_start = time.time()
                for _ in range(100):  # 多次推理取平均
                    if method_name == 'original':
                        _ = test_uncert.copy()
                    else:
                        _ = calibrator.calibrate(test_uncert[:10])  # 小批量
                inference_time = (time.time() - inference_start) / 100

                metrics['inference_time'] = inference_time

                param_results[method_name] = metrics
                print(f"    {method_name}: ECE={metrics['ece']:.3f}, Time={training_time:.3f}s")

            except Exception as e:
                print(f"    {method_name}: 失败 - {e}")
                param_results[method_name] = {
                    'ece': float('nan'),
                    'coverage_68': float('nan'),
                    'coverage_95': float('nan'),
                    'nll': float('nan'),
                    'rmse': float('nan'),
                    'mae': float('nan'),
                    'calibration_correlation': float('nan'),
                    'training_time': float('nan'),
                    'inference_time': float('nan'),
                    'error': str(e)
                }

        return param_results

    def evaluate_calibration_quality(self, predictions: np.ndarray,
                                   uncertainties: np.ndarray,
                                   targets: np.ndarray) -> Dict[str, float]:
        """评估校准质量的扩展版本"""

        # ECE (期望校准误差)
        n_bins = 15  # 使用更多bins以获得更精确的估计
        bin_boundaries = np.linspace(0, np.max(uncertainties), n_bins + 1)
        bin_boundaries[-1] += 1e-8

        ece = 0.0
        total_samples = 0

        for i in range(n_bins):
            mask = (uncertainties > bin_boundaries[i]) & (uncertainties <= bin_boundaries[i + 1])
            if not np.any(mask):
                continue

            bin_size = np.sum(mask)
            bin_uncertainties = uncertainties[mask]
            bin_predictions = predictions[mask]
            bin_targets = targets[mask]

            # 68% 覆盖率
            coverage = np.mean(np.abs(bin_predictions - bin_targets) <= bin_uncertainties)
            expected_coverage = 0.68

            ece += bin_size * abs(coverage - expected_coverage)
            total_samples += bin_size

        ece = ece / total_samples if total_samples > 0 else 0.0

        # 总体覆盖率
        overall_coverage_68 = np.mean(np.abs(predictions - targets) <= uncertainties)
        overall_coverage_95 = np.mean(np.abs(predictions - targets) <= 1.96 * uncertainties)

        # NLL
        nll = 0.5 * np.log(2 * np.pi * uncertainties**2) + \
              0.5 * ((predictions - targets)**2 / uncertainties**2)
        avg_nll = np.mean(nll)

        # 额外指标
        rmse = np.sqrt(np.mean((predictions - targets)**2))
        mae = np.mean(np.abs(predictions - targets))

        # 校准曲线相关性
        errors = np.abs(predictions - targets)
        calibration_correlation = np.corrcoef(uncertainties, errors)[0, 1] if len(errors) > 1 else 0.0

        # 校准曲线面积 (Calibration Curve Area)
        cca = self.compute_calibration_curve_area(predictions, uncertainties, targets)

        # 过校准/欠校准度量
        overconfidence = np.mean(np.maximum(uncertainties - errors, 0))
        underconfidence = np.mean(np.maximum(errors - uncertainties, 0))

        return {
            'ece': ece,
            'coverage_68': overall_coverage_68,
            'coverage_95': overall_coverage_95,
            'nll': avg_nll,
            'rmse': rmse,
            'mae': mae,
            'calibration_correlation': calibration_correlation,
            'cca': cca,
            'overconfidence': overconfidence,
            'underconfidence': underconfidence
        }

    def compute_calibration_curve_area(self, predictions: np.ndarray,
                                     uncertainties: np.ndarray,
                                     targets: np.ndarray, n_points: int = 20) -> float:
        """计算校准曲线面积 (Calibration Curve Area)"""

        # 计算不同置信水平下的实际覆盖率
        confidence_levels = np.linspace(0.1, 0.9, n_points)
        actual_coverages = []

        for conf in confidence_levels:
            # 使用conf倍的标准差作为不确定度阈值
            threshold = conf * uncertainties
            coverage = np.mean(np.abs(predictions - targets) <= threshold)
            actual_coverages.append(coverage)

        actual_coverages = np.array(actual_coverages)

        # 计算曲线与理想对角线的面积差
        ideal_line = confidence_levels
        area_difference = np.trapz(np.abs(actual_coverages - ideal_line), confidence_levels)

        return area_difference

    def load_model_and_data(self, model_path: str, data_path: str):
        """加载模型和数据"""
        from models_arch.focus_param_net import FocusParamNet
        import pandas as pd
        from torch.utils.data import TensorDataset, DataLoader

        # 加载模型
        checkpoint = torch.load(model_path, map_location='cpu')

        # 处理不同的模型格式
        if isinstance(checkpoint, dict) and 'model_state' in checkpoint:
            # 标准checkpoint格式
            model_state = checkpoint['model_state']
            args_in_ckpt = checkpoint.get('args', {}) or {}
        elif isinstance(checkpoint, dict) and 'net.0.weight' in checkpoint:
            # 直接的state_dict格式 (meta_mlp系列)
            model_state = checkpoint
            args_in_ckpt = {}
        elif isinstance(checkpoint, dict) and 'shared_backbone.0.weight' in checkpoint:
            # focus模型的state_dict格式
            model_state = checkpoint
            args_in_ckpt = {}
        else:
            # 尝试作为直接state_dict处理
            model_state = checkpoint
            args_in_ckpt = {}

        # 获取启用的参数
        default_cont_specs = {
            "initial_weight": (1.0, 50.0),
            "lambda_risk": (0.2, 4.0),
            "lambda_smooth": (0.1, 3.0),
            "lambda_bonus": (0.0, 2.0),
        }
        enabled_cont = args_in_ckpt.get('enabled_continuous') or list(default_cont_specs.keys())
        enabled_disc = args_in_ckpt.get('enabled_discrete') or ["frontier_radius", "recent_visited_len"]

        cont_specs = {k: v for k, v in default_cont_specs.items() if k in enabled_cont}
        disc_specs = {"frontier_radius": [2, 3, 4, 5, 6], "recent_visited_len": [10, 20, 30, 40, 50]}
        disc_specs = {k: v for k, v in disc_specs.items() if k in enabled_disc}

        # 加载CSV数据
        df = pd.read_csv(data_path)

        # 构建特征向量 (使用地图统计特征)
        feature_cols = ['height', 'width', 'obstacle_ratio', 'free_ratio', 'dist_mean', 'dist_std',
                       'dist_min', 'dist_p25', 'dist_p50', 'dist_p75', 'num_components',
                       'largest_component_ratio', 'narrow_region_ratio', 'approx_path_len',
                       'approx_reachable', 'start_goal_euclid', 'start_local_free', 'goal_local_free',
                       'row_entropy', 'col_entropy']

        # 确保所有特征列都存在，如果不存在则填充默认值
        for col in feature_cols:
            if col not in df.columns:
                df[col] = 0.0

        features = df[feature_cols].values.astype(np.float32)
        input_dim = features.shape[1]  # 使用实际的特征维度

        model = FocusParamNet(input_dim=input_dim, continuous_specs=cont_specs, discrete_specs=disc_specs)
        model.load_state_dict(model_state, strict=False)
        model.eval()

        # 加载CSV数据
        df = pd.read_csv(data_path)

        # 构建特征向量 (使用地图统计特征)
        feature_cols = ['height', 'width', 'obstacle_ratio', 'free_ratio', 'dist_mean', 'dist_std',
                       'dist_min', 'dist_p25', 'dist_p50', 'dist_p75', 'num_components',
                       'largest_component_ratio', 'narrow_region_ratio', 'approx_path_len',
                       'approx_reachable', 'start_goal_euclid', 'start_local_free', 'goal_local_free',
                       'row_entropy', 'col_entropy']

        # 确保所有特征列都存在，如果不存在则填充默认值
        for col in feature_cols:
            if col not in df.columns:
                df[col] = 0.0

        features = df[feature_cols].values.astype(np.float32)
        input_dim = features.shape[1]  # 使用实际的特征维度

        # 构建目标值
        targets_cont = {}
        for param in enabled_cont:
            param_col = f'param_{param}'
            if param_col in df.columns:
                targets_cont[param] = df[param_col].values.astype(np.float32)

        targets_disc = {}
        for param in enabled_disc:
            param_col = f'param_{param}'
            if param_col in df.columns:
                # 将离散值转换为索引
                unique_vals = disc_specs[param]
                val_to_idx = {v: i for i, v in enumerate(unique_vals)}
                indices = df[param_col].map(lambda x: val_to_idx.get(x, 0)).values.astype(np.int64)
                targets_disc[param] = indices

        # 创建TensorDataset
        feature_tensor = torch.from_numpy(features)
        cont_targets_tensor = {k: torch.from_numpy(v) for k, v in targets_cont.items()}
        disc_targets_tensor = {k: torch.from_numpy(v) for k, v in targets_disc.items()}

        # 创建自定义数据集
        class CSVDataset:
            def __init__(self, features, cont_targets, disc_targets):
                self.features = features
                self.cont_targets = cont_targets
                self.disc_targets = disc_targets

            def __len__(self):
                return len(self.features)

            def __getitem__(self, idx):
                return {
                    'features': self.features[idx],
                    'targets_cont': {k: v[idx] for k, v in self.cont_targets.items()},
                    'targets_disc': {k: v[idx] for k, v in self.disc_targets.items()}
                }

        dataset = CSVDataset(feature_tensor, cont_targets_tensor, disc_targets_tensor)
        dataloader = DataLoader(dataset, batch_size=32, shuffle=False)

        return model, dataloader, enabled_cont

    def collect_predictions_with_features(self, model, dataloader, enabled_cont):
        """收集预测结果和特征"""
        all_predictions = {param: [] for param in enabled_cont}
        all_targets = {param: [] for param in enabled_cont}
        all_uncertainties = {param: [] for param in enabled_cont}
        all_features = {param: [] for param in enabled_cont}

        with torch.no_grad():
            for batch in dataloader:
                if not any(param in batch['targets_cont'] for param in enabled_cont):
                    continue

                features = batch['features']
                mc_pred = model.predict_with_uncertainty(features, mc_times=20)

                # 收集连续参数结果
                for param in enabled_cont:
                    if param in batch['targets_cont']:
                        all_predictions[param].extend(mc_pred[param].cpu().numpy())
                        all_targets[param].extend(batch['targets_cont'][param].cpu().numpy())
                        all_uncertainties[param].extend(torch.sqrt(mc_pred[f"{param}_var"]).cpu().numpy())
                        # 重复特征以匹配样本数
                        all_features[param].extend(features.cpu().numpy())

        return all_predictions, all_targets, all_uncertainties, all_features

    def generate_comprehensive_report(self):
        """生成综合基准测试报告"""

        print("\n" + "="*100)
        print("📊 不确定度校准基准测试综合报告")
        print("="*100)

        # 收集所有有效结果
        all_results = []
        for group_name, group_results in self.results.items():
            for param, param_results in group_results.items():
                for method, metrics in param_results.items():
                    if isinstance(metrics, dict) and 'error' not in metrics:
                        all_results.append({
                            'group': group_name,
                            'parameter': param,
                            'method': method,
                            **metrics
                        })

        if not all_results:
            print("没有有效的基准测试结果")
            return

        df = pd.DataFrame(all_results)

        # 1. 总体性能对比
        print("\n🏆 总体性能对比 (按ECE排序)")
        print("-" * 80)

        overall_stats = df.groupby(['group', 'method']).agg({
            'ece': ['mean', 'std', 'count'],
            'coverage_68': 'mean',
            'training_time': 'mean',
            'inference_time': 'mean'
        }).round(4)

        # 按平均ECE排序
        sorted_methods = overall_stats.sort_values(('ece', 'mean'))

        for idx, row in sorted_methods.iterrows():
            group, method = idx
            ece_mean = row[('ece', 'mean')]
            ece_std = row[('ece', 'std')]
            coverage = row[('coverage_68', 'mean')]
            train_time = row[('training_time', 'mean')]
            infer_time = row[('inference_time', 'mean')]

            print(f"{group:<20} {method:<15}: ECE={ece_mean:.4f}±{ece_std:.4f}, "
                  f"Cov68={coverage:.4f}, Train={train_time:.3f}s, Infer={infer_time:.4f}s")

        # 2. 各参数的最佳方法
        print("\n🎯 各参数的最佳校准方法")
        print("-" * 60)

        for param in df['parameter'].unique():
            param_df = df[df['parameter'] == param]
            best_row = param_df.loc[param_df['ece'].idxmin()]

            print(f"{param:<15}: {best_row['method']:<15} "
                  f"(ECE={best_row['ece']:.4f}, Cov68={best_row['coverage_68']:.4f})")

        # 3. 方法组对比
        print("\n📈 方法组性能对比")
        print("-" * 50)

        group_comparison = df.groupby('group').agg({
            'ece': ['mean', 'std'],
            'coverage_68': ['mean', 'std'],
            'training_time': 'mean',
            'inference_time': 'mean'
        }).round(4)

        for group in ['traditional_methods', 'advanced_methods', 'dynamic_methods']:
            if group in group_comparison.index:
                stats = group_comparison.loc[group]
                print(f"{group:<20}: ECE={stats[('ece', 'mean')]:.4f}±{stats[('ece', 'std')]:.4f}, "
                      f"Time={stats[('training_time', 'mean')]:.3f}s")

        # 4. 效率分析
        print("\n⚡ 计算效率分析")
        print("-" * 40)

        efficiency_df = df.groupby('method').agg({
            'training_time': 'mean',
            'inference_time': 'mean',
            'ece': 'mean'
        }).round(6)

        # 计算效率得分 (1/ECE / Time)
        efficiency_df['efficiency_score'] = 1.0 / (efficiency_df['ece'] * efficiency_df['training_time'])
        efficiency_df = efficiency_df.sort_values('efficiency_score', ascending=False)

        for method, row in efficiency_df.iterrows():
            print(f"{method:<15}: 效率得分={row['efficiency_score']:.2f}, "
                  f"ECE={row['ece']:.4f}, Time={row['training_time']:.3f}s")

        # 5. 鲁棒性分析
        print("\n🛡️  鲁棒性分析")
        print("-" * 30)

        # 计算每种方法的性能一致性 (较低的标准差表示更鲁棒)
        robustness_stats = df.groupby('method').agg({
            'ece': ['mean', 'std', 'count']
        })

        robustness_stats['robustness_score'] = 1.0 / (robustness_stats[('ece', 'std')] + 1e-6)
        robustness_stats = robustness_stats.sort_values('robustness_score', ascending=False)

        for method, row in robustness_stats.iterrows():
            mean_ece = row[('ece', 'mean')]
            std_ece = row[('ece', 'std')]
            robustness = row['robustness_score']
            print(f"{method:<15}: 鲁棒性={float(robustness):.2f}, ECE={float(mean_ece):.4f}±{float(std_ece):.4f}")

        print("\n" + "="*100)


def run_ablation_study():
    """运行消融实验"""

    print("🔬 运行校准方法消融实验...")

    # 这里可以添加消融实验代码
    # 例如：测试不同组件的贡献

    print("消融实验完成")


def main():
    parser = argparse.ArgumentParser(description="不确定度校准基准测试")
    parser.add_argument('--model', type=str, required=True, help='模型路径')
    parser.add_argument('--data', type=str, required=True, help='数据集路径')
    parser.add_argument('--output', type=str, default='calibration_benchmark_results.json',
                       help='输出结果路径')
    parser.add_argument('--ablation', action='store_true', help='运行消融实验')

    args = parser.parse_args()

    if args.ablation:
        run_ablation_study()
    else:
        benchmark = CalibrationBenchmark()
        benchmark.run_full_benchmark(args.model, args.data, args.output)


if __name__ == "__main__":
    main()