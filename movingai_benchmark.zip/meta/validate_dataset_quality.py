"""验证扩展数据集的质量"""
import json
import numpy as np
from pathlib import Path
from collections import Counter

def analyze_dataset(jsonl_path: str):
    """分析JSONL数据集的质量和分布"""
    print(f"📊 分析数据集: {jsonl_path}")
    
    # 读取数据
    data = []
    with open(jsonl_path, 'r') as f:
        for line in f:
            data.append(json.loads(line.strip()))
    
    print(f"总样本数: {len(data)}")
    
    # 标签分布
    labels = [d['label'] for d in data]
    label_counts = Counter(labels)
    success_rate = label_counts.get(1, 0) / len(data)
    print(f"成功率: {success_rate:.1%} (成功: {label_counts.get(1, 0)}, 失败: {label_counts.get(0, 0)})")
    
    # 特征分布
    print("\n🔍 特征分布:")
    feature_cols = ['obstacle_density', 'confidence_score', 'start_goal_distance', 'connectivity_ratio']
    for col in feature_cols:
        if col in data[0]:
            values = [d[col] for d in data if d.get(col) is not None]
            if values:
                min_val, max_val, mean_val = min(values), max(values), sum(values)/len(values)
                print(f"{col}: [{min_val:.3f}, {max_val:.3f}] 均值={mean_val:.3f}")
    
    # 参数分布
    print("\n⚙️ 参数分布:")
    param_cols = ['initial_weight', 'lambda_risk', 'lambda_smooth', 'lambda_bonus', 
                  'frontier_radius', 'recent_visited_len']
    for col in param_cols:
        if col in data[0]:
            values = [d[col] for d in data if d.get(col) is not None]
            if values:
                min_val, max_val, mean_val = min(values), max(values), sum(values)/len(values)
                print(f"{col}: [{min_val:.2f}, {max_val:.2f}] 均值={mean_val:.2f}")
    
    # 难度分布
    if 'difficulty_tag' in data[0]:
        print("\n📈 难度标签分布:")
        difficulty_tags = [d['difficulty_tag'] for d in data]
        difficulty_counts = Counter(difficulty_tags)
        for tag, count in difficulty_counts.most_common():
            print(f"  {tag}: {count} ({count/len(data):.1%})")
    
    # 检查数据完整性
    print("\n✅ 数据完整性检查:")
    required_cols = ['label', 'obstacle_density', 'confidence_score', 'initial_weight', 'lambda_risk']
    missing_issues = []
    for col in required_cols:
        missing_count = sum(1 for d in data if d.get(col) is None)
        if missing_count > 0:
            missing_issues.append(f"  {col}: {missing_count} ({missing_count/len(data):.1%})")
    
    if missing_issues:
        print("缺失值列:")
        for issue in missing_issues:
            print(issue)
    else:
        print("所有必需列无缺失值 ✓")
    
    # 参数合理性检查
    print("\n🔧 参数合理性检查:")
    param_ranges = {
        'initial_weight': (8.0, 50.0),
        'lambda_risk': (0.2, 4.0),
        'lambda_smooth': (0.1, 3.0),
        'lambda_bonus': (0.0, 2.0),
        'frontier_radius': (2, 6),
        'recent_visited_len': (10, 60),
    }
    
    for param, (min_range, max_range) in param_ranges.items():
        if param in data[0]:
            values = [d[param] for d in data if d.get(param) is not None]
            out_of_range = sum(1 for v in values if v < min_range or v > max_range)
            if out_of_range > 0:
                print(f"  {param}: {out_of_range} 样本超出合理范围 [{min_range}, {max_range}]")
            else:
                print(f"  {param}: 全部在合理范围内 ✓")
    
    return data

def compare_datasets(old_path: str, new_path: str):
    """比较新旧数据集"""
    print(f"\n🔄 数据集对比:")
    
    old_df = analyze_dataset(old_path)
    print("\n" + "="*50)
    new_df = analyze_dataset(new_path)
    
    print(f"\n📊 对比总结:")
    print(f"样本数量: {len(old_df)} → {len(new_df)} (增加 {len(new_df) - len(old_df)})")
    
    old_success = (old_df['label'] == 1).mean()
    new_success = (new_df['label'] == 1).mean()
    print(f"成功率: {old_success:.1%} → {new_success:.1%}")

if __name__ == "__main__":
    # 验证新数据集
    new_dataset = "data_v2/focused_training_dataset_v3.jsonl"
    old_dataset = "data_v2/focused_training_dataset_v2.jsonl"
    
    if Path(new_dataset).exists():
        analyze_dataset(new_dataset)
        
        if Path(old_dataset).exists():
            compare_datasets(old_dataset, new_dataset)
    else:
        print(f"数据集文件不存在: {new_dataset}")