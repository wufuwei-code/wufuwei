"""map_features.py
提取地图统计与结构特征，用于元策略（meta controller）输入。
后续可扩展：
- 图社区检测特征
- 关键瓶颈识别
- GNN embedding 预留接口
"""
from __future__ import annotations
import numpy as np
from scipy.ndimage import distance_transform_edt, label
from typing import Dict, Any

# ---- 核心特征提取 ----

def extract_map_features(map_grid: np.ndarray, start: tuple[int,int], goal: tuple[int,int]) -> Dict[str, float]:
    """返回一个包含多种统计指标的字典。
    约定: 障碍=1, 可通行=0
    """
    g = map_grid
    h, w = g.shape
    total = h * w
    obstacle_ratio = float(np.sum(g==1)) / total
    free_ratio = 1.0 - obstacle_ratio

    # 距离场（对可通行区域计算到障碍的距离）
    # 先对障碍取反 (障碍=1 -> True)，我们要 distance to obstacle => 用障碍mask 本身即可
    obstacle_mask = (g==1)
    dist_to_obstacle = distance_transform_edt(~obstacle_mask)
    # 统计可通行区的距离分布
    free_cells = dist_to_obstacle[g==0]
    if free_cells.size == 0:
        free_cells = np.array([0.0])

    dist_mean = float(np.mean(free_cells))
    dist_std  = float(np.std(free_cells))
    dist_min  = float(np.min(free_cells))
    dist_p25  = float(np.percentile(free_cells, 25))
    dist_p50  = float(np.percentile(free_cells, 50))
    dist_p75  = float(np.percentile(free_cells, 75))

    # 计算连通区域数量（在可通行区域中）
    labeled, num_components = label(g==0)

    # 计算与起终点相关的特征
    start_goal_euclid = float(np.linalg.norm(np.array(start) - np.array(goal)))

    # BFS 近似最短可行路径长度（若断开则为 -1）
    approx_path_len, reachable = _approx_shortest_path_length(g, start, goal)

    # 可通行区是否分块严重：最大连通块占比
    largest_component_ratio = 0.0
    if num_components > 0:
        sizes = [(labeled==i).sum() for i in range(1, num_components+1)]
        largest_component_ratio = float(np.max(sizes)) / float(np.sum(g==0)) if np.sum(g==0)>0 else 0.0

    # 瓶颈度估计：自由区距离场较小的像素占比（例如距离<=1 的比例）
    narrow_region_ratio = float(np.mean((free_cells<=1.01)))

    # 起终点附近局部可行性 (3x3 可通行比例)
    def local_free_ratio(pt):
        r,c = pt
        r0,r1 = max(0,r-1), min(h, r+2)
        c0,c1 = max(0,c-1), min(w, c+2)
        block = g[r0:r1, c0:c1]
        return float(np.mean(block==0))
    start_local_free = local_free_ratio(start)
    goal_local_free  = local_free_ratio(goal)

    # 估算障碍分布熵（按行/列投影）
    row_density = np.mean(g==1, axis=1)
    col_density = np.mean(g==1, axis=0)
    def _entropy(p):
        p = p + 1e-9
        p = p/np.sum(p)
        return float(-np.sum(p*np.log(p)))
    row_entropy = _entropy(row_density)
    col_entropy = _entropy(col_density)

    features = {
        'height': h,
        'width': w,
        'obstacle_ratio': obstacle_ratio,
        'free_ratio': free_ratio,
        'dist_mean': dist_mean,
        'dist_std': dist_std,
        'dist_min': dist_min,
        'dist_p25': dist_p25,
        'dist_p50': dist_p50,
        'dist_p75': dist_p75,
        'num_components': float(num_components),
        'largest_component_ratio': largest_component_ratio,
        'narrow_region_ratio': narrow_region_ratio,
        'approx_path_len': float(approx_path_len),
        'approx_reachable': 1.0 if reachable else 0.0,
        'start_goal_euclid': start_goal_euclid,
        'start_local_free': start_local_free,
        'goal_local_free': goal_local_free,
        'row_entropy': row_entropy,
        'col_entropy': col_entropy,
    }
    return features


def features_to_vector(feat: Dict[str,float]) -> np.ndarray:
    """将特征字典（按固定顺序）转换为 numpy 向量，供网络输入。"""
    keys = [
        'height','width','obstacle_ratio','free_ratio','dist_mean','dist_std','dist_min',
        'dist_p25','dist_p50','dist_p75','num_components','largest_component_ratio',
        'narrow_region_ratio','approx_path_len','approx_reachable','start_goal_euclid',
        'start_local_free','goal_local_free','row_entropy','col_entropy'
    ]
    return np.array([feat[k] for k in keys], dtype=np.float32)


def _approx_shortest_path_length(g: np.ndarray, start, goal):
    """简单 BFS 估算最短路径长度，避免频繁完整 A*。"""
    if g[start]==1 or g[goal]==1:
        return -1, False
    from collections import deque
    h,w = g.shape
    q = deque([(start[0], start[1], 0)])
    visited = set([start])
    dirs = [(-1,0),(1,0),(0,-1),(0,1)]  # 4邻域，粗估
    while q:
        r,c,d = q.popleft()
        if (r,c)==goal:
            return d, True
        for dr,dc in dirs:
            nr,nc = r+dr,c+dc
            if 0<=nr<h and 0<=nc<w and g[nr,nc]==0 and (nr,nc) not in visited:
                visited.add((nr,nc))
                q.append((nr,nc,d+1))
    return -1, False

if __name__ == "__main__":
    # 简单自测
    grid = np.zeros((10,10))
    grid[3:7,5] = 1
    feats = extract_map_features(grid,(0,0),(9,9))
    vec = features_to_vector(feats)
    print("features:", feats)
    print("vector shape:", vec.shape)
