"""
Large Scale Data Collection for Focus Learning
大规模数据采集策略 - 为Focus Learning提供1000+样本训练数据
"""
import os
import csv
import numpy as np
import time
from typing import List, Dict, Tuple
from pathlib import Path
import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
import multiprocessing

# 确保导入路径
import sys
sys.path.append('.')

def generate_diverse_map_configs(num_configs: int = 1000) -> List[Dict]:
    """生成多样化的地图配置"""
    configs = []
    np.random.seed(2024)
    
    for i in range(num_configs):
        # 多样化的地图大小分布
        size_dist = np.random.choice(['small', 'medium', 'large'], p=[0.3, 0.5, 0.2])
        if size_dist == 'small':
            size = np.random.randint(12, 18)
        elif size_dist == 'medium':
            size = np.random.randint(18, 25)
        else:  # large
            size = np.random.randint(25, 32)
        
        # 障碍率分布：倾向于中等复杂度，但包含简单和困难场景
        complexity_dist = np.random.choice(['easy', 'medium', 'hard'], p=[0.2, 0.6, 0.2])
        if complexity_dist == 'easy':
            obs_rate = np.random.uniform(0.10, 0.20)
        elif complexity_dist == 'medium':
            obs_rate = np.random.uniform(0.20, 0.35)
        else:  # hard
            obs_rate = np.random.uniform(0.35, 0.45)
        
        configs.append({
            'map_id': i,
            'size': size,
            'obstacle_ratio': obs_rate,
            'seed': 2024 + i,
            'complexity': complexity_dist
        })
    
    return configs

def collect_single_map_data(config: Dict) -> Dict:
    """采集单张地图的数据（用于多进程）"""
    try:
        from utils.map_generator import generate_random_map
        from meta.collect_meta_dataset import collect_map_data
        
        # 生成地图
        grid, start, goal = generate_random_map(config['size'], config['obstacle_ratio'])
        
        # 采集数据
        data = collect_map_data(grid, start, goal, verbose=False)
        
        if data:
            data['map_id'] = config['map_id']
            data['map_size'] = config['size']
            data['map_complexity'] = config['complexity']
            return data
        else:
            return None
            
    except Exception as e:
        print(f"Error processing map {config['map_id']}: {e}")
        return None

def collect_large_dataset(
    output_path: str = 'meta/dataset/meta_params_large_dataset.csv',
    num_samples: int = 1000,
    max_workers: int = None,
    batch_size: int = 100
) -> None:
    """大规模数据采集主函数"""
    
    print(f"🚀 开始大规模数据采集: {num_samples} 样本")
    print(f"输出文件: {output_path}")
    
    # 确保输出目录存在
    output_dir = Path(output_path).parent
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # 生成多样化配置
    configs = generate_diverse_map_configs(num_samples)
    print(f"生成配置: {len(configs)} 个地图")
    
    # 统计配置分布
    size_dist = {}
    complexity_dist = {}
    for config in configs:
        size_range = f"{config['size']//5*5}-{config['size']//5*5+4}"
        size_dist[size_range] = size_dist.get(size_range, 0) + 1
        complexity_dist[config['complexity']] = complexity_dist.get(config['complexity'], 0) + 1
    
    print(f"地图大小分布: {size_dist}")
    print(f"复杂度分布: {complexity_dist}")
    
    # 设置多进程参数
    if max_workers is None:
        max_workers = max(1, multiprocessing.cpu_count() - 1)
    print(f"使用 {max_workers} 个进程")
    
    # 初始化CSV文件
    csv_header = None
    collected_count = 0
    
    # 分批处理以节省内存
    for batch_start in range(0, len(configs), batch_size):
        batch_end = min(batch_start + batch_size, len(configs))
        batch_configs = configs[batch_start:batch_end]
        
        print(f"\n处理批次 {batch_start//batch_size + 1}/{(len(configs)-1)//batch_size + 1}: 样本 {batch_start+1}-{batch_end}")
        
        batch_data = []
        
        # 多进程采集当前批次
        with ProcessPoolExecutor(max_workers=max_workers) as executor:
            # 提交任务
            future_to_config = {
                executor.submit(collect_single_map_data, config): config 
                for config in batch_configs
            }
            
            # 收集结果
            for future in as_completed(future_to_config):
                config = future_to_config[future]
                try:
                    result = future.result()
                    if result:
                        batch_data.append(result)
                        print(f"✓ Map {config['map_id']}", end=" ")
                    else:
                        print(f"✗ Map {config['map_id']}", end=" ")
                except Exception as e:
                    print(f"✗ Map {config['map_id']} Error: {e}", end=" ")
                
                # 每20个样本换行
                if (len(batch_data) + 1) % 20 == 0:
                    print()
        
        print(f"\n批次完成: {len(batch_data)}/{len(batch_configs)} 样本成功")
        
        # 写入CSV文件
        if batch_data:
            mode = 'w' if csv_header is None else 'a'
            write_header = csv_header is None
            
            with open(output_path, mode, newline='') as f:
                if write_header:
                    csv_header = list(batch_data[0].keys())
                    writer = csv.DictWriter(f, fieldnames=csv_header)
                    writer.writeheader()
                else:
                    writer = csv.DictWriter(f, fieldnames=csv_header)
                
                writer.writerows(batch_data)
            
            collected_count += len(batch_data)
            print(f"已保存 {collected_count} 个样本到 {output_path}")
    
    print(f"\n🎉 大规模数据采集完成!")
    print(f"总计采集: {collected_count}/{num_samples} 样本")
    print(f"成功率: {collected_count/num_samples*100:.1f}%")
    print(f"数据文件: {output_path}")

def analyze_dataset_statistics(dataset_path: str):
    """分析数据集统计信息"""
    import pandas as pd
    
    try:
        df = pd.read_csv(dataset_path)
        print(f"\n📊 数据集统计分析: {dataset_path}")
        print(f"总样本数: {len(df)}")
        
        if 'map_complexity' in df.columns:
            print(f"复杂度分布: {df['map_complexity'].value_counts().to_dict()}")
        
        if 'map_size' in df.columns:
            print(f"地图大小: 最小{df['map_size'].min()}, 最大{df['map_size'].max()}, 平均{df['map_size'].mean():.1f}")
        
        # 分析参数范围
        param_cols = [col for col in df.columns if col.startswith('param_')]
        if param_cols:
            print(f"参数统计:")
            for param in param_cols[:4]:  # 显示前4个参数
                values = df[param].dropna()
                print(f"  {param}: 范围[{values.min():.2f}, {values.max():.2f}], 均值{values.mean():.2f}")
    
    except Exception as e:
        print(f"分析数据集失败: {e}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--samples', type=int, default=1200, help='采集样本数量')
    parser.add_argument('--output', default='meta/dataset/meta_params_large_dataset.csv', help='输出文件路径')
    parser.add_argument('--workers', type=int, default=None, help='并行进程数')
    parser.add_argument('--batch-size', type=int, default=100, help='批处理大小')
    parser.add_argument('--analyze-only', action='store_true', help='仅分析现有数据集')
    
    args = parser.parse_args()
    
    if args.analyze_only:
        analyze_dataset_statistics(args.output)
    else:
        start_time = time.time()
        collect_large_dataset(args.output, args.samples, args.workers, args.batch_size)
        end_time = time.time()
        print(f"总耗时: {(end_time - start_time)/60:.1f} 分钟")
        
        # 分析结果
        analyze_dataset_statistics(args.output)