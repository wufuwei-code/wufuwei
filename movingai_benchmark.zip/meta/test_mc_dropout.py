"""测试训练好的FocusParamNet模型的MC Dropout不确定度估计"""
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__)))

import torch
import numpy as np
from models_arch.focus_param_net import FocusParamNet
from models_arch.focus_dataset import FocusParamDataset

def test_mc_dropout():
    # 加载训练好的模型
    model_path = "models/focus_param_v3/best.pt"
    if not os.path.exists(model_path):
        print(f"模型文件不存在: {model_path}")
        return
    
    # 构建模型
    model = FocusParamNet(input_dim=4)
    checkpoint = torch.load(model_path, map_location='cpu')
    model.load_state_dict(checkpoint['model_state'])
    
    # 准备测试数据 - 使用固定特征
    test_features = torch.tensor([
        [0.3, 0.8, 0.6, 0.5],  # 高obstacle_density, 高confidence_score
        [0.1, 0.2, 0.3, 0.9],  # 低obstacle_density, 低confidence_score
    ], dtype=torch.float32)
    
    print("=== MC Dropout 不确定度估计测试 ===")
    print(f"测试数据形状: {test_features.shape}")
    
    # 标准预测
    model.eval()
    with torch.no_grad():
        standard_pred = model.forward(test_features)
    
    print("\n--- 标准预测 (eval模式) ---")
    for i, (key, val) in enumerate(standard_pred.items()):
        print(f"{key}: {val.numpy()}")
    
    # MC Dropout预测
    mc_pred = model.predict_with_uncertainty(test_features, mc_times=10)
    
    print("\n--- MC Dropout预测 (10次采样) ---")
    for key, val in mc_pred.items():
        if '_var' in key:
            print(f"{key}: {val.numpy()}")
        elif '_all' not in key:
            print(f"{key}: {val.numpy()}")
    
    # 比较不确定度
    print("\n--- 不确定度分析 ---")
    for param in ['initial_weight', 'lambda_risk', 'lambda_smooth', 'lambda_bonus', 'frontier_radius', 'recent_visited_len']:
        if param in mc_pred and f"{param}_var" in mc_pred:
            mean_vals = mc_pred[param].numpy()
            var_vals = mc_pred[f"{param}_var"].numpy()
            std_vals = np.sqrt(var_vals)
            print(f"{param}:")
            print(f"  样本1: {mean_vals[0]:.3f} ± {std_vals[0]:.3f}")
            print(f"  样本2: {mean_vals[1]:.3f} ± {std_vals[1]:.3f}")

if __name__ == "__main__":
    test_mc_dropout()