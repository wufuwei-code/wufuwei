# Model Prediction Summary

This report summarizes the model prediction performance (direct mode) on the evaluation dataset.

## Numeric Summary

| param | mae | mse |
| --- | --- | --- |
| initial_weight | 9.496794700622559 | 117.47109985351562 |
| lambda_risk | 0.6512396335601807 | 0.614976167678833 |
| lambda_smooth | 0.5074888467788696 | 0.34173572063446045 |
| lambda_bonus | 0.4774699807167053 | 0.32155629992485046 |
| frontier_radius | 2.159574508666992 | 5.606382846832275 |
| recent_visited_len | 24.569149017333984 | 904.2286987304688 |
| curvature_window | 1.148936152458191 | 1.8191488981246948 |
| risk_power | 0.2523215115070343 | 0.09527681022882462 |


## Figures

- Scatter plots (true vs pred) for each parameter: `meta/figs/direct_scatter_{param}.pdf` / `.png`
- MAE bar chart: `meta/figs/direct_mae_bar_hr.pdf` / `.png`
- Feature-Parameter Pearson correlation heatmap: `meta/figs/feat_param_corr_direct_hr.pdf` / `.png`

## Parameter meanings

- **initial_weight**: see code `meta/meta_controller.py` for detailed description.
- **lambda_risk**: see code `meta/meta_controller.py` for detailed description.
- **lambda_smooth**: see code `meta/meta_controller.py` for detailed description.
- **lambda_bonus**: see code `meta/meta_controller.py` for detailed description.
- **frontier_radius**: see code `meta/meta_controller.py` for detailed description.
- **recent_visited_len**: see code `meta/meta_controller.py` for detailed description.
- **curvature_window**: see code `meta/meta_controller.py` for detailed description.
- **risk_power**: see code `meta/meta_controller.py` for detailed description.

## Notes

- MAE and MSE computed over the available dataset (failures removed).
- Scatter plots include Pearson r and $R^2$ annotations when defined.
