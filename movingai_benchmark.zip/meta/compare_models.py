"""对比新旧模型的性能"""
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__)))

import torch
import json
from models_arch.focus_param_net import FocusParamNet

def compare_models():
    print("🔄 模型性能对比分析")
    
    # 模型路径
    old_model_path = "models/focus_param/best.pt"
    new_model_path = "models/focus_param_v3/best.pt"
    
    # 检查文件存在性
    if not os.path.exists(old_model_path):
        print(f"旧模型不存在: {old_model_path}")
        return
    if not os.path.exists(new_model_path):
        print(f"新模型不存在: {new_model_path}")
        return
    
    # 加载模型
    def load_model(path):
        model = FocusParamNet(input_dim=4)
        checkpoint = torch.load(path, map_location='cpu')
        model.load_state_dict(checkpoint['model_state'])
        return model, checkpoint
    
    old_model, old_checkpoint = load_model(old_model_path)
    new_model, new_checkpoint = load_model(new_model_path)
    
    print("\n📊 训练历史对比:")
    print(f"旧模型 - 最佳得分: {old_checkpoint.get('best_score', 'N/A')}")
    print(f"新模型 - 最佳得分: {new_checkpoint.get('best_score', 'N/A')}")
    
    # 测试数据
    test_features = torch.tensor([
        [0.3, 0.8, 0.6, 0.5],  # 高障碍密度
        [0.1, 0.2, 0.3, 0.9],  # 低障碍密度  
        [0.4, 0.6, 0.7, 0.4],  # 中等难度
        [0.2, 0.9, 0.2, 0.8],  # 高连通性
    ], dtype=torch.float32)
    
    print(f"\n🧪 测试样本预测对比 (4个样本):")
    
    # 标准预测对比
    old_model.eval()
    new_model.eval()
    
    with torch.no_grad():
        old_pred = old_model.forward(test_features)
        new_pred = new_model.forward(test_features)
    
    print("\n--- 连续参数预测对比 ---")
    continuous_params = ['initial_weight', 'lambda_risk', 'lambda_smooth', 'lambda_bonus']
    for param in continuous_params:
        print(f"\n{param}:")
        old_vals = old_pred[param].numpy()
        new_vals = new_pred[param].numpy()
        for i in range(len(test_features)):
            diff = abs(new_vals[i] - old_vals[i])
            print(f"  样本{i+1}: {old_vals[i]:.3f} → {new_vals[i]:.3f} (差异: {diff:.3f})")
    
    print("\n--- 离散参数预测对比 ---")
    discrete_params = ['frontier_radius', 'recent_visited_len']
    for param in discrete_params:
        print(f"\n{param}:")
        old_vals = old_pred[param].numpy()
        new_vals = new_pred[param].numpy()
        for i in range(len(test_features)):
            match = "✓" if old_vals[i] == new_vals[i] else "✗"
            print(f"  样本{i+1}: {old_vals[i]} → {new_vals[i]} {match}")
    
    # MC Dropout不确定度对比
    print("\n--- 不确定度估计对比 (MC Dropout) ---")
    old_mc = old_model.predict_with_uncertainty(test_features, mc_times=8)
    new_mc = new_model.predict_with_uncertainty(test_features, mc_times=8)
    
    for param in continuous_params:
        print(f"\n{param} 不确定度:")
        old_std = torch.sqrt(old_mc[f"{param}_var"]).numpy()
        new_std = torch.sqrt(new_mc[f"{param}_var"]).numpy()
        for i in range(len(test_features)):
            uncertainty_change = new_std[i] - old_std[i]
            trend = "↓" if uncertainty_change < 0 else "↑" if uncertainty_change > 0 else "="
            print(f"  样本{i+1}: {old_std[i]:.3f} → {new_std[i]:.3f} {trend}")
    
    # 数据集规模对比
    print(f"\n📈 数据集规模对比:")
    
    # 读取训练历史
    old_history_path = "models/focus_param/training_history.json"
    new_history_path = "models/focus_param_v3/training_history.json"
    
    if os.path.exists(old_history_path):
        with open(old_history_path, 'r') as f:
            old_history = json.load(f)
        print(f"旧模型训练轮数: {len(old_history.get('train_loss', []))}")
    
    if os.path.exists(new_history_path):
        with open(new_history_path, 'r') as f:
            new_history = json.load(f)
        print(f"新模型训练轮数: {len(new_history.get('train_loss', []))}")
        
        # 最终损失对比
        if old_history and new_history:
            old_final_loss = old_history['train_loss'][-1] if old_history['train_loss'] else None
            new_final_loss = new_history['train_loss'][-1] if new_history['train_loss'] else None
            if old_final_loss and new_final_loss:
                improvement = old_final_loss - new_final_loss
                print(f"训练损失改善: {old_final_loss:.4f} → {new_final_loss:.4f} (改善: {improvement:.4f})")
    
    print(f"\n✅ 对比分析完成")

if __name__ == "__main__":
    compare_models()