#!/usr/bin/env python3
"""
校准方法比较脚本

综合比较不同校准方法的效果，包括：
1. 原始模型（无校准）
2. 温度缩放
3. 方差缩放  
4. 等温回归
5. 深度校准网络

生成详细的对比报告和建议
"""

import json
import numpy as np
import pandas as pd
from pathlib import Path
import argparse

def load_calibration_results(results_path: str) -> dict:
    """加载校准结果"""
    if not Path(results_path).exists():
        return {}
    
    with open(results_path, 'r') as f:
        return json.load(f)

def load_deep_calibration_results(results_path: str) -> dict:
    """加载深度校准结果"""
    if not Path(results_path).exists():
        return {}
    
    with open(results_path, 'r') as f:
        data = json.load(f)
    
    # 重新组织格式以匹配其他方法
    reformatted = {}
    for param, param_data in data.items():
        if 'deep_calibration' in param_data:
            reformatted[param] = {
                'deep': param_data['deep_calibration']
            }
    
    return reformatted

def create_comparison_table(calibration_results: dict, deep_results: dict) -> pd.DataFrame:
    """创建校准方法比较表"""
    
    rows = []
    
    for param in calibration_results.keys():
        param_results = calibration_results[param]
        deep_param_results = deep_results.get(param, {})
        
        # 提取各方法的结果
        methods = ['original', 'temperature', 'variance', 'isotonic']
        if 'deep' in deep_param_results:
            methods.append('deep')
        
        for method in methods:
            if method == 'deep':
                if method in deep_param_results:
                    data = deep_param_results[method]
                else:
                    continue
            else:
                if method in param_results:
                    data = param_results[method]
                else:
                    continue
            
            row = {
                'parameter': param,
                'method': method,
                'ece': data.get('ece', np.nan),
                'coverage_68': data.get('coverage_68', np.nan),
                'coverage_95': data.get('coverage_95', np.nan),
                'nll': data.get('nll', np.nan)
            }
            rows.append(row)
    
    return pd.DataFrame(rows)

def analyze_calibration_improvements(df: pd.DataFrame) -> dict:
    """分析校准改进效果"""
    
    analysis = {
        'best_methods': {},
        'improvements': {},
        'summary': {}
    }
    
    parameters = df['parameter'].unique()
    
    for param in parameters:
        param_df = df[df['parameter'] == param].copy()
        
        if param_df.empty:
            continue
        
        # 找到原始性能
        original_row = param_df[param_df['method'] == 'original']
        if original_row.empty:
            continue
        
        original_ece = original_row['ece'].iloc[0]
        original_coverage = original_row['coverage_68'].iloc[0]
        
        # 找到最佳方法
        calibration_methods = param_df[param_df['method'] != 'original']
        
        if not calibration_methods.empty:
            # 按ECE排序（越小越好）
            best_ece_method = calibration_methods.loc[calibration_methods['ece'].idxmin()]
            
            # 按覆盖率接近68%排序
            calibration_methods['coverage_error'] = np.abs(calibration_methods['coverage_68'] - 0.68)
            best_coverage_method = calibration_methods.loc[calibration_methods['coverage_error'].idxmin()]
            
            analysis['best_methods'][param] = {
                'best_ece': {
                    'method': best_ece_method['method'],
                    'ece': best_ece_method['ece'],
                    'coverage_68': best_ece_method['coverage_68']
                },
                'best_coverage': {
                    'method': best_coverage_method['method'],
                    'ece': best_coverage_method['ece'],
                    'coverage_68': best_coverage_method['coverage_68']
                }
            }
            
            # 计算改进幅度
            ece_improvement = (original_ece - best_ece_method['ece']) / original_ece * 100
            coverage_improvement = abs(best_coverage_method['coverage_68'] - 0.68) - abs(original_coverage - 0.68)
            
            analysis['improvements'][param] = {
                'ece_improvement_percent': ece_improvement,
                'coverage_improvement': coverage_improvement,
                'original_ece': original_ece,
                'original_coverage': original_coverage
            }
    
    # 总体统计
    all_improvements = [v['ece_improvement_percent'] for v in analysis['improvements'].values()]
    all_coverage_improvements = [v['coverage_improvement'] for v in analysis['improvements'].values()]
    
    analysis['summary'] = {
        'avg_ece_improvement': np.mean(all_improvements) if all_improvements else 0,
        'max_ece_improvement': np.max(all_improvements) if all_improvements else 0,
        'avg_coverage_improvement': np.mean(all_coverage_improvements) if all_coverage_improvements else 0,
        'parameters_improved': len([x for x in all_improvements if x > 0])
    }
    
    return analysis

def generate_recommendations(analysis: dict, df: pd.DataFrame) -> list:
    """生成校准建议"""
    
    recommendations = []
    
    # 总体建议
    summary = analysis['summary']
    if summary['avg_ece_improvement'] > 10:
        recommendations.append(
            f"🎉 校准效果显著：平均ECE改进 {summary['avg_ece_improvement']:.1f}%，"
            f"推荐在生产环境中使用校准技术。"
        )
    elif summary['avg_ece_improvement'] > 0:
        recommendations.append(
            f"✅ 校准有效：平均ECE改进 {summary['avg_ece_improvement']:.1f}%，"
            f"建议根据具体需求选择合适的校准方法。"
        )
    else:
        recommendations.append(
            "⚠️ 校准效果有限，可能需要重新审视模型架构或训练策略。"
        )
    
    # 方法特定建议
    method_counts = df.groupby('method').size()
    method_performance = df.groupby('method')['ece'].mean()
    
    best_method = method_performance.idxmin()
    if best_method != 'original':
        avg_ece = method_performance[best_method]
        recommendations.append(
            f"🏆 推荐方法：{best_method}，平均ECE = {avg_ece:.3f}"
        )
    
    # 参数特定建议
    for param, param_analysis in analysis['best_methods'].items():
        best_ece_method = param_analysis['best_ece']['method']
        ece_value = param_analysis['best_ece']['ece']
        coverage_value = param_analysis['best_ece']['coverage_68']
        
        if ece_value < 0.3:
            status = "✅ 良好"
        elif ece_value < 0.5:
            status = "⚠️ 可接受"
        else:
            status = "❌ 需改进"
        
        recommendations.append(
            f"{param}: 最佳方法为 {best_ece_method} "
            f"(ECE={ece_value:.3f}, Coverage={coverage_value:.3f}) {status}"
        )
    
    return recommendations

def main():
    parser = argparse.ArgumentParser(description="校准方法比较分析")
    parser.add_argument('--calibration-results', type=str, default='calibration_results.json',
                       help='基础校准结果文件')
    parser.add_argument('--deep-results', type=str, default='deep_calibration_results.json',
                       help='深度校准结果文件')
    parser.add_argument('--output', type=str, default='calibration_comparison.json',
                       help='输出比较结果文件')
    
    args = parser.parse_args()
    
    print("📊 开始校准方法比较分析")
    
    # 加载结果
    calibration_results = load_calibration_results(args.calibration_results)
    deep_results = load_deep_calibration_results(args.deep_results)
    
    if not calibration_results and not deep_results:
        print("❌ 未找到任何校准结果文件")
        return
    
    # 创建比较表
    df = create_comparison_table(calibration_results, deep_results)
    
    if df.empty:
        print("❌ 没有可比较的数据")
        return
    
    print(f"📋 比较表格:")
    print(df.to_string(index=False, float_format='%.3f'))
    
    # 分析改进效果
    analysis = analyze_calibration_improvements(df)
    
    # 生成建议
    recommendations = generate_recommendations(analysis, df)
    
    # 创建完整报告
    report = {
        'comparison_table': df.to_dict('records'),
        'analysis': analysis,
        'recommendations': recommendations,
        'summary_statistics': {
            'total_parameters': len(df['parameter'].unique()),
            'total_methods': len(df['method'].unique()),
            'avg_original_ece': df[df['method'] == 'original']['ece'].mean() if 'original' in df['method'].values else None,
            'best_overall_ece': df[df['method'] != 'original']['ece'].min() if len(df[df['method'] != 'original']) > 0 else None
        }
    }
    
    # 保存报告
    with open(args.output, 'w') as f:
        json.dump(report, f, indent=2, default=float)
    
    print(f"\n💾 比较分析报告已保存到: {args.output}")
    
    # 打印建议
    print(f"\n🎯 校准建议:")
    for i, rec in enumerate(recommendations, 1):
        print(f"{i}. {rec}")
    
    # 打印关键统计
    print(f"\n📈 关键统计:")
    stats = report['summary_statistics']
    if stats['avg_original_ece']:
        print(f"原始平均ECE: {stats['avg_original_ece']:.3f}")
    if stats['best_overall_ece']:
        print(f"最佳校准ECE: {stats['best_overall_ece']:.3f}")
        if stats['avg_original_ece']:
            improvement = (stats['avg_original_ece'] - stats['best_overall_ece']) / stats['avg_original_ece'] * 100
            print(f"相对改进: {improvement:.1f}%")

if __name__ == "__main__":
    main()