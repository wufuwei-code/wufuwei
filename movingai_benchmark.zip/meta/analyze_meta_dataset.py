"""analyze_meta_dataset.py
对采集的 meta 数据集进行诊断：
1. 各参数残差 (param - rule) 分布统计：均值/标准差/相对范围百分比
2. 特征与残差皮尔逊相关系数（可选）
用法：
python -m meta.analyze_meta_dataset --data meta/dataset/meta_params_dataset.csv --corr
"""
from __future__ import annotations
import argparse
import csv
import numpy as np
from typing import Dict, List
from meta.meta_controller import PARAM_BOUNDS, FEATURE_ORDER


def load_rows(path: str):
    rows = []
    with open(path,'r') as f:
        reader = csv.DictReader(f)
        for line in reader:
            if line.get('metric_success','1') in ['0','False','false']:
                continue
            ok = True
            rec = {}
            for p in PARAM_BOUNDS.keys():
                pk = 'param_'+p
                rk = 'rule_'+p
                if pk not in line or rk not in line:
                    ok = False; break
                try:
                    rec[pk] = float(line[pk]); rec[rk] = float(line[rk])
                except:
                    ok = False; break
            if not ok:
                continue
            feats = []
            for k in FEATURE_ORDER:
                if k not in line:
                    ok=False; break
                feats.append(float(line[k]))
            if not ok:
                continue
            rec['features'] = np.array(feats, dtype=np.float32)
            rows.append(rec)
    return rows


def residual_stats(rows):
    stats = {}
    for p in PARAM_BOUNDS.keys():
        diffs = [r['param_'+p]-r['rule_'+p] for r in rows]
        if not diffs:
            continue
        arr = np.array(diffs, dtype=np.float32)
        lo,hi = PARAM_BOUNDS[p]
        rng = hi-lo
        stats[p] = {
            'mean': float(arr.mean()),
            'std': float(arr.std()),
            'std_pct_range': float(arr.std()/rng*100.0),
            'abs_mean_pct_range': float(np.abs(arr).mean()/rng*100.0),
            'min': float(arr.min()),
            'max': float(arr.max()),
        }
    return stats


def feature_residual_corr(rows):
    # 返回: {param: [corr for each feature]}
    corr = {}
    feats_mat = np.stack([r['features'] for r in rows])  # N x F
    for p in PARAM_BOUNDS.keys():
        diffs = np.array([r['param_'+p]-r['rule_'+p] for r in rows], dtype=np.float32)
        vecs = []
        for j in range(feats_mat.shape[1]):
            fcol = feats_mat[:,j]
            if np.std(fcol) < 1e-6 or np.std(diffs) < 1e-6:
                c = 0.0
            else:
                c = float(np.corrcoef(fcol, diffs)[0,1])
            vecs.append(c)
        corr[p] = vecs
    return corr


def main(args):
    rows = load_rows(args.data)
    if not rows:
        print('No valid rows.')
        return
    stats = residual_stats(rows)
    print('=== Residual Statistics (param - rule) ===')
    for p,info in stats.items():
        print(f"{p:18s} mean={info['mean']:+7.3f} std={info['std']:.3f} std%range={info['std_pct_range']:.2f}% absMean%range={info['abs_mean_pct_range']:.2f}% min={info['min']:+.3f} max={info['max']:+.3f}")
    if args.corr:
        corr = feature_residual_corr(rows)
        print('\n=== Feature-Residual Pearson Corr ===')
        header = 'param,' + ','.join(FEATURE_ORDER)
        print(header)
        for p,vec in corr.items():
            print(p+','+','.join(f"{v:.3f}" for v in vec))

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--data', type=str, default='meta/dataset/meta_params_dataset.csv')
    ap.add_argument('--corr', action='store_true', help='是否输出特征与残差的相关系数')
    args = ap.parse_args()
    main(args)
