"""collect_meta_dataset.py
收集 (地图特征 -> 最优参数 / 性能) 数据集。
流程：
1. 随机生成地图 (可调规模 & 障碍率区间)
2. 提取特征
3. 采样若干参数组合（拉丁超立方 / 简单随机）
4. 运行分层混合 A* (或回退) 获得指标
5. 选出多目标评分 top-k (或最优) 记录
6. 输出 CSV

多目标综合评分默认：score = w1*norm_path_len + w2*norm_smooth_len + w3*norm_expanded + w4*time
(指标越低越好)；可通过命令行参数调整。

后续训练：model 输入特征 → 预测最优参数（回归）。
"""
from __future__ import annotations
import argparse
import csv
import numpy as np
import time
from pathlib import Path
from typing import Dict, Any, List

from astar_demo import inflate_map, prune_path, smooth_path_with_bezier_adaptive, astar_hierarchical_hybrid
from meta.map_features import extract_map_features, features_to_vector
from meta.meta_controller import MetaController

PARAM_SPACE = {
    'initial_weight': (8.0, 36.0),
    'lambda_risk': (0.4, 2.2),
    'lambda_smooth': (0.2, 1.2),
    'lambda_bonus': (0.1, 1.2),
    'frontier_radius': (2, 7),
    'recent_visited_len': (15, 110),
    'curvature_window': (2, 5),
    'risk_power': (1.0, 1.8),
}

INT_PARAMS = {'frontier_radius','recent_visited_len','curvature_window'}

FEATURE_KEYS = [
    'height','width','obstacle_ratio','free_ratio','dist_mean','dist_std','dist_min',
    'dist_p25','dist_p50','dist_p75','num_components','largest_component_ratio',
    'narrow_region_ratio','approx_path_len','approx_reachable','start_goal_euclid',
    'start_local_free','goal_local_free','row_entropy','col_entropy'
]

PARAM_KEYS = list(PARAM_SPACE.keys())

METRIC_KEYS = ['path_len','smooth_len','expanded','time','success']

DEF_WEIGHTS = {'path_len':1.0,'smooth_len':0.6,'expanded':0.4,'time':0.3}


def sample_param() -> Dict[str, Any]:
    p = {}
    for k,(lo,hi) in PARAM_SPACE.items():
        val = np.random.uniform(lo,hi)
        if k in INT_PARAMS:
            val = int(round(val))
        p[k] = val
    p['min_weight'] = 1.0
    return p


def run_once(map_grid, start, goal, params) -> Dict[str, Any]:
    inflation_radius = 2
    path = []
    expanded_order = np.zeros_like(map_grid)
    t0 = time.time()
    for r in range(inflation_radius, -1, -1):
        inflated = inflate_map(map_grid, r)
        inflated[start] = 0
        inflated[goal] = 0
        path_tmp, expanded_tmp = astar_hierarchical_hybrid(inflated, start, goal, params)
        if path_tmp:
            path = np.array(path_tmp)
            expanded_order = expanded_tmp
            break
    t_plan = time.time() - t0
    if len(path)==0:
        return {
            'success': False,
            'path_len': np.nan,
            'smooth_len': np.nan,
            'expanded': np.nan,
            'time': t_plan,
        }
    path = prune_path(path, map_grid)
    spath = smooth_path_with_bezier_adaptive(path, map_grid)
    raw_len = float(np.sum(np.linalg.norm(np.diff(path, axis=0), axis=1)))
    smooth_len = float(np.sum(np.linalg.norm(np.diff(spath, axis=0), axis=1)))
    expanded = int(np.max(expanded_order))
    return {
        'success': True,
        'path_len': raw_len,
        'smooth_len': smooth_len,
        'expanded': expanded,
        'time': t_plan,
    }


def compute_score(metric: Dict[str,Any], weights: Dict[str,float], norm_stats: Dict[str, float]):
    if not metric['success']:
        return 1e9
    score = 0.0
    for k,w in weights.items():
        v = metric[k]
        mean = norm_stats[k]['mean']
        std  = norm_stats[k]['std']
        if std < 1e-6:
            norm_v = 0.0
        else:
            norm_v = (v - mean)/std
        score += w * norm_v
    return score


def collect(args):
    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(args.seed)

    rows, cols = args.rows, args.cols
    start = (0,0)
    goal = (rows-1, cols-1)

    records: List[Dict[str,Any]] = []

    for m in range(args.maps):
        # --- 1. 生成随机地图 ---
        obstacle_ratio = rng.uniform(args.min_obs, args.max_obs)
        grid = (rng.random((rows, cols)) < obstacle_ratio).astype(int)
        grid[start] = 0
        goal_cell_blocked = grid[goal] == 1
        grid[goal] = 0

        # --- 2. 提取特征 ---
        feats = extract_map_features(grid, start, goal)

        # --- 3. 计算 rule 基线参数（delta 训练所需参考）---
        mc_rule = MetaController(use_mlp=False)
        rule_params = mc_rule.get_params(feats)

        # --- 4. 采样参数并运行若干 trial ---
        param_trials: List[Dict[str, Any]] = []
        metrics: List[Dict[str, Any]] = []

        # 全局随机采样
        for _ in range(args.param_trials):
            params = sample_param()
            result = run_once(grid, start, goal, params)
            params['_source'] = 'global'
            param_trials.append(params)
            metrics.append(result)

        # 局部扰动采样（围绕 rule）
        if args.local_trials > 0:
            for _ in range(args.local_trials):
                perturbed = {}
                for k,(lo,hi) in PARAM_SPACE.items():
                    base_val = rule_params[k]
                    span = hi - lo
                    noise = np.random.normal(0, args.local_scale * span)
                    val = base_val + noise
                    if k in INT_PARAMS:
                        val = int(round(val))
                    # clamp
                    if k in INT_PARAMS:
                        val = int(np.clip(val, lo, hi))
                    else:
                        val = float(np.clip(val, lo, hi))
                    perturbed[k] = val
                perturbed['min_weight'] = 1.0
                result = run_once(grid, start, goal, perturbed)
                perturbed['_source'] = 'local'
                param_trials.append(perturbed)
                metrics.append(result)

        # --- 5. 为多目标评分做指标标准化统计 ---
        norm_stats = {}
        for k in DEF_WEIGHTS.keys():
            vals = [r[k] for r in metrics if r['success'] and not np.isnan(r[k])]
            if len(vals) == 0:
                norm_stats[k] = {'mean': 0.0, 'std': 1.0}
            else:
                norm_stats[k] = {'mean': float(np.mean(vals)), 'std': float(np.std(vals)) + 1e-6}

        # --- 6. 计算得分 & 选最优 + Top-k 软标签 ---
        scored = []  # (score, idx)
        for i, (p, mtr) in enumerate(zip(param_trials, metrics)):
            sc = compute_score(mtr, DEF_WEIGHTS, norm_stats)
            scored.append((sc, i))
        scored.sort(key=lambda x: x[0])
        if not scored or not np.isfinite(scored[0][0]):
            continue
        best_score, best_idx = scored[0]
        best_params = param_trials[best_idx]
        best_metric = metrics[best_idx]

        soft_vec = None
        if args.topk > 1:
            k = min(args.topk, len(scored))
            top_slice = scored[:k]
            scores_arr = np.array([s for s,_ in top_slice], dtype=np.float32)
            base = scores_arr[0]
            # 权重：exp(-alpha*(score - best))
            w = np.exp(-args.soft_alpha * (scores_arr - base))
            w /= (w.sum() + 1e-8)
            # 加权平均参数
            acc = {p:0.0 for p in PARAM_KEYS}
            for (sc, idx), weight in zip(top_slice, w):
                for p in PARAM_KEYS:
                    acc[p] += param_trials[idx][p] * float(weight)
            soft_vec = acc

        # --- 7. 记录样本 ---
        rec: Dict[str, Any] = {}
        # 特征
        for k in FEATURE_KEYS:
            rec[k] = feats[k]
        # 最优参数（label，用于 direct 模式或后续转换为 delta）
        for k in PARAM_KEYS:
            rec['param_' + k] = best_params[k]
        rec['param_source'] = best_params.get('_source','global')
        # rule 基线参数（用于 delta = param - rule）
        for k in PARAM_KEYS:
            rec['rule_' + k] = rule_params[k]
        # 软标签
        if soft_vec is not None:
            for k in PARAM_KEYS:
                rec['soft_param_'+k] = soft_vec[k]
            rec['soft_topk'] = args.topk
            rec['soft_alpha'] = args.soft_alpha
        # 指标
        for k in METRIC_KEYS:
            rec['metric_' + k] = best_metric[k]
        rec['score'] = best_score
        rec['map_obstacle_ratio_used'] = obstacle_ratio
        rec['goal_original_blocked'] = int(goal_cell_blocked)
        records.append(rec)

        if (m + 1) % 5 == 0:
            print(f"Collected {m + 1}/{args.maps} maps")

    # 写 CSV
    if records:
        fieldnames = list(records[0].keys())
        with out_path.open('w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(records)
        print(f"Saved dataset: {out_path} (rows={len(records)})")
    else:
        print("No successful records collected.")


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument('-o','--output', type=str, default='meta/dataset/meta_params_dataset.csv')
    ap.add_argument('--maps', type=int, default=60)
    ap.add_argument('--param-trials', type=int, default=25, help='全局随机采样次数')
    ap.add_argument('--local-trials', type=int, default=0, help='围绕 rule 参数的局部扰动采样次数')
    ap.add_argument('--local-scale', type=float, default=0.05, help='局部扰动相对参数范围的标准差比例 (0.05=5%)')
    ap.add_argument('--topk', type=int, default=1, help='>1 时启用 top-k 软标签')
    ap.add_argument('--soft-alpha', type=float, default=35.0, help='软标签权重温度，越大越接近硬最优')
    ap.add_argument('--rows', type=int, default=60)
    ap.add_argument('--cols', type=int, default=60)
    ap.add_argument('--min-obs', type=float, default=0.12)
    ap.add_argument('--max-obs', type=float, default=0.40)
    ap.add_argument('--seed', type=int, default=42)
    return ap.parse_args()

if __name__ == '__main__':
    args = parse_args()
    collect(args)
