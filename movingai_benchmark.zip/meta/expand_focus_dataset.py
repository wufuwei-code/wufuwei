#!/usr/bin/env python3
"""
扩展JSONL训练数据集
基于collect_meta_dataset生成更大规模的focused_training_dataset_v3.jsonl
目标：1000-5000样本，保持与v2相同的字段格式
"""
import argparse
import json
import os
import sys
import time
import numpy as np
from pathlib import Path
from typing import Dict, Any, List, Tuple
from concurrent.futures import ProcessPoolExecutor, as_completed
import multiprocessing as mp

# 添加项目根目录到Python路径
sys.path.append(str(Path(__file__).parent.parent))

from astar_demo import inflate_map, prune_path, smooth_path_with_bezier_adaptive, astar_hierarchical_hybrid
from meta.map_features import extract_map_features, features_to_vector
from scipy.ndimage import distance_transform_edt

# 参数空间（与原始collect_meta_dataset保持一致）
PARAM_SPACE = {
    'initial_weight': (8.0, 50.0),  # 扩展上限到50
    'lambda_risk': (0.2, 4.0),     # 扩展范围
    'lambda_smooth': (0.1, 3.0),   # 扩展范围
    'lambda_bonus': (0.0, 2.0),    # 扩展范围
    'frontier_radius': (2, 6),      # 对应[2,3,4,5,6]
    'recent_visited_len': (10, 50), # 对应[10,20,30,40,50]
}

INT_PARAMS = {'frontier_radius', 'recent_visited_len'}

def generate_map_with_retries(rows: int, cols: int, obs_rate: float, 
                            max_retries: int = 5) -> Tuple[np.ndarray, Tuple[int, int], Tuple[int, int]]:
    """生成可达的地图，带重试机制"""
    for attempt in range(max_retries):
        # 生成随机地图
        grid = np.random.random((rows, cols)) < obs_rate
        
        # 选择起点和终点
        free_cells = [(r, c) for r in range(rows) for c in range(cols) if not grid[r, c]]
        if len(free_cells) < 2:
            continue
            
        start, goal = np.random.choice(len(free_cells), 2, replace=False)
        start = free_cells[start]
        goal = free_cells[goal]
        
        # 简单连通性检查（BFS）
        if is_reachable(grid, start, goal):
            return grid, start, goal
    
    # 如果重试失败，生成简单的可达地图
    grid = np.zeros((rows, cols), dtype=bool)
    # 添加一些随机障碍
    for _ in range(int(rows * cols * obs_rate * 0.5)):
        r, c = np.random.randint(0, rows), np.random.randint(0, cols)
        grid[r, c] = True
    
    start = (1, 1)
    goal = (rows-2, cols-2)
    grid[start] = False
    grid[goal] = False
    
    return grid, start, goal

def is_reachable(grid: np.ndarray, start: Tuple[int, int], goal: Tuple[int, int]) -> bool:
    """BFS检查连通性"""
    rows, cols = grid.shape
    visited = set()
    queue = [start]
    
    while queue:
        r, c = queue.pop(0)
        if (r, c) == goal:
            return True
        if (r, c) in visited:
            continue
        visited.add((r, c))
        
        # 8邻域
        for dr in [-1, 0, 1]:
            for dc in [-1, 0, 1]:
                if dr == 0 and dc == 0:
                    continue
                nr, nc = r + dr, c + dc
                if 0 <= nr < rows and 0 <= nc < cols and not grid[nr, nc]:
                    if (nr, nc) not in visited:
                        queue.append((nr, nc))
    
    return False

def sample_parameters(n_samples: int, seed: int) -> List[Dict[str, float]]:
    """采样参数组合"""
    np.random.seed(seed)
    samples = []
    
    for _ in range(n_samples):
        params = {}
        for name, (low, high) in PARAM_SPACE.items():
            if name in INT_PARAMS:
                params[name] = float(np.random.randint(low, high + 1))
            else:
                params[name] = np.random.uniform(low, high)
        samples.append(params)
    
    return samples

def evaluate_parameters(grid: np.ndarray, start: Tuple[int, int], goal: Tuple[int, int],
                       params: Dict[str, float], timeout: float = 5.0) -> Dict[str, Any]:
    """评估单组参数"""
    try:
        # 运行A*算法
        start_time = time.time()
        
        # 构建参数字典
        astar_params = {
            'initial_weight': params['initial_weight'],
            'lambda_risk': params['lambda_risk'],
            'lambda_smooth': params['lambda_smooth'],
            'lambda_bonus': params['lambda_bonus'],
            'frontier_radius': int(params['frontier_radius']),
            'recent_visited_len': int(params['recent_visited_len']),
        }
        
        # 调用astar_hierarchical_hybrid
        path, expanded_order = astar_hierarchical_hybrid(grid, start, goal, astar_params)
        
        elapsed = time.time() - start_time
        
        if path is not None and len(path) > 1:
            # 成功找到路径
            path_length = len(path)
            
            # 计算路径平滑性（简化版）
            smooth_gain = 0.0
            if path_length > 2:
                # 计算转弯次数
                turns = 0
                for i in range(1, len(path) - 1):
                    dir1 = (path[i][0] - path[i-1][0], path[i][1] - path[i-1][1])
                    dir2 = (path[i+1][0] - path[i][0], path[i+1][1] - path[i][1])
                    if dir1 != dir2:
                        turns += 1
                smooth_gain = turns / len(path) if len(path) > 0 else 1.0
            
            # 计算扩展节点数
            expanded_count = np.count_nonzero(expanded_order)
            
            # 简化评分
            score = path_length / (grid.shape[0] + grid.shape[1])
            
            return {
                'success': True,
                'path_length': path_length,
                'expanded': expanded_count,
                'time': elapsed,
                'smooth_gain': smooth_gain,
                'score': score
            }
        else:
            # 失败
            return {
                'success': False,
                'path_length': None,
                'expanded': grid.shape[0] * grid.shape[1] // 4,  # 估算
                'time': elapsed,
                'smooth_gain': None,
                'score': float('inf')
            }
            
    except Exception as e:
        return {
            'success': False,
            'path_length': None,
            'expanded': 0,
            'time': timeout,
            'smooth_gain': None,
            'score': float('inf')
        }

def collect_single_map(map_config: Tuple[int, int, int, float, int]) -> List[Dict[str, Any]]:
    """为单个地图收集数据"""
    map_id, rows, cols, obs_rate, seed = map_config
    
    # 设置随机种子
    np.random.seed(seed)
    
    try:
        # 生成地图
        grid, start, goal = generate_map_with_retries(rows, cols, obs_rate)
        
        # 提取地图特征
        features = extract_map_features(grid, start, goal)
        
        # 计算简化特征向量（4维）
        obstacle_density = features.get('obstacle_ratio', obs_rate)
        confidence_score = min(1.0, features.get('largest_component_ratio', 0.5) + 
                             features.get('approx_reachable', 0.5) * 0.5)
        start_goal_distance = features.get('start_goal_euclid', 
                                         np.linalg.norm(np.array(goal) - np.array(start)))
        connectivity_ratio = features.get('largest_component_ratio', None)
        
        # 采样参数组合
        param_samples = sample_parameters(n_samples=25, seed=seed + map_id)
        
        # 评估所有参数组合
        results = []
        for i, params in enumerate(param_samples):
            eval_result = evaluate_parameters(grid, start, goal, params)
            
            # 构建记录
            record = {
                'map_hash': f"{map_id:08x}{seed:08x}",
                'label': 1 if eval_result['success'] else 0,
                'obstacle_density': obstacle_density,
                'confidence_score': confidence_score,
                'start_goal_distance': start_goal_distance,
                'connectivity_ratio': connectivity_ratio,
                
                # 路径指标（可能为null）
                'path_length': eval_result['path_length'],
                'smooth_path_length': None,  # 暂不计算
                'path_smooth_gain_ratio': eval_result['smooth_gain'],
                
                # 参数
                'initial_weight': params['initial_weight'],
                'lambda_risk': params['lambda_risk'],
                'lambda_smooth': params['lambda_smooth'],
                'lambda_bonus': params['lambda_bonus'],
                'frontier_radius': params['frontier_radius'],
                'recent_visited_len': params['recent_visited_len'],
                'curvature_window': 3.0,  # 固定值
                'risk_power': 2.0,        # 固定值
                
                # 元数据
                'has_path_metrics': 1 if eval_result['path_length'] is not None else 0,
                'has_connectivity': 1 if connectivity_ratio is not None else 0,
                'initial_weight_level': 'heavy' if params['initial_weight'] >= 30 else 'clipped',
                'density_bucket': min(4, int(obstacle_density * 10)),
                'difficulty_tag': f"d{min(4, int(obstacle_density * 10))}_{'heavy' if params['initial_weight'] >= 30 else 'clipped'}",
                'difficulty_score': obstacle_density * 0.7 + (1 - confidence_score) * 0.3
            }
            
            results.append(record)
        
        # 选择最好的3个结果（成功的优先，按score排序）
        successful = [r for r in results if r['label'] == 1]
        failed = [r for r in results if r['label'] == 0]
        
        if successful:
            successful.sort(key=lambda x: evaluate_parameters(grid, start, goal, {
                k: x[k] for k in PARAM_SPACE.keys()
            })['score'])
            top_results = successful[:3]
        else:
            # 如果没有成功的，选择失败的
            top_results = failed[:3]
        
        return top_results
        
    except Exception as e:
        print(f"地图 {map_id} 处理失败: {e}")
        return []

def main():
    parser = argparse.ArgumentParser(description="扩展JSONL训练数据集")
    parser.add_argument('--output', type=str, 
                       default='data_v2/focused_training_dataset_v3.jsonl',
                       help='输出JSONL文件路径')
    parser.add_argument('--maps', type=int, default=500,
                       help='生成地图数量')
    parser.add_argument('--workers', type=int, default=4,
                       help='并行进程数')
    parser.add_argument('--min-size', type=int, default=30,
                       help='最小地图尺寸')
    parser.add_argument('--max-size', type=int, default=80,
                       help='最大地图尺寸')
    parser.add_argument('--min-obs', type=float, default=0.10,
                       help='最小障碍率')
    parser.add_argument('--max-obs', type=float, default=0.45,
                       help='最大障碍率')
    parser.add_argument('--seed', type=int, default=42,
                       help='随机种子')
    
    args = parser.parse_args()
    
    # 确保输出目录存在
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    # 生成地图配置
    np.random.seed(args.seed)
    map_configs = []
    
    for i in range(args.maps):
        rows = cols = np.random.randint(args.min_size, args.max_size + 1)
        obs_rate = np.random.uniform(args.min_obs, args.max_obs)
        map_configs.append((i, rows, cols, obs_rate, args.seed + i * 1000))
    
    print(f"🚀 开始扩展数据集")
    print(f"目标地图数: {args.maps}")
    print(f"地图尺寸: {args.min_size}-{args.max_size}")
    print(f"障碍率: {args.min_obs:.2f}-{args.max_obs:.2f}")
    print(f"并行度: {args.workers}")
    print(f"输出: {args.output}")
    
    start_time = time.time()
    all_records = []
    
    # 并行处理
    with ProcessPoolExecutor(max_workers=args.workers) as executor:
        # 提交任务
        future_to_map = {executor.submit(collect_single_map, config): config[0] 
                        for config in map_configs}
        
        # 收集结果
        completed = 0
        for future in as_completed(future_to_map):
            map_id = future_to_map[future]
            try:
                records = future.result()
                all_records.extend(records)
                completed += 1
                
                if completed % 50 == 0:
                    print(f"进度: {completed}/{args.maps} 地图, {len(all_records)} 样本")
                    
            except Exception as e:
                print(f"地图 {map_id} 失败: {e}")
    
    total_time = time.time() - start_time
    
    # 写入JSONL文件
    with open(args.output, 'w') as f:
        for record in all_records:
            f.write(json.dumps(record) + '\n')
    
    print(f"\n✅ 数据收集完成!")
    print(f"总样本数: {len(all_records)}")
    print(f"总用时: {total_time:.1f}s")
    print(f"输出文件: {args.output}")
    
    # 简单统计
    success_count = sum(1 for r in all_records if r['label'] == 1)
    print(f"成功率: {success_count}/{len(all_records)} ({success_count/len(all_records)*100:.1f}%)")

if __name__ == "__main__":
    main()