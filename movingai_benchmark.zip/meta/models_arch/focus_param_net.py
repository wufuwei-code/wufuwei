"""FocusParamNet: 多头参数预测模型"""
from __future__ import annotations
from typing import Dict, List, Tuple, Sequence, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F


class FocusParamNet(nn.Module):
    def __init__(
        self,
        input_dim: int,
        hidden: Sequence[int] = (256, 256),
        dropout: float = 0.1,
        continuous_specs: Optional[Dict[str, Tuple[float, float]]] = None,
        discrete_specs: Optional[Dict[str, Sequence[int]]] = None,
    ) -> None:
        super().__init__()

        if continuous_specs is None:
            continuous_specs = {
                "initial_weight": (1.0, 50.0),
                "lambda_risk": (0.2, 4.0),
                "lambda_smooth": (0.1, 3.0),
                "lambda_bonus": (0.0, 2.0),
            }
        if discrete_specs is None:
            discrete_specs = {
                "frontier_radius": [2, 3, 4, 5, 6],
                "recent_visited_len": [10, 20, 30, 40, 50],
            }

        self.continuous_specs = continuous_specs
        self.discrete_specs = discrete_specs

        layers: List[nn.Module] = []
        prev = input_dim
        for h in hidden:
            layers.append(nn.Linear(prev, h))
            layers.append(nn.ReLU())
            if dropout and dropout > 0:
                layers.append(nn.Dropout(dropout))
            prev = h
        self.backbone = nn.Sequential(*layers)

        self.continuous_heads = nn.ModuleDict({
            name: nn.Linear(prev, 1) for name in self.continuous_specs.keys()
        })
        self.discrete_heads = nn.ModuleDict({
            name: nn.Linear(prev, len(values)) for name, values in self.discrete_specs.items()
        })

    def forward(self, x: torch.Tensor, return_logits: bool = False) -> Dict[str, torch.Tensor]:
        h = self.backbone(x)
        outputs: Dict[str, torch.Tensor] = {}

        for name, (lo, hi) in self.continuous_specs.items():
            raw = self.continuous_heads[name](h)
            val = lo + torch.sigmoid(raw) * (hi - lo)
            outputs[name] = val.squeeze(-1)
            if return_logits:
                outputs[f"{name}_raw"] = raw.squeeze(-1)

        for name, classes in self.discrete_specs.items():
            logits = self.discrete_heads[name](h)
            probs = F.softmax(logits, dim=-1)
            pred_idx = torch.argmax(probs, dim=-1)
            class_tensor = torch.as_tensor(classes, device=logits.device)
            outputs[name] = class_tensor[pred_idx]
            if return_logits:
                outputs[f"{name}_logits"] = logits

        return outputs

    def forward_train(self, x: torch.Tensor) -> Dict[str, torch.Tensor]:
        h = self.backbone(x)
        out_cont: Dict[str, torch.Tensor] = {}
        out_disc: Dict[str, torch.Tensor] = {}
        
        for name, (lo, hi) in self.continuous_specs.items():
            raw = self.continuous_heads[name](h)
            val = lo + torch.sigmoid(raw) * (hi - lo)
            out_cont[name] = val.squeeze(-1)
            out_cont[f"{name}_raw"] = raw.squeeze(-1)
            
        for name, classes in self.discrete_specs.items():
            logits = self.discrete_heads[name](h)
            out_disc[name] = logits
            
        return {"continuous": out_cont, "discrete": out_disc}

    def compute_loss(self, batch: Dict[str, torch.Tensor], outputs: Dict[str, Dict[str, torch.Tensor]],
                     huber_delta: float = 1.0, class_weights: Optional[Dict[str, torch.Tensor]] = None,
                     sample_weight: Optional[torch.Tensor] = None) -> Tuple[torch.Tensor, Dict[str, float]]:
        def huber_loss(pred, target, delta=1.0):
            diff = pred - target
            abs_diff = diff.abs()
            quadratic = torch.minimum(abs_diff, torch.tensor(delta, device=diff.device))
            linear = abs_diff - quadratic
            return 0.5 * quadratic**2 + delta * linear

        cont_losses = []
        disc_losses = []
        metrics: Dict[str, float] = {}

        # 连续参数损失
        for name, target in batch['targets_cont'].items():
            if name not in outputs['continuous']:
                continue
            pred = outputs['continuous'][name]
            l = huber_loss(pred, target, huber_delta)
            if sample_weight is not None and sample_weight.shape[0] == l.shape[0]:
                l = l * sample_weight
            l = l.mean()
            cont_losses.append(l)
            metrics[f"loss_cont_{name}"] = l.item()

        # 离散参数损失
        for name, target in batch['targets_disc'].items():
            if name not in outputs['discrete']:
                continue
            logits = outputs['discrete'][name]
            weight = None
            if class_weights and name in class_weights:
                weight = class_weights[name].to(logits.device)
            ce = nn.functional.cross_entropy(logits, target, weight=weight, reduction='none')
            if sample_weight is not None and sample_weight.shape[0] == ce.shape[0]:
                ce = ce * sample_weight
            ce = ce.mean()
            disc_losses.append(ce)
            metrics[f"loss_disc_{name}"] = ce.item()

        total_cont = torch.stack(cont_losses).sum() if cont_losses else torch.tensor(0.0, device=outputs['continuous'][list(outputs['continuous'].keys())[0]].device if outputs['continuous'] else batch['sample_weight'].device)
        total_disc = torch.stack(disc_losses).sum() if disc_losses else torch.tensor(0.0, device=total_cont.device)
        total = total_cont + total_disc
        metrics['loss_cont_total'] = total_cont.item()
        metrics['loss_disc_total'] = total_disc.item()
        metrics['loss_total'] = total.item()
        return total, metrics

    @torch.no_grad()
    def predict_with_uncertainty(
        self,
        x: torch.Tensor,
        mc_times: int = 8,
        return_all: bool = False,
    ) -> Dict[str, torch.Tensor]:
        was_training = self.training
        self.train()
        all_samples: Dict[str, List[torch.Tensor]] = {}

        for _ in range(mc_times):
            out = self.forward(x, return_logits=False)
            for k, v in out.items():
                all_samples.setdefault(k, []).append(v.detach())

        if not was_training:
            self.eval()

        result: Dict[str, torch.Tensor] = {}
        for k, arr in all_samples.items():
            stack = torch.stack(arr, dim=0)
            if stack.dtype in [torch.long, torch.int]:
                mode_vals, _ = torch.mode(stack, dim=0)
                result[k] = mode_vals
                result[f"{k}_var"] = stack.float().var(dim=0, unbiased=False)
            else:
                mean = stack.mean(dim=0)
                var = stack.var(dim=0, unbiased=False)
                result[k] = mean
                result[f"{k}_var"] = var
            if return_all:
                result[f"{k}_all"] = stack
        return result


def build_default_focus_param_net(input_dim: int) -> FocusParamNet:
    return FocusParamNet(input_dim=input_dim)


__all__ = [
    "FocusParamNet",
    "build_default_focus_param_net",
]