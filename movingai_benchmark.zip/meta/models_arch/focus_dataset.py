"""Focus 参数预测数据集与 DataLoader 构建工具

参见之前说明: 读取 JSONL, 输出特征与多头标签。
"""
from __future__ import annotations
from typing import List, Dict, Any, Optional, Sequence
import json
import os
import torch
from torch.utils.data import Dataset

DEFAULT_CONTINUOUS_PARAMS = [
    "initial_weight",
    "lambda_risk",
    "lambda_smooth",
    "lambda_bonus",
]
DEFAULT_DISCRETE_PARAMS = [
    "frontier_radius",
    "recent_visited_len",
]
DEFAULT_DISCRETE_VALUE_SPACE: Dict[str, List[int]] = {
    "frontier_radius": [2,3,4,5,6],
    "recent_visited_len": [10,20,30,40,50],
}

def _safe_get(d: Dict[str, Any], key: str):
    return d.get(key, None)

class FocusParamDataset(Dataset):
    def __init__(self,
                 jsonl_path: str,
                 continuous_params: Optional[Sequence[str]] = None,
                 discrete_params: Optional[Sequence[str]] = None,
                 discrete_value_space: Optional[Dict[str, List[int]]] = None,
                 min_feature_len: int = 1,
                 drop_missing: bool = True,
                 add_sample_weight: bool = True) -> None:
        super().__init__()
        self.jsonl_path = jsonl_path
        self.continuous_params = list(continuous_params) if continuous_params else list(DEFAULT_CONTINUOUS_PARAMS)
        self.discrete_params = list(discrete_params) if discrete_params else list(DEFAULT_DISCRETE_PARAMS)
        self.discrete_value_space = discrete_value_space or DEFAULT_DISCRETE_VALUE_SPACE
        self.drop_missing = drop_missing
        self.add_sample_weight = add_sample_weight

        self.samples: List[Dict[str, Any]] = []
        self._load(min_feature_len)
        # 构建离散映射
        self._disc_value_to_index: Dict[str, Dict[int, int]] = {
            name: {v: i for i, v in enumerate(vals)} for name, vals in self.discrete_value_space.items()
        }
        self.class_weights: Dict[str, torch.Tensor] = {}
        self._build_class_weights()

    def _load(self, min_feature_len: int):
        if not os.path.isfile(self.jsonl_path):
            raise FileNotFoundError(self.jsonl_path)
        with open(self.jsonl_path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                except Exception:
                    continue
                # 处理特征：可能是 features 字段或者从其他字段合成
                feats = obj.get('features') or obj.get('feature') or obj.get('feat')
                if feats is None:
                    # 如果没有features字段，尝试从元数据构造简单特征向量
                    meta_feats = []
                    for k in ['obstacle_density', 'confidence_score', 'start_goal_distance', 'connectivity_ratio']:
                        v = obj.get(k)
                        if v is not None:
                            meta_feats.append(float(v))
                        else:
                            meta_feats.append(0.0)  # 缺失值填0
                    feats = meta_feats
                
                if not isinstance(feats, list) or len(feats) < min_feature_len:
                    continue
                
                # 处理参数：可能在params字典内，也可能在顶层
                params = obj.get('params') or obj.get('predicted_params') or obj
                miss = False
                for p in self.continuous_params:
                    if _safe_get(params, p) is None:
                        miss = True; break
                if not miss:
                    for p in self.discrete_params:
                        if _safe_get(params, p) is None:
                            miss = True; break
                if miss and self.drop_missing:
                    continue
                self.samples.append({
                    'features': feats,
                    'params': params,
                    'outcome': obj.get('outcome'),
                    'difficulty_tag': obj.get('difficulty_tag')
                })

    def _build_class_weights(self):
        counts_map: Dict[str, Dict[int, int]] = {p: {} for p in self.discrete_params}
        for s in self.samples:
            ps = s['params']
            for p in self.discrete_params:
                v = ps.get(p)
                if v is None: continue
                counts_map[p][v] = counts_map[p].get(v, 0) + 1
        for p in self.discrete_params:
            values = self.discrete_value_space[p]
            counts = torch.tensor([counts_map[p].get(v, 1) for v in values], dtype=torch.float32)
            inv = 1.0 / counts
            w = inv / inv.sum() * len(values)
            self.class_weights[p] = w

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx: int) -> Dict[str, Any]:
        rec = self.samples[idx]
        feats = torch.tensor(rec['features'], dtype=torch.float32)
        params = rec['params']
        cont_targets = {p: torch.tensor(float(params[p]), dtype=torch.float32) for p in self.continuous_params if params.get(p) is not None}
        disc_targets = {}
        for p in self.discrete_params:
            v = params.get(p)
            if v is None: continue
            idx_v = self._disc_value_to_index[p].get(int(v))
            if idx_v is None: continue
            disc_targets[p] = torch.tensor(idx_v, dtype=torch.long)
        sample_weight = 1.0
        if self.add_sample_weight:
            if rec.get('outcome') == 'failure':
                sample_weight *= 1.3
            if rec.get('difficulty_tag') in ("narrow_passage", "high_density", "multi_bend"):
                sample_weight *= 1.2
        return {
            'features': feats,
            'targets_cont': cont_targets,
            'targets_disc': disc_targets,
            'sample_weight': torch.tensor(sample_weight, dtype=torch.float32)
        }

    def collate_fn(self, batch: List[Dict[str, Any]]) -> Dict[str, Any]:
        X = torch.stack([b['features'] for b in batch], dim=0)
        cont_batch: Dict[str, torch.Tensor] = {}
        disc_batch: Dict[str, torch.Tensor] = {}
        for name in self.continuous_params:
            vals = [b['targets_cont'].get(name) for b in batch]
            if all(v is not None for v in vals):
                cont_batch[name] = torch.stack(vals, dim=0)
        for name in self.discrete_params:
            vals = [b['targets_disc'].get(name) for b in batch]
            if all(v is not None for v in vals):
                disc_batch[name] = torch.stack(vals, dim=0)
        sample_w = torch.stack([b['sample_weight'] for b in batch], dim=0)
        return {
            'features': X,
            'targets_cont': cont_batch,
            'targets_disc': disc_batch,
            'sample_weight': sample_w,
        }

__all__ = [
    'FocusParamDataset',
    'DEFAULT_CONTINUOUS_PARAMS',
    'DEFAULT_DISCRETE_PARAMS',
    'DEFAULT_DISCRETE_VALUE_SPACE'
]
