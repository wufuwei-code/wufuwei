#!/usr/bin/env python3
"""
高级校准方法集成测试

测试所有校准方法与A*路径规划系统的集成效果：
1. 端到端路径规划性能测试
2. 校准不确定度对规划质量的影响
3. 计算开销分析
4. 鲁棒性测试
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__)))

import torch
import numpy as np
import json
import time
from pathlib import Path
import argparse
from collections import defaultdict

from typing import Dict, List, Tuple, Any, Optional
import pandas as pd
import argparse
from collections import defaultdict
from environments.astar_env import AStarEnv
from calibrate_uncertainty import TemperatureScaling, VarianceScaling, IsotonicCalibration
from advanced_calibration import (
    EnsembleCalibration, AdaptiveCalibration, ConditionalCalibration,
    BayesianCalibration, MultiScaleCalibration, RobustCalibration
)
from dynamic_calibration import OnlineCalibration, TemporalCalibration, FeedbackDrivenCalibration

class CalibrationIntegrationTest:
    """校准方法集成测试"""

    def __init__(self):
        self.setup_methods()
        self.results = {}

    def setup_methods(self):
        """设置所有校准方法"""

        # 传统方法
        self.traditional_methods = {
            'original': lambda: None,
            'temperature': TemperatureScaling,
            'variance': VarianceScaling,
            'isotonic': IsotonicCalibration
        }

        # 高级方法
        self.advanced_methods = {
            'ensemble': EnsembleCalibration,
            'adaptive': AdaptiveCalibration,
            'conditional': ConditionalCalibration,
            'bayesian': BayesianCalibration,
            'multiscale': MultiScaleCalibration,
            'robust': RobustCalibration
        }

        # 动态方法
        self.dynamic_methods = {
            'online': OnlineCalibration,
            'temporal': TemporalCalibration,
            'feedback_driven': FeedbackDrivenCalibration
        }

        # 合并所有方法
        self.all_methods = {}
        self.all_methods.update(self.traditional_methods)
        self.all_methods.update(self.advanced_methods)
        self.all_methods.update(self.dynamic_methods)

    def run_integration_test(self, model_path: str, test_maps: List[str],
                           output_path: str = 'calibration_integration_results.json'):
        """运行集成测试"""

        print("🚀 开始校准方法集成测试")
        print(f"模型: {model_path}")
        print(f"测试地图: {test_maps}")

        # 加载模型
        model, enabled_cont = self.load_model(model_path)

        # 训练校准器
        print("🎯 训练校准器...")
        calibrators = self.train_calibrators(model, enabled_cont)

        # 运行集成测试
        print("🏃 运行集成测试...")
        integration_results = self.run_astar_integration_tests(
            model, calibrators, test_maps, enabled_cont
        )

        self.results = integration_results

        # 生成报告
        self.generate_integration_report()

        # 保存结果
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(self.results, f, indent=2, default=float, ensure_ascii=False)

        print(f"\n💾 集成测试结果已保存到: {output_path}")

    def load_model(self, model_path: str):
        """加载模型"""
        from models_arch.focus_param_net import FocusParamNet

        checkpoint = torch.load(model_path, map_location='cpu')
        args_in_ckpt = checkpoint.get('args', {}) or {}

        # 获取启用的参数
        default_cont_specs = {
            "initial_weight": (1.0, 50.0),
            "lambda_risk": (0.2, 4.0),
            "lambda_smooth": (0.1, 3.0),
            "lambda_bonus": (0.0, 2.0),
        }
        enabled_cont = args_in_ckpt.get('enabled_continuous') or list(default_cont_specs.keys())
        enabled_disc = args_in_ckpt.get('enabled_discrete') or ["frontier_radius", "recent_visited_len"]

        cont_specs = {k: v for k, v in default_cont_specs.items() if k in enabled_cont}
        disc_specs = {"frontier_radius": [2, 3, 4, 5, 6], "recent_visited_len": [10, 20, 30, 40, 50]}
        disc_specs = {k: v for k, v in disc_specs.items() if k in enabled_disc}

        model = FocusParamNet(input_dim=4, continuous_specs=cont_specs, discrete_specs=disc_specs)
        model.load_state_dict(checkpoint['model_state'], strict=False)
        model.eval()

        return model, enabled_cont

    def train_calibrators(self, model, enabled_cont: List[str]) -> Dict[str, Any]:
        """训练所有校准器"""

        # 收集训练数据
        print("  📊 收集训练数据...")
        train_predictions, train_targets, train_uncertainties, train_features = \
            self.collect_training_data(model, enabled_cont)

        calibrators = {}

        # 训练每种方法
        all_methods = {}
        all_methods.update(self.traditional_methods)
        all_methods.update(self.advanced_methods)
        all_methods.update(self.dynamic_methods)

        for method_name, method_class in all_methods.items():
            if method_name == 'original':
                calibrators[method_name] = None
                continue

            print(f"  🔧 训练 {method_name} 校准器...")

            method_calibrators = {}
            for param in enabled_cont:
                if len(train_predictions[param]) == 0:
                    continue

                try:
                    calibrator = method_class()

                    # 根据方法类型传递不同参数
                    fit_kwargs = {}
                    if method_name in ['adaptive', 'robust']:
                        fit_kwargs['features'] = np.array(train_features[param])
                    elif method_name == 'conditional':
                        fit_kwargs['predictions'] = np.array(train_predictions[param])

                    calibrator.fit(
                        np.array(train_predictions[param]),
                        np.array(train_uncertainties[param]),
                        np.array(train_targets[param]),
                        **fit_kwargs
                    )

                    method_calibrators[param] = calibrator

                except Exception as e:
                    print(f"    参数 {param} 训练失败: {e}")
                    method_calibrators[param] = None

            calibrators[method_name] = method_calibrators

        return calibrators

    def collect_training_data(self, model, enabled_cont: List[str], n_samples: int = 1000):
        """收集训练数据"""

        # 创建一些随机地图进行训练
        train_predictions = {param: [] for param in enabled_cont}
        train_targets = {param: [] for param in enabled_cont}
        train_uncertainties = {param: [] for param in enabled_cont}
        train_features = {param: [] for param in enabled_cont}

        # 生成随机地图特征
        np.random.seed(42)
        for _ in range(n_samples):
            # 随机地图特征
            features = torch.randn(1, 4)  # 4维特征

            with torch.no_grad():
                mc_pred = model.predict_with_uncertainty(features, mc_times=10)

            # 模拟目标值 (这里使用预测值作为近似)
            for param in enabled_cont:
                pred = mc_pred[param].item()
                uncert = torch.sqrt(mc_pred[f"{param}_var"]).item()

                train_predictions[param].append(pred)
                train_uncertainties[param].append(uncert)
                train_targets[param].append(pred + np.random.normal(0, uncert * 0.1))  # 添加噪声
                train_features[param].append(features.squeeze().numpy())

        return train_predictions, train_targets, train_uncertainties, train_features

    def run_astar_integration_tests(self, model, calibrators: Dict,
                                  test_maps: List[str], enabled_cont: List[str]) -> Dict:
        """运行A*集成测试"""

        results = defaultdict(list)

        for map_path in test_maps:
            print(f"  🗺️  测试地图: {Path(map_path).name}")

            # 加载地图
            map_data = self.load_map(map_path)
            if map_data is None:
                continue

            # 为每个方法运行A*规划
            for method_name, method_calibrators in calibrators.items():
                print(f"    🔍 测试方法: {method_name}")

                # 运行多次以获得统计
                method_results = []
                for trial in range(5):  # 5次试验
                    result = self.run_single_astar_test(
                        model, method_calibrators, map_data,
                        enabled_cont, method_name
                    )
                    method_results.append(result)

                # 计算平均结果
                avg_result = self.average_results(method_results)
                avg_result['map'] = Path(map_path).name
                avg_result['method'] = method_name

                results[method_name].append(avg_result)

        return dict(results)

    def run_single_astar_test(self, model, method_calibrators, map_data,
                            enabled_cont: List[str], method_name: str) -> Dict:
        """运行单个A*测试"""

        # 创建A*环境
        env = AStarEnv(map_data['grid'], map_data['start'], map_data['goal'])

        # 获取地图特征
        features = self.extract_map_features(map_data)

        # 预测参数
        with torch.no_grad():
            mc_pred = model.predict_with_uncertainty(torch.tensor(features).unsqueeze(0), mc_times=20)

        # 应用校准
        calibrated_params = {}
        calibration_times = {}

        for param in enabled_cont:
            pred = mc_pred[param].item()
            uncert = torch.sqrt(mc_pred[f"{param}_var"]).item()

            if method_calibrators and param in method_calibrators and method_calibrators[param]:
                start_time = time.time()
                calibrated_uncert = method_calibrators[param].calibrate(
                    np.array([uncert]), predictions=np.array([pred]) if method_name == 'conditional' else None,
                    features=np.array([features]) if method_name in ['adaptive', 'robust'] else None
                )[0]
                calibration_times[param] = time.time() - start_time
            else:
                calibrated_uncert = uncert
                calibration_times[param] = 0.0

            calibrated_params[param] = pred

        # 运行A*规划
        start_time = time.time()
        path, cost, expanded_nodes, planning_time = self.run_weighted_astar(
            env, calibrated_params
        )
        total_time = time.time() - start_time

        # 计算路径质量指标
        path_length = len(path) if path else 0
        is_valid = self.validate_path(path, env)
        optimality_gap = self.compute_optimality_gap(path, env) if path else float('inf')

        return {
            'path_length': path_length,
            'path_cost': cost,
            'expanded_nodes': expanded_nodes,
            'planning_time': planning_time,
            'total_time': total_time,
            'calibration_time': sum(calibration_times.values()),
            'is_valid': is_valid,
            'optimality_gap': optimality_gap,
            'parameters': calibrated_params,
            'uncertainties': {param: torch.sqrt(mc_pred[f"{param}_var"]).item() for param in enabled_cont}
        }

    def run_weighted_astar(self, env: AStarEnv, params: Dict) -> Tuple[List, float, int, float]:
        """运行加权A*规划"""

        start_time = time.time()

        # 使用预测的参数
        initial_weight = params.get('initial_weight', 1.0)
        lambda_risk = params.get('lambda_risk', 1.0)
        lambda_smooth = params.get('lambda_smooth', 0.5)
        lambda_bonus = params.get('lambda_bonus', 0.0)

        # 简单的加权A*实现
        from queue import PriorityQueue
        import math

        start = env.start
        goal = env.goal
        grid = env.grid

        def heuristic(a, b):
            return abs(a[0] - b[0]) + abs(a[1] - b[1])

        frontier = PriorityQueue()
        frontier.put((0, start))
        came_from = {start: None}
        cost_so_far = {start: 0}
        expanded = 0

        while not frontier.empty():
            current = frontier.get()[1]
            expanded += 1

            if current == goal:
                break

            for next_pos in env.get_neighbors(current):
                # 计算移动代价
                move_cost = 1.0  # 基础代价

                # 添加风险代价
                if grid[next_pos[0]][next_pos[1]] > 0:  # 有障碍物风险
                    move_cost += lambda_risk * grid[next_pos[0]][next_pos[1]]

                # 添加平滑代价 (转向惩罚)
                if came_from[current] is not None:
                    prev_dir = (current[0] - came_from[current][0], current[1] - came_from[current][1])
                    curr_dir = (next_pos[0] - current[0], next_pos[1] - current[1])
                    if prev_dir != curr_dir:
                        move_cost += lambda_smooth

                # 添加奖励
                move_cost -= lambda_bonus

                new_cost = cost_so_far[current] + move_cost
                priority = new_cost + initial_weight * heuristic(next_pos, goal)

                if next_pos not in cost_so_far or new_cost < cost_so_far[next_pos]:
                    cost_so_far[next_pos] = new_cost
                    priority = new_cost + initial_weight * heuristic(next_pos, goal)
                    frontier.put((priority, next_pos))
                    came_from[next_pos] = current

        # 重建路径
        if goal not in came_from:
            return None, float('inf'), expanded, time.time() - start_time

        path = []
        current = goal
        while current != start:
            path.append(current)
            current = came_from[current]
        path.append(start)
        path.reverse()

        total_cost = cost_so_far[goal]
        planning_time = time.time() - start_time

        return path, total_cost, expanded, planning_time

    def load_map(self, map_path: str) -> Optional[Dict]:
        """加载地图数据"""
        try:
            # 这里应该实现实际的地图加载逻辑
            # 暂时返回一个简单的示例地图
            grid = np.random.choice([0, 1], size=(20, 20), p=[0.7, 0.3])
            start = (0, 0)
            goal = (19, 19)

            # 确保起点和终点是可通行的
            grid[start] = 0
            grid[goal] = 0

            return {
                'grid': grid,
                'start': start,
                'goal': goal
            }
        except Exception as e:
            print(f"加载地图失败 {map_path}: {e}")
            return None

    def extract_map_features(self, map_data: Dict) -> np.ndarray:
        """提取地图特征"""
        grid = map_data['grid']
        start = map_data['start']
        goal = map_data['goal']

        # 计算基本特征
        height, width = grid.shape
        obstacle_ratio = np.mean(grid)
        start_goal_dist = np.sqrt((start[0] - goal[0])**2 + (start[1] - goal[1])**2)
        normalized_dist = start_goal_dist / np.sqrt(height**2 + width**2)

        return np.array([height, width, obstacle_ratio, normalized_dist])

    def validate_path(self, path: List, env: AStarEnv) -> bool:
        """验证路径有效性"""
        if not path:
            return False

        # 检查起点和终点
        if path[0] != env.start or path[-1] != env.goal:
            return False

        # 检查连续性
        for i in range(len(path) - 1):
            if not env.is_neighbor(path[i], path[i+1]):
                return False

        # 检查无碰撞
        for pos in path:
            if env.grid[pos[0]][pos[1]] == 1:  # 假设1表示障碍物
                return False

        return True

    def compute_optimality_gap(self, path: List, env: AStarEnv) -> float:
        """计算最优性差距"""
        if not path:
            return float('inf')

        # 计算路径长度
        path_length = len(path) - 1  # 边数

        # 计算曼哈顿距离作为最优基准
        manhattan_dist = abs(env.start[0] - env.goal[0]) + abs(env.start[1] - env.goal[1])

        if manhattan_dist == 0:
            return 0.0

        return (path_length - manhattan_dist) / manhattan_dist

    def average_results(self, results: List[Dict]) -> Dict:
        """计算结果平均值"""
        if not results:
            return {}

        # 数值字段
        numeric_fields = ['path_length', 'path_cost', 'expanded_nodes', 'planning_time',
                         'total_time', 'calibration_time', 'optimality_gap']

        avg_result = {}
        for field in numeric_fields:
            values = [r[field] for r in results if field in r and r[field] != float('inf')]
            avg_result[field] = np.mean(values) if values else float('inf')

        # 布尔字段
        avg_result['is_valid'] = np.mean([r.get('is_valid', False) for r in results])

        # 参数和不确定度 (取第一个，因为它们应该相似)
        if results:
            avg_result['parameters'] = results[0].get('parameters', {})
            avg_result['uncertainties'] = results[0].get('uncertainties', {})

        return avg_result

    def generate_integration_report(self):
        """生成集成测试报告"""

        print("\n" + "="*100)
        print("🔗 校准方法集成测试报告")
        print("="*100)

        if not self.results:
            print("没有集成测试结果")
            return

        # 收集所有结果
        all_results = []
        for method, method_results in self.results.items():
            for result in method_results:
                all_results.append({**result, 'method': method})

        if not all_results:
            print("没有有效的测试结果")
            return

        # 转换为DataFrame便于分析
        df = pd.DataFrame(all_results)

        # 1. 路径规划性能对比
        print("\n🏆 路径规划性能对比")
        print("-" * 80)

        perf_stats = df.groupby('method').agg({
            'path_length': ['mean', 'std'],
            'path_cost': ['mean', 'std'],
            'expanded_nodes': ['mean', 'std'],
            'planning_time': 'mean',
            'is_valid': 'mean',
            'optimality_gap': 'mean'
        }).round(3)

        # 按路径长度排序 (越短越好)
        sorted_methods = perf_stats.sort_values(('path_length', 'mean'))

        for method in sorted_methods.index:
            stats = perf_stats.loc[method]
            print(f"{method:<15}: 长度={stats[('path_length', 'mean')]:.1f}±{stats[('path_length', 'std')]:.1f}, "
                  f"代价={stats[('path_cost', 'mean')]:.1f}, 扩展={stats[('expanded_nodes', 'mean')]:.0f}, "
                  f"有效率={stats[('is_valid', 'mean')]:.3f}")

        # 2. 计算效率分析
        print("\n⚡ 计算效率分析")
        print("-" * 60)

        efficiency_stats = df.groupby('method').agg({
            'total_time': 'mean',
            'calibration_time': 'mean',
            'planning_time': 'mean'
        }).round(4)

        for method in efficiency_stats.index:
            stats = efficiency_stats.loc[method]
            total_time = stats['total_time']
            calib_time = stats['calibration_time']
            plan_time = stats['planning_time']
            calib_ratio = calib_time / total_time if total_time > 0 else 0

            print(f"{method:<15}: 总时间={total_time:.4f}s, 校准占比={calib_ratio:.1%}")

        # 3. 鲁棒性分析
        print("\n🛡️  鲁棒性分析")
        print("-" * 40)

        robustness_stats = df.groupby('method').agg({
            'is_valid': ['mean', 'std'],
            'optimality_gap': ['mean', 'std', 'count']
        })

        # 计算成功率的一致性
        robustness_stats['validity_consistency'] = 1.0 / (robustness_stats[('is_valid', 'std')] + 1e-6)

        sorted_robust = robustness_stats.sort_values('validity_consistency', ascending=False)

        for method in sorted_robust.index:
            stats = robustness_stats.loc[method]
            valid_mean = stats[('is_valid', 'mean')]
            valid_std = stats[('is_valid', 'std')]
            consistency = stats['validity_consistency']

            print(f"{method:<15}: 有效率={valid_mean:.3f}±{valid_std:.3f}, 一致性={consistency:.2f}")

        # 4. 校准效果分析
        print("\n🎯 校准对规划的影响")
        print("-" * 50)

        # 比较原始方法 vs 校准方法
        if 'original' in df['method'].values:
            original_results = df[df['method'] == 'original']
            calibrated_results = df[df['method'] != 'original']

            orig_path_len = original_results['path_length'].mean()
            calib_path_len = calibrated_results['path_length'].mean()

            orig_valid = original_results['is_valid'].mean()
            calib_valid = calibrated_results['is_valid'].mean()

            improvement = (orig_path_len - calib_path_len) / orig_path_len if orig_path_len > 0 else 0
            valid_improvement = calib_valid - orig_valid

            print(f"路径长度改进: {improvement:.1%} ({orig_path_len:.1f} -> {calib_path_len:.1f})")
            print(f"有效性改进: {valid_improvement:.3f} ({orig_valid:.3f} -> {calib_valid:.3f})")

        print("\n" + "="*100)


def main():
    parser = argparse.ArgumentParser(description="校准方法集成测试")
    parser.add_argument('--model', type=str, required=True, help='模型路径')
    parser.add_argument('--maps', nargs='+', required=True, help='测试地图路径列表')
    parser.add_argument('--output', type=str, default='calibration_integration_results.json',
                       help='输出结果路径')

    args = parser.parse_args()

    tester = CalibrationIntegrationTest()
    tester.run_integration_test(args.model, args.maps, args.output)


if __name__ == "__main__":
    main()