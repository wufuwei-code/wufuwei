"""
Enhanced Meta Controller Training with Focus Learning
基于残差分析的重点学习策略：
1. Adaptive Parameter Weighting - 根据残差方差调整学习权重
2. Residual-aware Loss - 重点优化高变异参数
3. Regularization - 防止参数退化到边界值
"""
import torch
import torch.nn as nn
import numpy as np
from typing import Dict, List, Tuple
import argparse
from pathlib import Path
from meta_controller import SimpleMLP, MetaController, PARAM_BOUNDS, FEATURE_ORDER
from train_meta_controller import MetaDataset, ranking_loss


class EnhancedMetaTrainer:
    def __init__(self, use_multi_head=False, focus_learning=True):
        self.use_multi_head = use_multi_head
        self.focus_learning = focus_learning
        
        # 基于数据分析的参数重要性权重
        self.param_weights = {
            'initial_weight': 2.0,      # 残差std=10.316，范围大
            'recent_visited_len': 2.5,  # 残差std=27.299，最大变异
            'frontier_radius': 1.5,     # 残差std=1.445，中等重要
            'lambda_risk': 1.3,         # 残差std=0.559，需要重点学习
            'lambda_smooth': 1.0,       # 残差std=0.308，基准
            'lambda_bonus': 1.0,        # 残差std=0.329，基准
            'curvature_window': 1.2,    # 残差std=1.076，中等
            'risk_power': 1.0,          # 残差std=0.252，基准
        }
        
        # 参数中心化目标（基于数据分析的均值）
        self.param_centers = {
            'initial_weight': 19.075,
            'lambda_risk': 1.264,
            'lambda_smooth': 0.672,
            'lambda_bonus': 0.683,
            'frontier_radius': 3.517,
            'recent_visited_len': 62.637,
            'curvature_window': 3.160,
            'risk_power': 1.403,
        }
        
    def compute_adaptive_loss(self, pred, target, param_names):
        """计算自适应加权损失"""
        losses = []
        for i, param_name in enumerate(param_names):
            weight = self.param_weights.get(param_name, 1.0)
            param_loss = nn.MSELoss()(pred[:, i], target[:, i])
            losses.append(weight * param_loss)
        return torch.stack(losses).mean()
    
    def compute_regularization_loss(self, pred, param_names):
        """计算参数中心化正则损失，防止退化到边界值"""
        reg_losses = []
        for i, param_name in enumerate(param_names):
            center = self.param_centers.get(param_name, 0.0)
            # 将预测值转换到真实参数空间再计算中心化损失
            lo, hi = PARAM_BOUNDS[param_name]
            # pred在[-1,1]空间，转换到真实空间
            real_pred = lo + (hi - lo) * (torch.tanh(pred[:, i]) + 1) / 2
            center_tensor = torch.full_like(real_pred, center)
            reg_loss = nn.MSELoss()(real_pred, center_tensor)
            reg_losses.append(reg_loss)
        return torch.stack(reg_losses).mean()


def create_enhanced_model(input_dim=20, hidden_dim=128, output_dim=8, use_multi_head=False):
    """创建增强模型架构"""
    return SimpleMLP(input_dim, hidden_dim, output_dim, use_multi_head)


def train_enhanced_model(
    dataset_path: str,
    model_save_path: str,
    scaler_save_path: str,
    epochs: int = 300,
    lr: float = 0.001,
    use_multi_head: bool = False,
    focus_learning: bool = True,
    ranking_weight: float = 0.1,
    reg_weight: float = 0.01
):
    """训练增强模型"""
    
    # 准备数据 - 使用正确的加载方式
    from meta.train_meta_controller import load_csv, MetaDataset
    rows = load_csv(dataset_path, delta_mode=True, use_soft=False)
    dataset = MetaDataset(rows)
    
    # 计算归一化参数
    features = np.stack([r['features'] for r in rows]).astype(np.float32)
    scaler_mean = np.mean(features, axis=0)
    scaler_std = np.std(features, axis=0) + 1e-6
    
    dataloader = torch.utils.data.DataLoader(dataset, batch_size=32, shuffle=True)
    
    # 创建模型和训练器
    model = create_enhanced_model(use_multi_head=use_multi_head)
    trainer = EnhancedMetaTrainer(use_multi_head, focus_learning)
    
    # 优化器和调度器
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-4)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, epochs)
    
    # 训练参数名
    param_names = ['initial_weight','lambda_risk','lambda_smooth','lambda_bonus',
                   'frontier_radius','recent_visited_len','curvature_window','risk_power']
    
    print(f"开始增强训练: {epochs}轮, focus_learning={focus_learning}")
    print(f"参数权重: {trainer.param_weights}")
    
    best_loss = float('inf')
    
    for epoch in range(epochs):
        model.train()
        epoch_loss = 0.0
        epoch_reg_loss = 0.0
        epoch_rank_loss = 0.0
        
        for batch_idx, batch in enumerate(dataloader):
            features, targets = batch
            optimizer.zero_grad()
            
            # 前向传播
            pred = model(features)
            
            # 1. 主要损失：自适应加权MSE
            if focus_learning:
                main_loss = trainer.compute_adaptive_loss(pred, targets, param_names)
            else:
                main_loss = nn.MSELoss()(pred, targets)
            
            # 2. 正则化损失：防止参数退化
            reg_loss = trainer.compute_regularization_loss(pred, param_names)
            
            # 3. Ranking损失：利用样本间顺序
            rank_loss = torch.tensor(0.0)
            if ranking_weight > 0:
                try:
                    # 获取当前batch的原始数据
                    start_idx = batch_idx * 32
                    end_idx = min(start_idx + 32, len(dataset))
                    batch_raw = [dataset.raw_data[i] for i in range(start_idx, end_idx)]
                    if len(batch_raw) > 1:
                        rank_loss = ranking_loss(pred, batch_raw, threshold=0.5, margin=0.1)
                except Exception as e:
                    # print(f"Ranking loss error: {e}")
                    pass
            
            # 总损失
            total_loss = main_loss + reg_weight * reg_loss + ranking_weight * rank_loss
            
            # 反向传播
            total_loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer.step()
            
            epoch_loss += main_loss.item()
            epoch_reg_loss += reg_loss.item()
            epoch_rank_loss += rank_loss.item() if isinstance(rank_loss, torch.Tensor) else 0
        
        scheduler.step()
        
        # 验证
        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for batch in dataloader:
                features, targets = batch
                pred = model(features)
                if focus_learning:
                    loss = trainer.compute_adaptive_loss(pred, targets, param_names)
                else:
                    loss = nn.MSELoss()(pred, targets)
                val_loss += loss.item()
        
        avg_loss = epoch_loss / len(dataloader)
        avg_reg = epoch_reg_loss / len(dataloader)
        avg_rank = epoch_rank_loss / len(dataloader)
        avg_val = val_loss / len(dataloader)
        
        if epoch % 20 == 0 or epoch == epochs - 1:
            print(f"Epoch {epoch:3d}: train={avg_loss:.4f} reg={avg_reg:.4f} rank={avg_rank:.4f} val={avg_val:.4f} lr={scheduler.get_last_lr()[0]:.6f}")
        
        # 保存最佳模型
        if avg_val < best_loss:
            best_loss = avg_val
            torch.save(model.state_dict(), model_save_path)
            np.savez(scaler_save_path, 
                    mean=scaler_mean, 
                    std=scaler_std, 
                    delta_mode=np.array([1]))
            if epoch % 50 == 0:
                print(f"  → 保存最佳模型 (val_loss={best_loss:.4f})")
    
    print(f"训练完成! 最佳验证损失: {best_loss:.4f}")
    return model, trainer


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', default='meta/dataset/meta_params_dataset.csv')
    parser.add_argument('--model', default='meta/models/meta_mlp_enhanced_focus.pt')
    parser.add_argument('--scaler', default='meta/models/meta_scaler_enhanced_focus.npz')
    parser.add_argument('--epochs', type=int, default=300)
    parser.add_argument('--lr', type=float, default=0.001)
    parser.add_argument('--use-multi-head', action='store_true')
    parser.add_argument('--focus-learning', action='store_true', default=True)
    parser.add_argument('--ranking-weight', type=float, default=0.1)
    parser.add_argument('--reg-weight', type=float, default=0.01)
    
    args = parser.parse_args()
    
    train_enhanced_model(
        args.data, args.model, args.scaler,
        epochs=args.epochs,
        lr=args.lr,
        use_multi_head=args.use_multi_head,
        focus_learning=args.focus_learning,
        ranking_weight=args.ranking_weight,
        reg_weight=args.reg_weight
    )