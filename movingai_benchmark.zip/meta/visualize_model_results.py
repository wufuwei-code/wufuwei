import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import torch
from meta.meta_controller import SimpleMLP, FEATURE_ORDER, PARAM_BOUNDS

PARAM_KEYS = ['initial_weight','lambda_risk','lambda_smooth','lambda_bonus','frontier_radius','recent_visited_len','curvature_window','risk_power']


def load_scaler(scaler_path):
    d = np.load(scaler_path)
    return d['mean'].astype(np.float32), d['std'].astype(np.float32)


def load_model(model_path, device='cpu', use_multi_head=False):
    model = SimpleMLP(in_dim=len(FEATURE_ORDER), hidden=96, out_dim=len(PARAM_KEYS), use_multi_head=use_multi_head)
    sd = torch.load(model_path, map_location=device)
    model.load_state_dict(sd)
    model.eval()
    return model


def prepare_dataset(csv_path, n_samples=None):
    df = pd.read_csv(csv_path)
    # drop failures
    if 'metric_success' in df.columns:
        df = df[df['metric_success'].astype(str).isin(['1','True','true'])]
    if n_samples is not None and len(df) > n_samples:
        df = df.sample(n=n_samples, random_state=42)
    # features
    X = df[FEATURE_ORDER].values.astype(np.float32)
    # targets prefer soft if available
    Y = df[[f'param_{k}' for k in PARAM_KEYS]].values.astype(np.float32)
    rules = None
    rule_cols = [f'rule_{k}' for k in PARAM_KEYS]
    if all(c in df.columns for c in rule_cols):
        rules = df[rule_cols].values.astype(np.float32)
    return df, X, Y, rules


def predict_direct(model, X, scaler_mean=None, scaler_std=None):
    import torch
    Xn = X.copy()
    if scaler_mean is not None:
        Xn = (Xn - scaler_mean) / (scaler_std + 1e-6)
    with torch.no_grad():
        t = torch.from_numpy(Xn).float()
        out = model(t).cpu().numpy()
    # sigmoid
    norm = 1.0 / (1.0 + np.exp(-out))
    preds = np.zeros_like(norm)
    for i,k in enumerate(PARAM_KEYS):
        lo,hi = PARAM_BOUNDS[k]
        vals = lo + (hi-lo) * norm[:,i]
        if k in ['frontier_radius','recent_visited_len','curvature_window']:
            vals = np.round(vals).astype(int)
        preds[:,i] = vals
    return preds


def evaluate_preds(Y_true, Y_pred):
    mae = np.mean(np.abs(Y_true - Y_pred), axis=0)
    mse = np.mean((Y_true - Y_pred)**2, axis=0)
    return mae, mse


def plot_scatter_all(Y_true, Y_pred, out_prefix):
    Path('meta/figs').mkdir(parents=True, exist_ok=True)
    # paper style
    try:
        plt.style.use('seaborn')
    except Exception:
        plt.style.use('default')
    sns.set_style('whitegrid')
    sns.set_context('paper', font_scale=1.1)
    plt.rcParams.update({
        'font.family': 'serif',
        'font.serif': ['Times New Roman', 'DejaVu Serif'],
        'figure.dpi': 300,
    })

    for i,k in enumerate(PARAM_KEYS):
        fig, ax = plt.subplots(figsize=(5,5))
        ax.scatter(Y_true[:,i], Y_pred[:,i], s=18, alpha=0.6, color='#1f77b4')
        mn = min(Y_true[:,i].min(), Y_pred[:,i].min())
        mx = max(Y_true[:,i].max(), Y_pred[:,i].max())
        ax.plot([mn,mx],[mn,mx],'--',color='gray', linewidth=1)
        ax.set_xlabel('True '+k)
        ax.set_ylabel('Pred '+k)
        # stats
        import scipy.stats as st
        # avoid ConstantInputWarning: check for constant arrays
        y_true_col = Y_true[:,i].flatten()
        y_pred_col = Y_pred[:,i].flatten()
        try:
            if np.allclose(y_true_col, y_true_col[0]) or np.allclose(y_pred_col, y_pred_col[0]):
                r = np.nan
            else:
                r, _ = st.pearsonr(y_true_col, y_pred_col)
        except Exception:
            r = np.nan
        ss_res = np.sum((Y_true[:,i]-Y_pred[:,i])**2)
        ss_tot = np.sum((Y_true[:,i]-np.mean(Y_true[:,i]))**2)
        r2 = 1 - ss_res/(ss_tot + 1e-12)
        ax.text(0.05, 0.92, f'$r$={r:.2f}\n$R^2$={r2:.2f}', transform=ax.transAxes, fontsize=9, verticalalignment='top', bbox=dict(boxstyle='round', facecolor='white', alpha=0.7))
        ax.set_title(k, fontsize=10)
        plt.tight_layout()
        out_png = f'meta/figs/{out_prefix}_scatter_{k}.png'
        out_pdf = f'meta/figs/{out_prefix}_scatter_{k}.pdf'
        fig.savefig(out_png, dpi=300)
        fig.savefig(out_pdf)
        plt.close(fig)


def plot_error_bar(mae, out_path):
    Path('meta/figs').mkdir(parents=True, exist_ok=True)
    try:
        plt.style.use('seaborn')
    except Exception:
        plt.style.use('default')
    sns.set_context('paper', font_scale=1.1)
    fig, ax = plt.subplots(figsize=(9,4))
    palette = sns.color_palette('muted', len(PARAM_KEYS))
    x = np.arange(len(PARAM_KEYS))
    ax.bar(x, mae, color=palette)
    ax.set_ylabel('MAE')
    ax.set_xticks(x)
    ax.set_xticklabels(PARAM_KEYS, rotation=45, ha='right')
    plt.tight_layout()
    fig.savefig(out_path.replace('.png','_hr.png'), dpi=300)
    fig.savefig(out_path.replace('.png','_hr.pdf'))
    plt.close(fig)


def plot_feat_param_corr(X, Y, out_path):
    Path('meta/figs').mkdir(parents=True, exist_ok=True)
    df = pd.DataFrame(X, columns=FEATURE_ORDER)
    for i,k in enumerate(PARAM_KEYS):
        df[k] = Y[:,i]
    corr = df.corr(method='pearson')
    try:
        plt.style.use('seaborn')
    except Exception:
        plt.style.use('default')
    fig, ax = plt.subplots(figsize=(10,8))
    sns.heatmap(corr.loc[FEATURE_ORDER, PARAM_KEYS], annot=True, fmt='.2f', cmap='vlag', center=0, ax=ax, cbar_kws={'shrink':0.6})
    ax.set_title('Feature vs Param Pearson r')
    plt.tight_layout()
    fig.savefig(out_path.replace('.png','_hr.png'), dpi=300)
    fig.savefig(out_path.replace('.png','_hr.pdf'))
    plt.close(fig)


def main():
    model_path = 'meta/models/meta_mlp.pt'
    scaler_path = 'meta/models/meta_scaler.npz'
    csv_path = 'meta/dataset/meta_params_dataset.csv'

    df, X, Y, rules = prepare_dataset(csv_path, n_samples=2000)
    scaler_mean, scaler_std = load_scaler(scaler_path)
    model = load_model(model_path)
    preds = predict_direct(model, X, scaler_mean, scaler_std)

    mae, mse = evaluate_preds(Y, preds)
    print('MAE per param:', dict(zip(PARAM_KEYS, mae)))
    print('MSE per param:', dict(zip(PARAM_KEYS, mse)))

    plot_scatter_all(Y, preds, 'direct')
    plot_error_bar(mae, 'meta/figs/direct_mae_bar.png')
    plot_feat_param_corr(X, preds, 'meta/figs/feat_param_corr_direct.png')

    # save numeric summary
    out_csv = Path('meta/figs/direct_error_summary.csv')
    df_out = pd.DataFrame({'param': PARAM_KEYS, 'mae': mae, 'mse': mse})
    df_out.to_csv(out_csv, index=False)

    # generate simple markdown report
    report_md = Path('meta/figs/report.md')
    with report_md.open('w', encoding='utf-8') as f:
        f.write('# Model Prediction Summary\n\n')
        f.write('This report summarizes the model prediction performance (direct mode) on the evaluation dataset.\n\n')
        f.write('## Numeric Summary\n\n')
        # to_markdown depends on optional 'tabulate'. If not available, fall back to manual markdown table.
        try:
            md_table = df_out.to_markdown(index=False)
        except Exception:
            cols = df_out.columns.tolist()
            header = '| ' + ' | '.join(cols) + ' |\n'
            sep = '| ' + ' | '.join(['---'] * len(cols)) + ' |\n'
            rows = ''
            for row in df_out.values.tolist():
                rows += '| ' + ' | '.join([str(x) for x in row]) + ' |\n'
            md_table = header + sep + rows
        f.write(md_table)
        f.write('\n\n')
        f.write('## Figures\n\n')
        f.write('- Scatter plots (true vs pred) for each parameter: `meta/figs/direct_scatter_{param}.pdf` / `.png`\n')
        f.write('- MAE bar chart: `meta/figs/direct_mae_bar_hr.pdf` / `.png`\n')
        f.write('- Feature-Parameter Pearson correlation heatmap: `meta/figs/feat_param_corr_direct_hr.pdf` / `.png`\n')
        f.write('\n')
        f.write('## Parameter meanings\n\n')
        for p in PARAM_KEYS:
            f.write(f'- **{p}**: see code `meta/meta_controller.py` for detailed description.\n')
        f.write('\n')
        f.write('## Notes\n\n')
        f.write('- MAE and MSE computed over the available dataset (failures removed).\n')
        f.write('- Scatter plots include Pearson r and $R^2$ annotations when defined.\n')

    print(f'Wrote CSV summary to {out_csv} and Markdown report to {report_md}')

if __name__ == '__main__':
    main()
