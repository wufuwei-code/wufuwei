import pandas as pd
import numpy as np

# 读取数据
df = pd.read_csv('results/random100_mixed_benchmark - 副本.csv')

print('=== 对比三种算法的扩展节点数 ===\n')
for alg in ['A*', 'ML-A*', 'Theta*']:
    data = df[df['algorithm']==alg]['expanded_nodes']
    print(f'{alg}:')
    print(f'  平均值: {data.mean():.1f}')
    print(f'  中位数: {data.median():.1f}')
    print(f'  最小值: {data.min():.1f}')
    print(f'  最大值: {data.max():.1f}')
    print()

ml_mean = df[df['algorithm']=='ML-A*']['expanded_nodes'].mean()
a_mean = df[df['algorithm']=='A*']['expanded_nodes'].mean()
print(f'ML-A*/A* 扩展节点数比例: {(ml_mean/a_mean*100):.1f}%')
print(f'ML-A* 减少了: {((1-ml_mean/a_mean)*100):.1f}%\n')

# 检查前几个场景
print('=== 前5个场景的详细对比 ===')
df['map_scn'] = df['map_name'].astype(str) + '|' + df['scenario_id'].astype(str)
scenarios = df[df['algorithm']=='A*']['map_scn'].unique()[:5]

for scn in scenarios:
    print(f'\n场景: {scn}')
    for alg in ['A*', 'ML-A*', 'Theta*']:
        row = df[(df['map_scn']==scn) & (df['algorithm']==alg)]
        if not row.empty:
            exp = row['expanded_nodes'].values[0]
            path = row['path_length'].values[0]
            print(f'  {alg:8s}: expanded={exp:8.0f}, path_length={path:.1f}')
