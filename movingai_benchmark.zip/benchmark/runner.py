import time
import pandas as pd
import numpy as np
from typing import List, Dict, Any
from tqdm import tqdm
import signal
import threading
from contextlib import contextmanager
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FuturesTimeout


class TimeoutException(Exception):
    pass


@contextmanager
def time_limit(seconds):
    """跨平台超时上下文：在支持 SIGALRM 的系统上使用 signal，否则用 threading.Timer 备选实现。"""
    # Unix-like 系统支持 SIGALRM
    if hasattr(signal, 'SIGALRM'):
        def signal_handler(signum, frame):
            raise TimeoutException("Timed out!")

        old_handler = signal.getsignal(signal.SIGALRM)
        signal.signal(signal.SIGALRM, signal_handler)
        signal.alarm(seconds)
        try:
            yield
        finally:
            signal.alarm(0)
            signal.signal(signal.SIGALRM, old_handler)
    else:
        # 在 Windows 等不支持 SIGALRM 的平台上，使用 Timer 抛出异常的降级方案
        timer = None

        def raise_timeout():
            raise_timeout.exception = TimeoutException("Timed out!")

        def timer_fn():
            # 在线程中设置一个属性，主线程检查后会抛出异常。
            raise_timeout()

        try:
            timer = threading.Timer(seconds, lambda: None)
            timer.start()
            yield
        finally:
            if timer is not None:
                timer.cancel()


class BenchmarkRunner:
    """基准测试运行器"""
    
    def __init__(self, data_loader, timeout: float = 30.0):
        self.loader = data_loader
        self.timeout = timeout
        self.algorithms = {}
        self.results = None
        
    def register_algorithm(self, name: str, finder):
        """注册算法"""
        self.algorithms[name] = finder
        
    def run_benchmark(self, map_names: List[str], max_scenarios: int = 100) -> pd.DataFrame:
        """运行基准测试"""
        all_results = []
        
        for map_name in tqdm(map_names, desc="地图"):
            # 加载地图
            grid = self.loader.load_map(map_name)
            if grid is None:
                continue
                
            # 加载场景
            scenarios = self.loader.load_scenarios(map_name)
            if not scenarios:
                print(f"地图 {map_name} 没有找到场景")
                continue
                
            # 限制场景数量
            scenarios = scenarios[:max_scenarios]
            
            for scenario in tqdm(scenarios, desc=f"场景 {map_name}", leave=False):
                start = (scenario['start_y'], scenario['start_x'])
                goal = (scenario['goal_y'], scenario['goal_x'])
                
                # 验证起点终点
                if not self._is_valid_position(grid, start) or not self._is_valid_position(grid, goal):
                    continue
                    
                for algo_name, finder in self.algorithms.items():
                    try:
                        # run finder in thread to allow reliable timeout on all platforms
                        with ThreadPoolExecutor(max_workers=1) as ex:
                            future = ex.submit(finder.find_path, grid, start, goal)
                            try:
                                result = future.result(timeout=self.timeout)
                            except FuturesTimeout:
                                result = self._create_timeout_result(algo_name)
                    except Exception as e:
                        import traceback
                        print(f"算法 {algo_name} 在场景 {scenario} 出错: {e}")
                        traceback.print_exc()
                        result = self._create_error_result(algo_name)
                    
                    # 添加场景信息
                    result.update({
                        'map_name': map_name,
                        'scenario_id': scenario['bucket'],
                        'start_x': start[1],
                        'start_y': start[0],
                        'goal_x': goal[1],
                        'goal_y': goal[0],
                        'optimal_length': scenario['optimal_length'],
                        'suboptimality_ratio': (result['path_length'] / scenario['optimal_length'] 
                                              if result['success'] and scenario['optimal_length'] > 0 
                                              else float('inf'))
                    })
                    
                    all_results.append(result)
                    
        self.results = pd.DataFrame(all_results)
        return self.results
    
    def _is_valid_position(self, grid: np.ndarray, pos: tuple) -> bool:
        """检查位置是否有效"""
        row, col = pos
        return (0 <= row < grid.shape[0] and 
                0 <= col < grid.shape[1] and 
                grid[row, col] == 0)
    
    def _create_timeout_result(self, algo_name: str) -> Dict[str, Any]:
        """创建超时结果"""
        return {
            'path': [],
            'path_length': float('inf'),
            'expanded_nodes': 0,
            'grid_steps': 0,
            'computation_time': self.timeout,
            'success': False,
            'algorithm': algo_name,
            'timeout': True
        }
    
    def _create_error_result(self, algo_name: str) -> Dict[str, Any]:
        """创建错误结果"""
        return {
            'path': [],
            'path_length': float('inf'),
            'expanded_nodes': 0,
            'grid_steps': 0,
            'computation_time': 0,
            'success': False,
            'algorithm': algo_name,
            'error': True
        }
    
    def save_results(self, filename: str):
        """保存结果"""
        if self.results is not None:
            self.results.to_csv(filename, index=False)
    
    def load_results(self, filename: str) -> pd.DataFrame:
        """加载结果"""
        self.results = pd.read_csv(filename)
        return self.results